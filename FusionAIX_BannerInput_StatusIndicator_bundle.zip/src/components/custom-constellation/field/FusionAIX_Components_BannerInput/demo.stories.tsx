import type { Meta, StoryObj } from '@storybook/react';

import FusionAixComponentsBannerInput from './index';

import { stateProps, configProps, fieldMetadata } from './mock';

const storyNoop = (): void => {
  /* Storybook mock — intentionally empty */
};

const meta: Meta<typeof FusionAixComponentsBannerInput> = {
  title: 'FusionAixComponentsBannerInput',
  component: FusionAixComponentsBannerInput,
  excludeStories: /.*Data$/,
};

export default meta;
type Story = StoryObj<typeof FusionAixComponentsBannerInput>;

export const BaseFusionAixComponentsBannerInput: Story = (args) => {
  const props = {
    value: configProps.value,
    hasSuggestions: configProps.hasSuggestions,
    fieldMetadata,
    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: storyNoop,
            triggerFieldChange: storyNoop,
          };
        },
        ignoreSuggestion: storyNoop,
        acceptSuggestion: storyNoop,
        setInheritedProps: storyNoop,
        resolveConfigProps: storyNoop,
      };
    },
  };

  return <FusionAixComponentsBannerInput {...props} {...args} />;
};

BaseFusionAixComponentsBannerInput.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  testId: configProps.testId,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  required: configProps.required,
  status: configProps.status,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  variant: configProps.variant,
  validatemessage: configProps.validatemessage,
};

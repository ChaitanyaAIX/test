export type BannerInputFieldActions = {
  updateFieldValue: (propName: string, value: string) => void;
  triggerFieldChange: (propName: string, value: string) => void;
};

const handleEvent = (
  actions: BannerInputFieldActions,
  eventType: string,
  propName: string,
  value: string,
) => {
  switch (eventType) {
    case 'change':
      actions.updateFieldValue(propName, value);
      break;
    case 'blur':
      actions.triggerFieldChange(propName, value);
      break;
    case 'changeNblur':
      actions.updateFieldValue(propName, value);
      actions.triggerFieldChange(propName, value);
      break;
    default:
      return;
  }
};

export default handleEvent;

export type BannerSuggestionsPConn = {
  acceptSuggestion: () => void;
  ignoreSuggestion: () => void;
};

export type BannerSuggestionsSetStatus = (status: 'success' | undefined) => void;

export const suggestionsHandler = (
  accepted: boolean,
  pConn: BannerSuggestionsPConn,
  setStatus: BannerSuggestionsSetStatus,
) => {
  if (accepted) {
    pConn.acceptSuggestion();
    setStatus('success');
  } else {
    pConn.ignoreSuggestion();
    setStatus(undefined);
  }
};

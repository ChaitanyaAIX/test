/**
 * Propagate webpack nonce from window when present (CSP / style injection).
 */
function applyWebpackNonceFromWindow(): void {
  if (typeof window === 'undefined') {
    return;
  }

  const nonce = (window as Window & { __webpack_nonce__?: string }).__webpack_nonce__;
  if (nonce === undefined || nonce === '') {
    return;
  }

  const globalNonceHolder = globalThis as typeof globalThis & { __webpack_nonce__?: string };
  globalNonceHolder.__webpack_nonce__ = nonce;
}

applyWebpackNonceFromWindow();

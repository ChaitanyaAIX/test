import { tryCatch } from '@pega/cosmos-react-core';
import { getContrast, readableColor } from 'polished';
import styled, { css } from 'styled-components';

/** Minimal theme shape used by banner styled components (Cosmos palette keys). */
export type BannerThemeShape = {
  components: {
    card: {
      'border-radius': string;
    };
  };
  base: {
    palette: Record<string, string>;
  };
};

export const StyledBanner = styled.div(({ theme }) => {
  const t = theme as BannerThemeShape;
  return css`
    border-radius: ${t.components.card['border-radius']};
    min-height: 3.5rem;
    display: grid;
    grid-template-columns: 2rem minmax(0, 1fr);
  `;
});

export const StyledBannerStatus = styled.div<{ $variant: string }>(({ $variant, theme }) => {
  const t = theme as BannerThemeShape;
  const background = t.base.palette[$variant];
  const color = tryCatch(() =>
    getContrast(background, t.base.palette['primary-background']) >= 3
      ? t.base.palette['primary-background']
      : readableColor(background),
  );

  return css`
    background-color: ${background};
    color: ${color};
    border: 0.0625rem solid ${background};
    border-inline-end: none;
    border-start-start-radius: inherit;
    border-end-start-radius: inherit;
    font-size: 1.25rem;
    padding: 0 1rem;
    display: flex;
    justify-content: center;
    align-items: center;
  `;
});
export const StyledBannerText = styled.div<{ $variant: string }>(({ $variant, theme }) => {
  const t = theme as BannerThemeShape;
  const background = t.base.palette['primary-background'];
  const color = readableColor(background);
  return css`
    background: ${background};
    padding-block: 0.5rem;
    padding-inline-start: 0.5rem;
    padding-inline-end: 0.5rem;
    border: 0.0625rem solid ${t.base.palette[$variant]};
    border-inline-start: none;
    border-start-end-radius: inherit;
    border-end-end-radius: inherit;
    display: flex;
    align-items: center;
    color: ${color};
  `;
});

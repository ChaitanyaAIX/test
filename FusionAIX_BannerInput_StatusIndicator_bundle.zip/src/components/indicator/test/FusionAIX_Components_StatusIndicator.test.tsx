import React from 'react';
import { render, screen } from '@testing-library/react';

jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => {
  return {
    __esModule: true,
    getComponentFromMap: () => {
      return ({ name, value, variant }: any) => (
        <div
          data-test-id="field-value-list"
          data-name={name}
          data-value={value}
          data-variant={variant}
        />
      );
    },
  };
});

jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    __esModule: true,
    registerIcon: jest.fn(),
    withConfiguration: (Comp: any) => Comp,
    Text: ({ children, ...rest }: any) => <span {...rest}>{children}</span>,
    Status: ({ children, ...rest }: any) => <span data-test-id="status" {...rest}>{children}</span>,
    Icon: ({ name, ...rest }: any) => <span data-test-id="icon" data-name={name} {...rest} />,
  };
});

jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon',
  () => ({ name: 'check' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/arrow-down.icon',
  () => ({ name: 'arrow-down' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-solid.icon',
  () => ({ name: 'flag-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon',
  () => ({ name: 'flag-wave-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon',
  () => ({ name: 'warn-solid' }),
  {
    virtual: true,
  },
);

import StatusIndicator from '../../custom-sdk/field/FusionAIX_Components_StatusIndicator';

describe('FusionAIX_Components_StatusIndicator', () => {
  it('renders FieldValueList in DISPLAY_ONLY mode', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'DISPLAY_ONLY', label: 'Status', value: 'GREEN' } as any)}
      />,
    );
    const node = screen.getByTestId('field-value-list');
    expect(node).toHaveAttribute('data-name', 'Status');
    expect(node).toHaveAttribute('data-value', 'GREEN');
  });

  it('hides FieldValueList label in DISPLAY_ONLY mode when hideLabel is true', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'DISPLAY_ONLY', label: 'Status', hideLabel: true, value: 'GREEN' } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-name', '');
  });

  it('renders stacked FieldValueList in STACKED_LARGE_VAL mode', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'STACKED_LARGE_VAL', label: 'Status', value: 'GREEN' } as any)}
      />,
    );
    const node = screen.getByTestId('field-value-list');
    expect(node).toHaveAttribute('data-name', 'Status');
    expect(node).toHaveAttribute('data-variant', 'stacked');
  });

  it('hides FieldValueList label in STACKED_LARGE_VAL mode when hideLabel is true', () => {
    render(
      <StatusIndicator
        {...({
          displayMode: 'STACKED_LARGE_VAL',
          label: 'Status',
          hideLabel: true,
          value: 'GREEN',
        } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-name', '');
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-variant', 'stacked');
  });

  it('renders badge variant when indicator is badge', () => {
    const { container } = render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          testId: 'badge-wrapper',
          successStatus: 'green',
          value: 'green',
        } as any)}
      />,
    );
    expect(container.querySelector('[data-testid="badge-wrapper"]')).toBeInTheDocument();
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'arrow-down');
  });

  it('renders label when provided and hideLabel is false', () => {
    render(<StatusIndicator {...({ label: 'Overall Status', value: 'GREEN' } as any)} />);
    expect(screen.getByText('Overall Status')).toBeInTheDocument();
  });

  it('does not render label when hideLabel is true', () => {
    render(<StatusIndicator {...({ label: 'Overall Status', hideLabel: true, value: 'GREEN' } as any)} />);
    expect(screen.queryByText('Overall Status')).toBeNull();
  });

  it('renders critical status and warn icon for RED', () => {
    const { container } = render(
      <StatusIndicator {...({ label: 'Health', value: 'RED' } as any)} />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Critical' })).toHaveAttribute(
      'title',
      'Critical',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
    expect(container.querySelectorAll('[aria-hidden="true"]').length).toBeGreaterThanOrEqual(4);
  });

  it('normalizes YELLOW to AMBER and uses flag icon', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'YELLOW' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Warning' })).toHaveAttribute(
      'title',
      'Warning',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-wave-solid');
  });

  it('renders healthy status and check icon for GREEN', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'GREEN' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('uses Unknown when value is not a known status', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'BLUE' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
    expect(screen.queryByTestId('icon')).toBeNull();
  });

  it('handles null value safely and keeps Unknown status', () => {
    render(<StatusIndicator {...({ label: 'Health', value: null } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
    expect(screen.queryByTestId('icon')).toBeNull();
  });
});

import React from 'react';
import { render, screen } from '@testing-library/react';
import { ThemeProvider, type DefaultTheme } from 'styled-components';

import type { BannerThemeShape } from '../../../src/components/custom-sdk/field/FusionAIX_Components_BannerInput/styles';

jest.mock('@pega/cosmos-react-core', () => {
  return {
    __esModule: true,
    registerIcon: jest.fn(),
    withConfiguration: (Comp: unknown) => Comp,
    tryCatch: (fn: () => unknown) => {
      try {
        return fn();
      } catch {
        return undefined;
      }
    },
    Icon: ({ name }: { name: string }) => (
      <span data-test-id="banner-icon" data-name={name} />
    ),
    HTML: ({ content }: { content: string }) => (
      <span data-test-id="banner-html">{content}</span>
    ),
  };
});

jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon',
  () => ({ name: 'warn-solid' }),
  { virtual: true },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon',
  () => ({ name: 'flag-wave-solid' }),
  { virtual: true },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon',
  () => ({ name: 'check' }),
  { virtual: true },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/information-solid.icon',
  () => ({ name: 'information-solid' }),
  { virtual: true },
);

import SdkBanner from '../../../src/components/custom-sdk/field/FusionAIX_Components_BannerInput';
import ConstellationBanner from '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput';

const mockTheme: BannerThemeShape = {
  components: {
    card: {
      'border-radius': '4px',
    },
  },
  base: {
    palette: {
      success: '#13744f',
      urgent: '#e34850',
      info: '#287ee8',
      warn: '#ffb236',
      pending: '#868686',
      'primary-background': '#ffffff',
    },
  },
};

function renderWithTheme(ui: React.ReactElement) {
  return render(
    <ThemeProvider theme={mockTheme as unknown as DefaultTheme}>{ui}</ThemeProvider>,
  );
}

const variants = ['success', 'urgent', 'info', 'warn', 'pending'] as const;
const icons = ['warn-solid', 'flag-wave-solid', 'check', 'information-solid'] as const;

describe.each([
  ['custom-sdk', SdkBanner],
  ['custom-constellation', ConstellationBanner],
] as const)('FusionAIX_Components_BannerInput (%s)', (_label, Banner) => {
  it('renders defaults (success variant, warn-solid icon, empty value)', () => {
    renderWithTheme(<Banner value="" />);
    const alert = screen.getByRole('alert');
    expect(alert).toHaveAttribute('aria-label', 'Banner success - ');
    expect(alert).toHaveAttribute('aria-live', 'polite');
    expect(alert).toHaveAttribute('tabIndex', '0');
    expect(screen.getByTestId('banner-icon')).toHaveAttribute('data-name', 'warn-solid');
    expect(screen.getByTestId('banner-html')).toHaveTextContent('');
  });

  it('renders value in HTML and aria-label', () => {
    renderWithTheme(<Banner value="Hello" />);
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner success - Hello');
    expect(screen.getByTestId('banner-html')).toHaveTextContent('Hello');
  });

  it.each(variants)('uses variant %s in aria-label', (variant) => {
    renderWithTheme(<Banner value="x" variant={variant} />);
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', `Banner ${variant} - x`);
  });

  it.each(icons)('passes icon %s to Icon', (icon) => {
    renderWithTheme(<Banner value="v" icon={icon} />);
    expect(screen.getByTestId('banner-icon')).toHaveAttribute('data-name', icon);
  });

  it('uses default value when value prop is omitted', () => {
    renderWithTheme(<Banner {...({ variant: 'info' } as any)} />);
    expect(screen.getByTestId('banner-html')).toHaveTextContent('');
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner info - ');
  });

  it('uses success variant when variant is explicitly undefined', () => {
    renderWithTheme(<Banner {...({ value: 'q', variant: undefined } as any)} />);
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner success - q');
  });

  it('keeps warn-solid icon when icon is explicitly undefined', () => {
    renderWithTheme(<Banner {...({ value: 'z', variant: 'warn', icon: undefined } as any)} />);
    expect(screen.getByTestId('banner-icon')).toHaveAttribute('data-name', 'warn-solid');
  });
});

import * as polished from 'polished';
import React from 'react';
import { render } from '@testing-library/react';
import { ThemeProvider, type DefaultTheme } from 'styled-components';

jest.mock('@pega/cosmos-react-core', () => ({
  __esModule: true,
  tryCatch: (fn: () => unknown) => {
    try {
      return fn();
    } catch {
      return undefined;
    }
  },
}));

import * as constellationStyles from '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/styles';
import * as sdkStyles from '../../../src/components/custom-sdk/field/FusionAIX_Components_BannerInput/styles';
import type { BannerThemeShape } from '../../../src/components/custom-sdk/field/FusionAIX_Components_BannerInput/styles';

type BannerStylesModule = typeof sdkStyles;

function runBannerStylesSuite(label: string, mod: BannerStylesModule) {
  const { StyledBanner, StyledBannerStatus, StyledBannerText } = mod;

  const basePalette: Record<string, string> = {
    success: '#13744f',
    urgent: '#e34850',
    info: '#287ee8',
    warn: '#ffb236',
    pending: '#868686',
    'primary-background': '#ffffff',
  };

  const mkTheme = (overrides: Partial<Record<string, string>> = {}): BannerThemeShape => ({
    components: {
      card: {
        'border-radius': '4px',
      },
    },
    base: {
      palette: { ...basePalette, ...overrides } as Record<string, string>,
    },
  });

  const themeProp = (t: BannerThemeShape) => t as unknown as DefaultTheme;

  describe(`FusionAIX_Components_BannerInput styles (${label})`, () => {
    it('renders StyledBanner grid shell', () => {
      const { container } = render(
        <ThemeProvider theme={themeProp(mkTheme())}>
          <StyledBanner>
            <StyledBannerStatus $variant="success">
              <span>icon</span>
            </StyledBannerStatus>
            <StyledBannerText $variant="success">
              <span>text</span>
            </StyledBannerText>
          </StyledBanner>
        </ThemeProvider>,
      );
      expect(container.textContent).toContain('icon');
      expect(container.textContent).toContain('text');
    });

    it('uses readableColor branch when contrast vs primary-background is low', () => {
      const theme = mkTheme({
        success: '#fefefe',
        'primary-background': '#ffffff',
      });
      const { container } = render(
        <ThemeProvider theme={themeProp(theme)}>
          <StyledBannerStatus $variant="success">
            <span>s</span>
          </StyledBannerStatus>
        </ThemeProvider>,
      );
      expect(container.querySelector('div')).toBeTruthy();
    });

    it('recovers via tryCatch when getContrast throws', () => {
      const spy = jest.spyOn(polished, 'getContrast').mockImplementationOnce(() => {
        throw new Error('boom');
      });
      const { container } = render(
        <ThemeProvider theme={themeProp(mkTheme())}>
          <StyledBannerStatus $variant="warn">
            <span>s</span>
          </StyledBannerStatus>
        </ThemeProvider>,
      );
      spy.mockRestore();
      expect(container.querySelector('div')).toBeTruthy();
    });

    it('renders StyledBannerText with variant border color', () => {
      const { container } = render(
        <ThemeProvider theme={themeProp(mkTheme())}>
          <StyledBannerText $variant="info">
            <span>msg</span>
          </StyledBannerText>
        </ThemeProvider>,
      );
      expect(container.textContent).toContain('msg');
    });
  });
}

runBannerStylesSuite('custom-sdk', sdkStyles);
runBannerStylesSuite('custom-constellation', constellationStyles as BannerStylesModule);

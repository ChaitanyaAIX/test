import handleEvent from '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/event-utils';

describe('FusionAIX_Components_BannerInput event-utils', () => {
  const mkActions = () => ({
    updateFieldValue: jest.fn(),
    triggerFieldChange: jest.fn(),
  });

  it('handles change', () => {
    const actions = mkActions();
    handleEvent(actions, 'change', 'f1', 'a');
    expect(actions.updateFieldValue).toHaveBeenCalledWith('f1', 'a');
    expect(actions.triggerFieldChange).not.toHaveBeenCalled();
  });

  it('handles blur', () => {
    const actions = mkActions();
    handleEvent(actions, 'blur', 'f1', 'b');
    expect(actions.triggerFieldChange).toHaveBeenCalledWith('f1', 'b');
    expect(actions.updateFieldValue).not.toHaveBeenCalled();
  });

  it('handles changeNblur', () => {
    const actions = mkActions();
    handleEvent(actions, 'changeNblur', 'f1', 'c');
    expect(actions.updateFieldValue).toHaveBeenCalledWith('f1', 'c');
    expect(actions.triggerFieldChange).toHaveBeenCalledWith('f1', 'c');
  });

  it('ignores unknown event types', () => {
    const actions = mkActions();
    handleEvent(actions, 'unknown', 'f1', 'd');
    expect(actions.updateFieldValue).not.toHaveBeenCalled();
    expect(actions.triggerFieldChange).not.toHaveBeenCalled();
  });
});

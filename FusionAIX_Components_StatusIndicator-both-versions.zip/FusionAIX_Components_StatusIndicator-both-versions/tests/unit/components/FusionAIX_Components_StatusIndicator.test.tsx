import React from 'react';
import { render, screen } from '@testing-library/react';

jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => {
  return {
    __esModule: true,
    getComponentFromMap: () => {
      return ({ name, value, variant }: any) => (
        <div
          data-test-id="field-value-list"
          data-name={name}
          data-value={value}
          data-variant={variant}
        />
      );
    },
  };
});

jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    __esModule: true,
    registerIcon: jest.fn(),
    withConfiguration: (Comp: any) => Comp,
    Text: ({ children, ...rest }: any) => <span {...rest}>{children}</span>,
    Status: ({ children, variant, ...rest }: any) => (
      <span data-test-id="status" data-variant={variant} {...rest}>
        {children}
      </span>
    ),
    Icon: ({ name, ...rest }: any) => <span data-test-id="icon" data-name={name} {...rest} />,
  };
});

jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon',
  () => ({ name: 'check' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/arrow-down.icon',
  () => ({ name: 'arrow-down' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-solid.icon',
  () => ({ name: 'flag-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon',
  () => ({ name: 'flag-wave-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon',
  () => ({ name: 'warn-solid' }),
  {
    virtual: true,
  },
);

import StatusIndicator from '../../../src/components/custom-sdk/field/FusionAIX_Components_StatusIndicator';

describe('FusionAIX_Components_StatusIndicator', () => {
  it('renders FieldValueList in DISPLAY_ONLY mode', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'DISPLAY_ONLY', label: 'Status', value: 'GREEN' } as any)}
      />,
    );
    const node = screen.getByTestId('field-value-list');
    expect(node).toHaveAttribute('data-name', 'Status');
    expect(node).toHaveAttribute('data-value', 'GREEN');
  });

  it('hides FieldValueList label in DISPLAY_ONLY mode when hideLabel is true', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'DISPLAY_ONLY', label: 'Status', hideLabel: true, value: 'GREEN' } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-name', '');
  });

  it('renders stacked FieldValueList in STACKED_LARGE_VAL mode', () => {
    render(
      <StatusIndicator
        {...({ displayMode: 'STACKED_LARGE_VAL', label: 'Status', value: 'GREEN' } as any)}
      />,
    );
    const node = screen.getByTestId('field-value-list');
    expect(node).toHaveAttribute('data-name', 'Status');
    expect(node).toHaveAttribute('data-variant', 'stacked');
  });

  it('hides FieldValueList label in STACKED_LARGE_VAL mode when hideLabel is true', () => {
    render(
      <StatusIndicator
        {...({
          displayMode: 'STACKED_LARGE_VAL',
          label: 'Status',
          hideLabel: true,
          value: 'GREEN',
        } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-name', '');
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-variant', 'stacked');
  });

  it('renders badge variant when indicator is badge', () => {
    const { container } = render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          testId: 'badge-wrapper',
          successStatus: 'green',
          value: 'green',
        } as any)}
      />,
    );
    expect(container.querySelector('[data-testid="badge-wrapper"]')).toBeInTheDocument();
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'arrow-down');
  });

  it('renders label when provided and hideLabel is false', () => {
    render(<StatusIndicator {...({ label: 'Overall Status', value: 'GREEN' } as any)} />);
    expect(screen.getByText('Overall Status')).toBeInTheDocument();
  });

  it('does not render label when hideLabel is true', () => {
    render(<StatusIndicator {...({ label: 'Overall Status', hideLabel: true, value: 'GREEN' } as any)} />);
    expect(screen.queryByText('Overall Status')).toBeNull();
  });

  it('renders critical status and warn icon for RED', () => {
    const { container } = render(
      <StatusIndicator {...({ label: 'Health', value: 'RED' } as any)} />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Critical' })).toHaveAttribute(
      'title',
      'Critical',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
    expect(container.querySelectorAll('[aria-hidden="true"]').length).toBeGreaterThanOrEqual(4);
  });

  it('normalizes YELLOW to AMBER and uses flag icon', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'YELLOW' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Warning' })).toHaveAttribute(
      'title',
      'Warning',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-wave-solid');
  });

  it('renders healthy status and check icon for GREEN', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'GREEN' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('maps traffic light from successStatus patterns like badge', () => {
    render(
      <StatusIndicator
        {...({
          label: 'Health',
          indicator: 'trafficIndicator',
          value: 'resolved',
          successStatus: 'resolved|completed|success',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('maps traffic light from pendingStatus and urgentStatus patterns', () => {
    const { rerender } = render(
      <StatusIndicator
        {...({
          label: 'Health',
          indicator: 'trafficIndicator',
          value: 'pending',
          successStatus: 'resolved',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Warning' })).toHaveAttribute(
      'title',
      'Warning',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-wave-solid');

    rerender(
      <StatusIndicator
        {...({
          label: 'Health',
          indicator: 'trafficIndicator',
          value: 'blocked',
          successStatus: 'resolved',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Critical' })).toHaveAttribute(
      'title',
      'Critical',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
  });

  it('uses Unknown when traffic value matches no pattern and is not RED, AMBER, or GREEN', () => {
    render(<StatusIndicator {...({ label: 'Health', value: 'BLUE' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
    expect(screen.queryByTestId('icon')).toBeNull();
  });

  it('handles null value safely and keeps Unknown status', () => {
    render(<StatusIndicator {...({ label: 'Health', value: null } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
    expect(screen.queryByTestId('icon')).toBeNull();
  });

  it('badge prefers inputProperty over value for displayed text', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          inputProperty: '  sdk-prop  ',
          value: 'ignored',
          infoStatus: 'sdk-prop',
        } as any)}
      />,
    );
    expect(screen.getByText('SDK-PROP')).toBeInTheDocument();
  });

  it('badge maps info variant when only infoStatus matches', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'ticket-open',
          infoStatus: 'open',
          warnStatus: '',
          successStatus: '',
          pendingStatus: '',
          urgentStatus: '',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('badge maps pending variant when pendingStatus matches', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'work pending',
          pendingStatus: 'pending',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'pending');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('badge rejects lookahead-style warnStatus as unsafe regex', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'x',
          warnStatus: '(?=x)',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('badge rejects backreference-style warnStatus as unsafe regex', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'x1',
          warnStatus: '\\1',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge rejects repetition token abuse in warnStatus', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'a',
          warnStatus: 'a++',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge rejects nested-quantifier-style warnStatus as unsafe', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'a',
          warnStatus: '(a*)',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge handles slash-regex syntax errors without throwing', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'pep',
          warnStatus: '/[/i',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge supports slash-delimited warnStatus when valid', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'pep',
          warnStatus: '/^pep$/i',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'warn');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-solid');
  });

  it('badge handles invalid raw regex without throwing', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'x',
          warnStatus: '(unclosed',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });
});

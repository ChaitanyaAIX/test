import React from 'react';
import { render, screen } from '@testing-library/react';

// Mock Cosmos components so we can assert props/classes safely.
jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    __esModule: true,
    registerIcon: jest.fn(),
    withConfiguration: (Comp: any) => Comp,
    Text: ({ children, ...rest }: any) => <span {...rest}>{children}</span>,
    Status: ({ children, className, variant }: any) => (
      <span data-test-id="status" data-variant={variant} className={className}>
        {children}
      </span>
    ),
    Icon: ({ name, className }: any) => (
      <span data-test-id="icon" data-name={name} className={className} />
    ),
  };
});

// Mock icon modules that are imported + registered.
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon',
  () => ({ name: 'check' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/arrow-down.icon',
  () => ({ name: 'arrow-down' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-solid.icon',
  () => ({ name: 'flag-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon',
  () => ({ name: 'flag-wave-solid' }),
  {
    virtual: true,
  },
);
jest.mock(
  '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon',
  () => ({ name: 'warn-solid' }),
  {
    virtual: true,
  },
);

import StatusIndicator from '../../../src/components/custom-constellation/field/FusionAIX_Components_StatusIndicator';

describe('FusionAIX_Components_StatusBadge', () => {
  it('renders label when provided (and not hidden)', () => {
    render(
      <StatusIndicator
        {...({ indicator: 'badge', label: 'Integrity Block', value: 'NOT PRESENT' } as any)}
      />,
    );
    expect(screen.getByText('Integrity Block')).toBeInTheDocument();
  });

  it('does not render label when hideLabel is true', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          label: 'Integrity Block',
          hideLabel: true,
          value: 'NOT PRESENT',
        } as any)}
      />,
    );
    expect(screen.queryByText('Integrity Block')).toBeNull();
  });

  it('uppercases displayed value and defaults to "--"', () => {
    const { rerender } = render(
      <StatusIndicator {...({ indicator: 'badge', value: 'not present' } as any)} />,
    );
    expect(screen.getByText('NOT PRESENT')).toBeInTheDocument();

    rerender(<StatusIndicator {...({ indicator: 'badge', value: '' } as any)} />);
    expect(screen.getByText('--')).toBeInTheDocument();
  });

  it('maps success variant to arrow-down icon (safe substring matching)', () => {
    render(
      <StatusIndicator
        {...({ indicator: 'badge', value: 'not present', successStatus: 'NOT PRESENT' } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'success');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'arrow-down');
  });

  it('maps warn variant to flag icon', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'present', warnStatus: 'PRESENT' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'warn');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-solid');
  });

  it('maps urgent variant to warn-solid icon', () => {
    render(
      <StatusIndicator
        {...({ indicator: 'badge', value: 'present', urgentStatus: 'PRESENT' } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'urgent');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
  });

  it('supports explicit regex syntax (/.../i) safely', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'pep', warnStatus: '/^pep$/i' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'warn');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-solid');
  });

  it('supports raw regex-like patterns (e.g. ^...$) for backwards compatibility', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'pep', warnStatus: '^pep$' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'warn');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-solid');
  });

  it('ignores invalid regex patterns without throwing', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'pep', warnStatus: '/(pep/i' } as any)} />,
    );
    // falls back to default info + check icon
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('ignores overly long patterns (security guard) and keeps default variant', () => {
    const longPattern = `/${'a'.repeat(500)}/i`;
    render(
      <StatusIndicator
        {...({ indicator: 'badge', value: 'aaaa', warnStatus: longPattern } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('applies icon position class to Status and Icon', () => {
    render(
      <StatusIndicator
        {...({
          indicator: 'badge',
          value: 'not present',
          successStatus: 'NOT PRESENT',
          iconPosition: 'right',
        } as any)}
      />,
    );
    expect(screen.getByTestId('status').className).toContain('status-badge-pill--icon-right');
    expect(screen.getByTestId('icon').className).toContain('status-badge-icon--right');
  });

  it('badge rejects lookahead-style warnStatus as unsafe regex', () => {
    render(
      <StatusIndicator
        {...({ indicator: 'badge', value: 'x', warnStatus: '(?=x)' } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge rejects backreference-style warnStatus as unsafe regex', () => {
    render(
      <StatusIndicator
        {...({ indicator: 'badge', value: 'x1', warnStatus: '\\1' } as any)}
      />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge rejects nested-quantifier-style warnStatus as unsafe', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'a', warnStatus: '(a*)' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge handles slash-regex syntax errors without throwing', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'pep', warnStatus: '/[/i' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge rejects repetition token abuse in warnStatus (constellation parity)', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'a', warnStatus: 'a++' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });

  it('badge handles invalid raw regex without throwing (constellation parity)', () => {
    render(
      <StatusIndicator {...({ indicator: 'badge', value: 'x', warnStatus: '(unclosed' } as any)} />,
    );
    expect(screen.getByTestId('status')).toHaveAttribute('data-variant', 'info');
  });
});

describe('FusionAIX_Components_StatusIndicator (constellation traffic)', () => {
  const TrafficIndicator = StatusIndicator;

  it('renders label for traffic mode when not hidden', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: 'GREEN' } as any)} />);
    expect(screen.getByText('Health')).toBeInTheDocument();
  });

  it('does not render label when hideLabel is true', () => {
    render(
      <TrafficIndicator {...({ label: 'Health', hideLabel: true, value: 'GREEN' } as any)} />,
    );
    expect(screen.queryByText('Health')).toBeNull();
  });

  it('renders critical status for RED literal', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: 'RED' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Critical' })).toHaveAttribute(
      'title',
      'Critical',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
  });

  it('normalizes YELLOW to AMBER and shows warning', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: 'YELLOW' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Warning' })).toHaveAttribute(
      'title',
      'Warning',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-wave-solid');
  });

  it('renders healthy status for GREEN literal', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: 'GREEN' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('maps traffic light from successStatus patterns', () => {
    render(
      <TrafficIndicator
        {...({
          label: 'Health',
          value: 'resolved',
          successStatus: 'resolved|completed|success',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'check');
  });

  it('maps traffic light from pendingStatus and urgentStatus patterns', () => {
    const { rerender } = render(
      <TrafficIndicator
        {...({
          label: 'Health',
          value: 'pending',
          successStatus: 'resolved',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Warning' })).toHaveAttribute(
      'title',
      'Warning',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'flag-wave-solid');

    rerender(
      <TrafficIndicator
        {...({
          label: 'Health',
          value: 'blocked',
          successStatus: 'resolved',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Critical' })).toHaveAttribute(
      'title',
      'Critical',
    );
    expect(screen.getByTestId('icon')).toHaveAttribute('data-name', 'warn-solid');
  });

  it('uses Unknown when value matches no pattern and is not a literal status', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: 'BLUE' } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
    expect(screen.queryByTestId('icon')).toBeNull();
  });

  it('handles null value as Unknown traffic status', () => {
    render(<TrafficIndicator {...({ label: 'Health', value: null } as any)} />);
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toHaveAttribute(
      'title',
      'Unknown',
    );
  });

  it('ignores unsafe successStatus patterns and falls back to literal GREEN', () => {
    render(
      <TrafficIndicator
        {...({
          label: 'Health',
          value: 'GREEN',
          successStatus: '(?=x)',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Healthy' })).toHaveAttribute(
      'title',
      'Healthy',
    );
  });

  it('ignores slash-regex syntax errors in traffic patterns', () => {
    render(
      <TrafficIndicator
        {...({
          label: 'Health',
          value: 'x',
          successStatus: '/[/i',
          pendingStatus: 'pending',
          urgentStatus: 'blocked',
        } as any)}
      />,
    );
    expect(screen.getByRole('img', { name: 'Current status: Unknown' })).toBeInTheDocument();
  });

  it('applies testId on traffic wrapper', () => {
    const { container } = render(
      <TrafficIndicator {...({ label: 'H', value: 'GREEN', testId: 'traffic-root' } as any)} />,
    );
    expect(container.querySelector('[data-testid="traffic-root"]')).toBeInTheDocument();
  });
});

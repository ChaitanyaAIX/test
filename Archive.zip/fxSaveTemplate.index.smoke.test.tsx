import React from 'react';
import { render } from '@testing-library/react';

jest.mock('@pega/react-sdk-components/lib/components/helpers/template-utils', () => ({
  __esModule: true,
  getInstructions: jest.fn(() => ''),
}));

jest.mock('@pega/react-sdk-components/lib/components/helpers/field-group-utils', () => ({
  __esModule: true,
  getReferenceList: jest.fn(() => '.SomeList'),
}));

jest.mock('@mui/material', () => ({
  __esModule: true,
  Typography: ({ children, ...rest }: any) => <div {...rest}>{children}</div>,
}));

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/styles',
  () => {
    const ReactActual = require('react');
    return {
      __esModule: true,
      default: ({ children }: any) => <div>{children}</div>,
    };
  },
);

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/updateEtag',
  () => ({
    __esModule: true,
    default: jest.fn(),
  }),
);

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/reduxMessage',
  () => ({
    __esModule: true,
    clearReduxPropertyMessages: jest.fn(),
  }),
);

describe('FusionAIX_Components_fxSaveTemplate index', () => {
  beforeEach(() => {
    const onViewMutate = jest.fn();
    (global as any).PCore = {
      getConstants: () => ({
        CASE_INFO: {
          ASSIGNMENT_ID: 'ASSIGNMENT_ID',
          ACTIVE_ACTION_ID: 'ACTIVE_ACTION_ID',
          ASSIGNMENTACTION_ID: 'ASSIGNMENTACTION_ID',
        },
      }),
      getFormUtils: () => ({
        getChanges: () => ({ caseInfo: { content: {} } }),
        getEditableFields: () => [],
      }),
      getContextTreeManager: () => ({
        onViewMutate,
      }),
      getRestClient: () => ({
        invokeRestApi: jest.fn(() => Promise.resolve({ headers: { etag: 'new' } })),
      }),
    };
  });

  it('renders without crashing and registers onViewMutate', () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp =
      require('../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/index.tsx')
        .default;

    const getPConnect = () => ({
      getValue: () => '',
      getContextName: () => 'app/primary_1',
      getPageReference: () => 'caseInfo.content',
      getCurrentView: () => 'View',
    });

    const childRegion = {
      props: {
        getPConnect: () => ({
          getChildren: () => [],
        }),
      },
    };

    render(
      <Comp
        getPConnect={getPConnect}
        NumCols="1"
        instructions=""
        isPrivateSave={false}
        timeout={1}
      >
        {[childRegion]}
      </Comp>,
    );

    expect((global as any).PCore.getContextTreeManager().onViewMutate).toHaveBeenCalled();
  });
});


import React from 'react';
import { act, render } from '@testing-library/react';

jest.mock('@pega/react-sdk-components/lib/components/helpers/template-utils', () => ({
  __esModule: true,
  getInstructions: jest.fn(() => ''),
}));

jest.mock('@pega/react-sdk-components/lib/components/helpers/field-group-utils', () => ({
  __esModule: true,
  getReferenceList: jest.fn(() => '.SomeList'),
}));

jest.mock('@mui/material', () => ({
  __esModule: true,
  Typography: ({ children, ...rest }: any) => <div {...rest}>{children}</div>,
}));

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/styles',
  () => {
    const ReactActual = require('react');
    return {
      __esModule: true,
      default: ({ children }: any) => <div>{children}</div>,
    };
  },
);

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/updateEtag',
  () => ({
    __esModule: true,
    default: jest.fn(),
  }),
);

jest.mock(
  '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/reduxMessage',
  () => ({
    __esModule: true,
    clearReduxPropertyMessages: jest.fn(),
  }),
);

describe('FusionAIX_Components_fxSaveTemplate index', () => {
  let onViewMutateMock: jest.Mock;
  let onViewMutateCallback: (() => void) | undefined;

  beforeEach(() => {
    jest.useFakeTimers();
    onViewMutateCallback = undefined;
    onViewMutateMock = jest.fn((_ctx: string, _root: string, _viewName: string, cb: () => void) => {
      onViewMutateCallback = cb;
    });

    const invokeRestApi = jest.fn(() => Promise.resolve({ headers: { etag: 'new' } }));

    (global as any).PCore = {
      getConstants: () => ({
        CASE_INFO: {
          ASSIGNMENT_ID: 'ASSIGNMENT_ID',
          ACTIVE_ACTION_ID: 'ACTIVE_ACTION_ID',
          ASSIGNMENTACTION_ID: 'ASSIGNMENTACTION_ID',
        },
      }),
      getFormUtils: () => ({
        getChanges: () => ({ caseInfo: { content: {} } }),
        getEditableFields: () => [],
      }),
      getContextTreeManager: () => ({
        onViewMutate: onViewMutateMock,
      }),
      getRestClient: () => ({
        invokeRestApi,
      }),
    };
  });

  afterEach(() => {
    jest.runOnlyPendingTimers();
    jest.useRealTimers();
  });

  it('renders without crashing and registers onViewMutate', () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp =
      require('../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/index.tsx')
        .default;

    const getPConnect = () => ({
      getValue: () => '',
      getContextName: () => 'app/primary_1',
      getPageReference: () => 'caseInfo.content',
      getCurrentView: () => 'View',
    });

    const childRegion = {
      props: {
        getPConnect: () => ({
          getChildren: () => [
            {
              getPConnect: () => ({
                getComponent: () => <div data-testid="field-1" />,
                getRawMetadata: () => ({ type: 'field' }),
              }),
            },
          ],
        }),
      },
    };

    render(
      <Comp
        getPConnect={getPConnect}
        NumCols="1"
        instructions=""
        isPrivateSave={false}
        timeout={1}
      >
        {[childRegion]}
      </Comp>,
    );

    expect((global as any).PCore.getContextTreeManager().onViewMutate).toHaveBeenCalled();
  });

  it('builds pageInstructions for array edits and calls save API', async () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp =
      require('../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/index.tsx')
        .default;

    const updateEtag =
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      require('../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/updateEtag')
        .default as jest.Mock;
    const { clearReduxPropertyMessages } =
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      require('../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/reduxMessage');

    const invokeRestApi =
      (global as any).PCore.getRestClient().invokeRestApi as jest.Mock;

    // Drive editable array field path extraction
    (global as any).PCore.getFormUtils = () => ({
      getChanges: () => ({
        caseInfo: {
          content: {
            FirstName: 'John',
            CreditScores: [{ CreditScore: 700 }],
          },
        },
      }),
      getEditableFields: () => [{ name: 'caseInfo.content.CreditScores[0].CreditScore' }],
    });

    const refViewPConnect = {
      setReferenceList: jest.fn(),
      getValue: jest.fn(() => []), // caseInfo.content.SomeList -> []
    };

    const getPConnect = () => ({
      getValue: (path: string) => {
        if (path === 'caseInfo.headers.etag') {
          return 'etag-old';
        }
        if (path === (global as any).PCore.getConstants().CASE_INFO.ASSIGNMENT_ID) {
          return 'A-1';
        }
        if (path === (global as any).PCore.getConstants().CASE_INFO.ACTIVE_ACTION_ID) {
          return 'ACT-1';
        }
        if (path === 'caseInfo.content.CreditScores[0].CreditScore') {
          return 720;
        }
        return '';
      },
      getContextName: () => 'app/primary_1',
      getPageReference: () => 'caseInfo.content',
      getCurrentView: () => 'View',
    });

    const childRegion = {
      props: {
        getPConnect: () => ({
          getChildren: () => [
            {
              getPConnect: () => ({
                getComponent: () => <div data-testid="field-1" />,
                getRawMetadata: () => ({ type: 'field' }),
              }),
            },
            {
              getPConnect: () => ({
                getRawMetadata: () => ({ type: 'reference' }),
                getReferencedViewPConnect: () => ({ getPConnect: () => refViewPConnect }),
                getComponent: () => <div data-testid="field-ref" />,
              }),
            },
          ],
        }),
      },
    };

    render(
      <Comp
        getPConnect={getPConnect}
        NumCols="1"
        instructions=""
        isPrivateSave={false}
        timeout={1}
      >
        {[childRegion]}
      </Comp>,
    );

    expect(onViewMutateCallback).toBeTruthy();

    await act(async () => {
      onViewMutateCallback?.();
    });

    await act(async () => {
      jest.runAllTimers();
      await Promise.resolve();
    });

    expect(invokeRestApi).toHaveBeenCalledWith(
      'save',
      expect.objectContaining({
        headers: { 'if-match': 'etag-old' },
        queryPayload: expect.objectContaining({ assignmentID: 'A-1', actionID: 'ACT-1' }),
        body: expect.objectContaining({
          pageInstructions: [
            expect.objectContaining({
              target: '.SomeList',
              listIndex: 1,
              instruction: 'INSERT',
              content: expect.objectContaining({ CreditScore: 720 }),
            }),
          ],
        }),
      }),
    );

    expect(updateEtag).toHaveBeenCalled();
    expect(clearReduxPropertyMessages).toHaveBeenCalled();
    expect(refViewPConnect.setReferenceList).toHaveBeenCalledWith('.SomeList');
  });
});


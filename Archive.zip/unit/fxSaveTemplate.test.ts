import updateCaseinfoEtag from '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/updateEtag';
import { clearReduxPropertyMessages } from '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/reduxMessage';

describe('FusionAIX_Components_fxSaveTemplate helpers', () => {
  describe('updateCaseinfoEtag', () => {
    it('returns early when store does not match expected shape', () => {
      const updateCaseContextEtag = jest.fn();
      (global as any).PCore = {
        getStore: () => ({ bad: true }),
        getContainerUtils: () => ({ updateCaseContextEtag }),
      };

      updateCaseinfoEtag('OLD', 'LATEST');
      expect(updateCaseContextEtag).not.toHaveBeenCalled();
    });

    it('returns early when store state does not match expected shape', () => {
      const updateCaseContextEtag = jest.fn();
      const store = {
        getState: () => ({ bad: true }),
      };
      (global as any).PCore = {
        getStore: () => store,
        getContainerUtils: () => ({ updateCaseContextEtag }),
      };

      updateCaseinfoEtag('OLD', 'LATEST');
      expect(updateCaseContextEtag).not.toHaveBeenCalled();
    });

    it('updates containers whose etag matches the old etag', () => {
      const updateCaseContextEtag = jest.fn();
      const store = {
        getState: () => ({
          data: {
            CTX1: { caseInfo: { headers: { etag: 'OLD' } } },
            CTX2: { caseInfo: { headers: { etag: 'NEW' } } },
            // invalid shape should be skipped by zod parsing
            CTX_BAD: { notCaseInfo: true },
          },
        }),
      };

      (global as any).PCore = {
        getStore: () => store,
        getContainerUtils: () => ({ updateCaseContextEtag }),
      };

      updateCaseinfoEtag('OLD', 'LATEST');

      expect(updateCaseContextEtag).toHaveBeenCalledTimes(1);
      expect(updateCaseContextEtag).toHaveBeenCalledWith('CTX1', 'LATEST');
    });

    it('overwrites all containers when old etag is null', () => {
      const updateCaseContextEtag = jest.fn();
      const store = {
        getState: () => ({
          data: {
            CTX1: { caseInfo: { headers: { etag: 'OLD' } } },
            CTX2: { caseInfo: { headers: { etag: 'NEW' } } },
          },
        }),
      };

      (global as any).PCore = {
        getStore: () => store,
        getContainerUtils: () => ({ updateCaseContextEtag }),
      };

      updateCaseinfoEtag(null, 'LATEST');

      expect(updateCaseContextEtag).toHaveBeenCalledTimes(2);
      expect(updateCaseContextEtag).toHaveBeenCalledWith('CTX1', 'LATEST');
      expect(updateCaseContextEtag).toHaveBeenCalledWith('CTX2', 'LATEST');
    });
  });

  describe('clearReduxPropertyMessages', () => {
    it('returns when store is unavailable', () => {
      (global as any).PCore = { getStore: () => null };
      expect(() => clearReduxPropertyMessages('caseInfo.content', 'CTX')).not.toThrow();
    });

    it('returns when no property messages exist', () => {
      const dispatch = jest.fn();
      const store = {
        getState: () => ({ data: { CTX: { context_data: { caseInfo: { content: {} } } } } }),
        dispatch,
      };
      (global as any).PCore = { getStore: () => store };
      clearReduxPropertyMessages('caseInfo.content', 'CTX');
      expect(dispatch).not.toHaveBeenCalled();
    });

    it('dispatches MERGE_DATA for caseInfo.content root', () => {
      const dispatch = jest.fn();
      const store = {
        getState: () => ({
          data: {
            CTX: {
              context_data: {
                caseInfo: {
                  content: {
                    summary_of_messages__: {
                      propertyMessages__: {
                        field1: [{ type: 'error', message: 'boom' }],
                      },
                    },
                  },
                },
              },
            },
          },
        }),
        dispatch,
      };

      (global as any).PCore = {
        getStore: () => store,
      };

      clearReduxPropertyMessages('caseInfo.content', 'CTX');

      expect(dispatch).toHaveBeenCalledTimes(1);
      const action = dispatch.mock.calls[0]?.[0];
      expect(action.type).toBe('MERGE_DATA');
      expect(action.payload.context).toBe('CTX');
      expect(action.payload.data.context_data.caseInfo.content).toEqual({
        summary_of_messages__: {
          propertyMessages__: null,
        },
      });
    });

    it('dispatches MERGE_DATA for a page reference inside caseInfo.content', () => {
      const dispatch = jest.fn();
      const store = {
        getState: () => ({
          data: {
            CTX: {
              context_data: {
                caseInfo: {
                  content: {
                    somePage: {
                      summary_of_messages__: {
                        propertyMessages__: {
                          field1: [{ type: 'error', message: 'boom' }],
                        },
                      },
                    },
                  },
                },
              },
            },
          },
        }),
        dispatch,
      };

      (global as any).PCore = {
        getStore: () => store,
      };

      clearReduxPropertyMessages('caseInfo.content.somePage', 'CTX');

      expect(dispatch).toHaveBeenCalledTimes(1);
      const action = dispatch.mock.calls[0]?.[0];

      expect(action.payload.data.context_data.caseInfo.content).toEqual({
        somePage: {
          summary_of_messages__: {
            propertyMessages__: null,
          },
        },
      });
    });
  });
});


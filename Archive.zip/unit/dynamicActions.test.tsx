import React from 'react';
import { fireEvent, render } from '@testing-library/react';

jest.mock('@mui/styles/makeStyles', () => {
  return () => () => ({
    buttonContainer: 'buttonContainer',
    actionButton: 'actionButton',
  });
});

jest.mock('@mui/material/Button', () => {
  const React = require('react');
  return ({ children, onClick }: any) => (
    <button type="button" onClick={onClick}>
      {children}
    </button>
  );
});

jest.mock('@mui/material/Box', () => {
  const React = require('react');
  return ({ children, ...rest }: any) => <div {...rest}>{children}</div>;
});

jest.mock('../../src/components/custom-sdk/widget/FusionAIX_Components_DynamicActions/styles', () => {
  const React = require('react');
  return ({ children }: any) => <div data-mock="DynamicActionsStyles">{children}</div>;
});

describe('FusionAIX_Components_DynamicActions', () => {
  beforeAll(() => {
    (global as any).PCore = {
      getConstants: () => ({
        CASE_INFO: { AVAILABLEACTIONS: 'availableActions' },
      }),
    };
    (window as any).PCore = (global as any).PCore;
  });

  const makePConnect = (overrides: Partial<any> = {}) => ({
    getValue: jest.fn(() => null),
    getActionsApi: jest.fn(() => ({ openLocalAction: jest.fn() })),
    ...overrides,
  });

  it('renders a fallback when no actions are available', async () => {
    const { default: DynamicActions } = await import(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_DynamicActions/index'
    );

    const pConn = makePConnect({
      getValue: jest.fn(() => null),
    });

    const { getByText } = render(<DynamicActions {...({ getPConnect: () => pConn } as any)} />);
    expect(getByText('No actions available')).toBeTruthy();
  });

  it('renders buttons for available actions and opens local action on click', async () => {
    const { default: DynamicActions } = await import(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_DynamicActions/index'
    );

    const openLocalAction = jest.fn();
    const pConn = makePConnect({
      getValue: jest.fn((key: string) => {
        if (key === (global as any).PCore.getConstants().CASE_INFO.AVAILABLEACTIONS) {
          return [
            { ID: 'A1', name: 'Approve', type: 'local', links: { open: { href: '/open' } } },
            { ID: 'A2', name: 'Reject', type: 'local', links: { open: { href: '/open2' } } },
          ];
        }
        return null;
      }),
      getActionsApi: jest.fn(() => ({ openLocalAction })),
    });

    const { getByText } = render(<DynamicActions {...({ getPConnect: () => pConn } as any)} />);

    fireEvent.click(getByText('Approve'));

    expect(openLocalAction).toHaveBeenCalledTimes(1);
    expect(openLocalAction).toHaveBeenCalledWith(
      'A1',
      expect.objectContaining({
        ID: 'A1',
        name: 'Approve',
        containerName: 'modal',
        type: 'express',
        target: undefined,
      }),
    );
  });
});

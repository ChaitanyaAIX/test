jest.mock(
  '@pega/react-sdk-components/lib/components/helpers/template-utils',
  () => ({
    getInstructions: jest.fn(() => ''),
  }),
);

const { getContext, getReferenceList, getView } = require('../../src/components/custom-sdk/template/ConstellationUIGallery_Components_fxDynamicTab/index') as typeof import('../../src/components/custom-sdk/template/ConstellationUIGallery_Components_fxDynamicTab/index');

describe('ConstellationUIGallery_Components_fxDynamicTab helpers', () => {
  describe('getContext', () => {
    it('builds pageReferenceForRows when referenceList starts with "."', () => {
      const getPConnect = () =>
        ({
          getContextName: () => 'CTX',
          getPageReference: () => 'pyWork',
          getStateProps: () => ({
            config: {
              readonlyContextList: '',
              referenceList: '.RowDetails',
            },
          }),
          viewName: 'myView',
        }) as any;

      const ctx = getContext(getPConnect as any);
      expect(ctx).toEqual({
        contextName: 'CTX',
        referenceListStr: '.RowDetails',
        pageReferenceForRows: 'pyWork.RowDetails',
        viewName: 'myView',
      });
    });

    it('uses readonlyContextList as referenceList when no referenceList is provided', () => {
      const getPConnect = () =>
        ({
          getContextName: () => 'CTX2',
          getPageReference: () => 'pyPage',
          getStateProps: () => ({
            readonlyContextList: 'Some.RefList',
          }),
          viewName: 'view2',
        }) as any;

      const ctx = getContext(getPConnect as any);
      expect(ctx.referenceListStr).toBe('Some.RefList');
      expect(ctx.pageReferenceForRows).toBe('Some.RefList');
    });
  });

  describe('getReferenceList', () => {
    it('returns the stripped referenceList when it does not contain D_', () => {
      const pConn = {
        getComponentConfig: () => ({ referenceList: '@P .MyList' }),
      } as any;

      expect(getReferenceList(pConn)).toBe('.MyList');
    });

    it('resolves a datasource reference and returns pxResults when present', () => {
      const resolveDatasourceReference = jest.fn(() => ({ pxResults: 'RESOLVED_LIST' }));
      const pConn = {
        getComponentConfig: () => ({ referenceList: '@P D_ABC' }),
        resolveDatasourceReference,
      } as any;

      expect(getReferenceList(pConn)).toBe('RESOLVED_LIST');
      expect(resolveDatasourceReference).toHaveBeenCalled();
    });

    it('appends ".pxResults" when resolving D_ pages without pxResults', () => {
      const resolveDatasourceReference = jest.fn(() => ({ notPxResults: true }));
      const pConn = {
        getComponentConfig: () => ({ referenceList: '@P D_ABC' }),
        resolveDatasourceReference,
      } as any;

      expect(getReferenceList(pConn)).toBe('D_ABC.pxResults');
    });
  });

  describe('getView', () => {
    it('delegates to pConn.createComponent', () => {
      const createComponent = jest.fn(() => ({ props: {} }));
      const view = { config: { heading: 'h' } } as any;
      const out = getView(view, () => ({ createComponent } as any));
      expect(createComponent).toHaveBeenCalledWith(view, undefined, undefined, undefined);
      expect(out).toEqual({ props: {} });
    });
  });
});


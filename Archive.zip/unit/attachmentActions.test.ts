import {
  addFilesFromFiles,
  addFilesWithPicker,
} from '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/attachmentActions';

describe('attachmentActions.addFilesFromFiles', () => {
  beforeEach(() => {
    const uploadAttachment = jest.fn(async () => ({
      ID: 'SVR-1',
      pzInsKey: 'PZ-1',
    }));
    const linkAttachmentsToCase = jest.fn(async () => undefined);
    const updateState = jest.fn(async () => undefined);

    (window as any).PCore = {
      getAttachmentUtils: () => ({
        uploadAttachment,
        linkAttachmentsToCase,
      }),
      getStoreValue: jest.fn(() => []),
      getStateUtils: () => ({
        updateState,
      }),
    };
  });

  it('uploads files, links to case, and updates attachment state', async () => {
    const uploadAttachment = (window as any).PCore.getAttachmentUtils().uploadAttachment as jest.Mock;
    const linkAttachmentsToCase = (window as any).PCore.getAttachmentUtils().linkAttachmentsToCase as jest.Mock;
    const updateState = (window as any).PCore.getStateUtils().updateState as jest.Mock;

    const file = new File(['abc'], 'a.pdf', { type: 'application/pdf' });

    await addFilesFromFiles([file], {
      contextName: 'CTX',
      multiple: true,
      valueRef: '.myRef',
      categoryName: 'Cat',
      linkToCase: true,
      linkedCaseId: 'LINK-CASE',
    });

    expect(uploadAttachment).toHaveBeenCalledTimes(1);
    expect(linkAttachmentsToCase).toHaveBeenCalledTimes(1);

    // updateAttachmentState uses normalized value ref: attachmentsList.myRef
    expect(updateState).toHaveBeenCalledWith(
      'CTX',
      'attachmentsList.myRef',
      expect.any(Array),
      expect.objectContaining({
        pageReference: 'context_data',
        isArrayDeepMerge: false,
      }),
    );

    const merged = updateState.mock.calls[0]?.[2] as any[];
    expect(merged[0]?.ID).toBe('SVR-1');
  });

  it('throws partial-success error when at least one upload fails', async () => {
    const uploadAttachment = jest
      .fn()
      .mockResolvedValueOnce({ ID: 'OK-1', pzInsKey: 'PZ-1' })
      .mockResolvedValueOnce({ status: 500, message: 'request failed' });
    const updateState = jest.fn();
    (window as any).PCore = {
      getAttachmentUtils: () => ({ uploadAttachment, linkAttachmentsToCase: jest.fn() }),
      getStoreValue: jest.fn(() => []),
      getStateUtils: () => ({ updateState }),
    };

    const files = [
      new File(['a'], 'ok.pdf', { type: 'application/pdf' }),
      new File(['b'], 'bad.pdf', { type: 'application/pdf' }),
    ];

    await expect(
      addFilesFromFiles(files, {
        contextName: 'CTX',
        multiple: true,
        valueRef: '.myRef',
        categoryName: 'Cat',
        linkToCase: false,
      }),
    ).rejects.toMatchObject({ partialSuccess: true });

    expect(updateState).toHaveBeenCalled();
  });

  it('supports single-file mode and picker flow', async () => {
    const uploadAttachment = jest.fn(async () => ({ ID: 'SVR-2', pzInsKey: 'PZ-2' }));
    const updateState = jest.fn();
    (window as any).PCore = {
      getAttachmentUtils: () => ({ uploadAttachment, linkAttachmentsToCase: jest.fn() }),
      getStoreValue: jest.fn(() => []),
      getStateUtils: () => ({ updateState }),
    };

    const originalCreateElement = document.createElement.bind(document);
    const clickSpy = jest
      .spyOn(document, 'createElement')
      .mockImplementationOnce(() => {
        const input = originalCreateElement('input');
        Object.defineProperty(input, 'files', {
          value: [new File(['a'], 'one.pdf', { type: 'application/pdf' })],
        });
        setTimeout(() => input.onchange?.(new Event('change') as any), 0);
        return input;
      });

    await addFilesWithPicker({ contextName: 'CTX', multiple: false, accept: '.pdf' });
    expect(uploadAttachment).toHaveBeenCalledTimes(1);
    expect(updateState).toHaveBeenCalled();
    clickSpy.mockRestore();
  });
});


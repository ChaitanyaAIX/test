import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import getEdgeParams from '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/utils';

// reactflow is heavy; we mock only the pieces used by these modules.
jest.mock('reactflow', () => {
  const React = require('react');
  return {
    __esModule: true,
    Position: { Left: 'Left', Right: 'Right', Top: 'Top', Bottom: 'Bottom' },
    Handle: ({ id }: any) => <div data-test-id={`handle-${id}`} />,
    getStraightPath: jest.fn(() => ['STRAIGHT', 10, 20]),
    getSmoothStepPath: jest.fn(() => ['STEP', 11, 21]),
    getBezierPath: jest.fn(() => ['BEZIER', 12, 22]),
    EdgeLabelRenderer: ({ children }: any) => <div data-test-id="edge-label">{children}</div>,
    BaseEdge: (props: any) => <div data-test-id="base-edge" data-path={props.path} />,
    useStore: (selector: any) => selector((global as any).__rfStore || { nodeInternals: new Map() }),
  };
});

// Cosmos components are mocked in the smoke test file; keep this test isolated.
jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    Link: ({ children, onClick, onPreview, href }: any) => (
      <a href={href} data-test-id="cosmos-link" onClick={onClick} onMouseEnter={onPreview}>
        {children}
      </a>
    ),
    Text: ({ children }: any) => <span data-test-id="cosmos-text">{children}</span>,
    Icon: ({ name }: any) => <span data-test-id={`cosmos-icon-${name}`} />,
    registerIcon: () => undefined,
    StyledText: 'span',
    StyledLink: 'a',
  };
});
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/user.icon', () => ({}), { virtual: true });
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/store.icon', () => ({}), { virtual: true });

describe('RB_Components_NetworkDiagram', () => {
  beforeAll(() => {
    (window as any).PCore = {
      getSemanticUrlUtils: () => ({
        getResolvedSemanticURL: () => '/case/1',
        getActions: () => ({ ACTION_OPENWORKBYHANDLE: 'OPEN' }),
      }),
    };
  });

  beforeEach(() => {
    (global as any).__rfStore = { nodeInternals: new Map() };
  });

  it('getEdgeParams returns positions and endpoints', () => {
    const a = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 0, y: 0 },
    };
    const b = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 300, y: 0 },
    };
    const out = getEdgeParams(a as any, b as any);
    expect(out).toEqual(
      expect.objectContaining({
        sx: expect.any(Number),
        sy: expect.any(Number),
        tx: expect.any(Number),
        ty: expect.any(Number),
        sourcePos: expect.any(String),
        targetPos: expect.any(String),
      }),
    );
  });

  it('getEdgeParams can return top and bottom positions', () => {
    const center = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 100, y: 100 },
    };
    const above = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 100, y: -150 },
    };
    const below = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 100, y: 350 },
    };

    const toAbove = getEdgeParams(center as any, above as any);
    const toBelow = getEdgeParams(center as any, below as any);

    expect(toAbove.sourcePos).toBe('Top');
    expect(toBelow.sourcePos).toBe('Bottom');
  });

  it('getEdgeParams falls back to top when nodes overlap', () => {
    const a = {
      width: 100,
      height: 100,
      positionAbsolute: { x: 0, y: 0 },
    };
    const out = getEdgeParams(a as any, a as any);
    expect(out.sourcePos).toBe('Top');
    expect(out.targetPos).toBe('Top');
  });

  it('CustomEdge chooses correct path algorithm and sets label class', async () => {
    const { default: CustomEdge } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/CustomEdge'
    );

    const { getByTestId, container, rerender } = render(
      <CustomEdge
        id="e1"
        source="s"
        target="t"
        sourceX={0}
        sourceY={0}
        targetX={100}
        targetY={100}
        sourcePosition={'Left' as any}
        targetPosition={'Right' as any}
        data={{ path: 'straight', label: 'L', type: 'FRIEND' }}
        markerStart={undefined}
        markerEnd={undefined}
      />,
    );
    expect(getByTestId('base-edge').getAttribute('data-path')).toBe('STRAIGHT');
    expect(container.querySelector('.custom-edge.nodrag.nopan.friend')?.textContent).toBe('L');

    rerender(
      <CustomEdge
        id="e2"
        source="s"
        target="t"
        sourceX={0}
        sourceY={0}
        targetX={100}
        targetY={100}
        sourcePosition={'Left' as any}
        targetPosition={'Right' as any}
        data={{ path: 'step', label: 'S' }}
        markerStart={undefined}
        markerEnd={undefined}
      />,
    );
    expect(getByTestId('base-edge').getAttribute('data-path')).toBe('STEP');

    rerender(
      <CustomEdge
        id="e3"
        source="s"
        target="t"
        sourceX={0}
        sourceY={0}
        targetX={100}
        targetY={100}
        sourcePosition={'Left' as any}
        targetPosition={'Right' as any}
        data={{ path: 'bezier', label: 'B' }}
        markerStart={undefined}
        markerEnd={undefined}
      />,
    );
    expect(getByTestId('base-edge').getAttribute('data-path')).toBe('BEZIER');
  });

  it('CustomNode renders link when key+objClass exist and uses icon by type', async () => {
    const openWorkByHandle = jest.fn();
    const showCasePreview = jest.fn();

    const { default: CustomNode } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/CustomNode'
    );

    const props: any = {
      data: {
        type: 'Corporation',
        key: 'HANDLE-1',
        objClass: 'My-Work',
        id: 'C-1',
        label: 'Corp',
        getPConnect: () => ({ getActionsApi: () => ({ openWorkByHandle, showCasePreview }) }),
        theme: { base: { palette: { 'foreground-color': '#000', 'primary-background': '#fff' } } },
      },
    };

    const { getByTestId } = render(<CustomNode {...props} />);
    expect(getByTestId('cosmos-icon-store')).toBeInTheDocument();

    const link = getByTestId('cosmos-link');
    fireEvent.click(link, { metaKey: false, ctrlKey: false, preventDefault: jest.fn() });
    expect(openWorkByHandle).toHaveBeenCalledWith('HANDLE-1', 'My-Work');
  });

  it('CustomNode triggers preview on hover and does not intercept meta/ctrl clicks', async () => {
    const openWorkByHandle = jest.fn();
    const showCasePreview = jest.fn();

    const { default: CustomNode } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/CustomNode'
    );

    const props: any = {
      data: {
        type: 'Person',
        key: 'HANDLE 1',
        objClass: 'My-Work',
        id: 'C-1',
        label: 'Person',
        getPConnect: () => ({ getActionsApi: () => ({ openWorkByHandle, showCasePreview }) }),
        theme: { base: { palette: { 'foreground-color': '#000', 'primary-background': '#fff' } } },
      },
    };

    const preventDefault = jest.fn();
    const { getByTestId } = render(<CustomNode {...props} />);
    expect(getByTestId('cosmos-icon-user')).toBeInTheDocument();

    const link = getByTestId('cosmos-link');
    fireEvent.mouseEnter(link);
    expect(showCasePreview).toHaveBeenCalledWith(encodeURI('HANDLE 1'), { caseClassName: 'My-Work' });

    fireEvent.click(link, { metaKey: true, ctrlKey: false, preventDefault });
    expect(preventDefault).not.toHaveBeenCalled();
    expect(openWorkByHandle).not.toHaveBeenCalled();
  });

  it('CustomNode renders Text when key or objClass is missing', async () => {
    const { default: CustomNode } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/CustomNode'
    );
    const props: any = {
      data: {
        type: 'Corporation',
        key: '',
        objClass: '',
        id: 'C-1',
        label: 'No link',
        getPConnect: () => ({ getActionsApi: () => ({ openWorkByHandle: jest.fn(), showCasePreview: jest.fn() }) }),
        theme: { base: { palette: { 'foreground-color': '#000', 'primary-background': '#fff' } } },
      },
    };
    const { getByTestId } = render(<CustomNode {...props} />);
    expect(getByTestId('cosmos-text')).toBeInTheDocument();
  });

  it('FloatingEdge returns null when nodes are missing', async () => {
    const { default: FloatingEdge } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/FloatingEdge'
    );
    const { container } = render(
      <FloatingEdge id="fe" source="a" target="b" markerEnd={undefined} data={{ label: 'x' }} />,
    );
    expect(container.firstChild).toBeNull();
  });

  it('FloatingEdge renders a path + label when nodes exist', async () => {
    (global as any).__rfStore.nodeInternals.set('a', {
      width: 100,
      height: 100,
      positionAbsolute: { x: 0, y: 0 },
    });
    (global as any).__rfStore.nodeInternals.set('b', {
      width: 100,
      height: 100,
      positionAbsolute: { x: 300, y: 0 },
    });

    const { default: FloatingEdge } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/FloatingEdge'
    );
    const { container } = render(
      <FloatingEdge
        id="fe2"
        source="a"
        target="b"
        markerEnd="m"
        data={{ label: 'Edge', type: 'FRIEND' }}
      />,
    );
    expect(container.querySelector('path.react-flow__edge-path')).toBeTruthy();
    expect(container.querySelector('.custom-edge.nodrag.nopan.friend')?.textContent).toBe('Edge');
  });
});

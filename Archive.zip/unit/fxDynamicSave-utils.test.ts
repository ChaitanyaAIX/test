jest.mock('uuid', () => ({
  v4: jest.fn(() => 'UUID-1'),
}));

import {
  extractVisibilityValue,
  findMatchingContextValue,
  getKeyForMappedField,
} from '../../src/components/custom-sdk/template/FusionAIX_Components_fxDynamicSave/utils';

describe('FusionAIX_Components_fxDynamicSave/utils', () => {
  describe('mapStateToProps', () => {
    it('returns visibility and getPConnect from ownProps', async () => {
      const getComputedVisibility = jest.fn(() => true);
      const getPConnect = jest.fn(() => ({ getComputedVisibility }));
      const { mapStateToProps } = await import(
        '../../src/components/custom-sdk/template/FusionAIX_Components_fxDynamicSave/utils'
      );
      expect(mapStateToProps({}, { getPConnect })).toEqual({
        visibility: true,
        getPConnect,
      });
    });
  });

  describe('extractVisibilityValue', () => {
    it('extracts the quoted value from a visibility condition', () => {
      expect(extractVisibilityValue("@E .SelectProvider == 'Vehicle'")).toBe('Vehicle');
    });

    it('returns null when no quoted value is present', () => {
      expect(extractVisibilityValue('@E .SelectProvider == Vehicle')).toBeNull();
    });
  });

  describe('findMatchingContextValue', () => {
    it('returns dotted values to delete when base non-dotted value exists', () => {
      const condition = "@E .SelectProvider == 'Vehicle'";
      const contextValues = ['Vehicle', '.VehicleDetails', '.PersonalDetails'];
      expect(findMatchingContextValue(condition, contextValues)).toEqual(['.PersonalDetails']);
    });

    it('returns dotted values matching compare value when base non-dotted value does not exist', () => {
      const condition = "@E .SelectProvider == 'Vehicle'";
      const contextValues = ['.VehicleDetails', '.PersonalDetails'];
      expect(findMatchingContextValue(condition, contextValues)).toEqual(['.VehicleDetails']);
    });

    it('returns empty when no extractable compare value exists', () => {
      expect(findMatchingContextValue('@E something', ['.VehicleDetails'])).toEqual([]);
    });
  });

  describe('getKeyForMappedField', () => {
    const mkField = (meta: any) => ({
      getPConnect: () => ({ meta }),
    });

    it('creates a key from meta.type + meta.config.name', () => {
      const field = mkField({ type: 'T', config: { name: 'N' } });
      expect(getKeyForMappedField(field)).toBe('T_N');
    });

    it('creates a key from meta.type + meta.config.label', () => {
      const field = mkField({ type: 'T', config: { label: 'L' } });
      expect(getKeyForMappedField(field)).toBe('T_L');
    });

    it('falls back to uuidv4 when metadata is missing', () => {
      const field = mkField(null);
      expect(getKeyForMappedField(field)).toBe('UUID-1');
    });

    it('supports nested arrays by joining keys with "__"', () => {
      const field1 = mkField({ type: 'A', config: { name: 'X' } });
      const field2 = mkField({ type: 'B', config: { label: 'Y' } });
      expect(getKeyForMappedField([field1, field2])).toBe('A_X__B_Y');
    });
  });
});


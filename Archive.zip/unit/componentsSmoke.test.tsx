import React from 'react';
import { render } from '@testing-library/react';
// Note: we intentionally keep styling concerns out of this smoke test.

jest.mock('@pega/cosmos-react-core', () => require('./__mocks__/cosmosReactCore'));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/reset.icon', () => ({}), { virtual: true });
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/user.icon', () => ({}), { virtual: true });
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/store.icon', () => ({}), { virtual: true });

jest.mock('@mui/styles/makeStyles', () => {
  return () => () => ({
    buttonContainer: 'buttonContainer',
    actionButton: 'actionButton',
  });
});
jest.mock('@mui/material/Button', () => {
  const React = require('react');
  return ({ children, onClick }: any) => (
    <button type="button" onClick={onClick}>
      {children}
    </button>
  );
});
jest.mock('@mui/material/Box', () => {
  const React = require('react');
  return ({ children, ...rest }: any) => <div {...rest}>{children}</div>;
});

jest.mock('../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/styles', () => {
  const React = require('react');
  return ({ children }: any) => <div data-mock="NetworkDiagramStyles">{children}</div>;
});

jest.mock('reactflow', () => {
  const React = require('react');
  return {
    __esModule: true,
    default: ({ children }: any) => <div data-mock="ReactFlow">{children}</div>,
    ReactFlowProvider: ({ children }: any) => <div data-mock="ReactFlowProvider">{children}</div>,
    MiniMap: () => <div data-mock="MiniMap" />,
    Controls: () => <div data-mock="Controls" />,
    MarkerType: { ArrowClosed: 'ArrowClosed' },
    ConnectionMode: { Loose: 'Loose' },
    useReactFlow: () => ({ fitView: jest.fn() }),
    useNodesState: () => [[], jest.fn(), jest.fn()],
    useEdgesState: () => [[], jest.fn(), jest.fn()],
  };
});

// Minimal PCore/Window stubs so components can mount without real Pega runtime.
const makePConnect = (overrides: Partial<any> = {}) => ({
  getValue: jest.fn(() => null),
  getContextName: jest.fn(() => 'CTX'),
  getLocalizedValue: jest.fn((s: string) => s),
  getActionsApi: jest.fn(() => ({ openLocalAction: jest.fn() })),
  getContainerManager: jest.fn(() => ({
    addContainerItem: jest.fn(),
    removeContainerItem: jest.fn(),
  })),
  getDataObject: jest.fn(() => ({ caseInfo: {} })),
  updateState: jest.fn(),
  ...overrides,
});

beforeAll(() => {
  (global as any).PCore = {
    getConstants: () => ({
      CASE_INFO: { AVAILABLEACTIONS: 'availableActions', CASE_INFO_ID: 'caseId', CASE_INFO_CLASSID: 'classId' },
    }),
  };
  (window as any).PCore = {
    ...(global as any).PCore,
    getConstants: (global as any).PCore.getConstants,
    getDataPageUtils: () => ({ getPageDataAsync: jest.fn(async () => ({ pyNodes: [], pyEdges: [] })) }),
    getDataApiUtils: () => ({
      getData: jest.fn(async () => ({ data: { data: [] } })),
      getCaseEditLock: jest.fn(async () => ({ headers: { etag: 'E' } })),
    }),
    getContainerUtils: () => ({
      updateCaseContextEtag: jest.fn(),
      getContainerItems: jest.fn(() => ({ a: {}, b: {} })),
    }),
    getMessagingServiceManager: () => ({
      subscribe: jest.fn(() => 'sub-id'),
      unsubscribe: jest.fn(),
    }),
    getRestClient: () => ({
      invokeRestApi: jest.fn(async () => ({ data: { data: { caseInfo: {} } } })),
    }),
    createPConnect: jest.fn(() => ({
      getPConnect: () => ({
        getActionsApi: () => ({ finishAssignment: jest.fn(async () => undefined) }),
        getContextName: () => 'TMP',
      }),
    })),
  };
});

// Smoke-test the primary component entrypoints (index.tsx files).
describe('components smoke', () => {
  it('renders custom-sdk components without crashing (with mocks)', async () => {
    const pConn = makePConnect({
      getValue: jest.fn((key: string) => {
        if (key === (global as any).PCore.getConstants().CASE_INFO.AVAILABLEACTIONS) {
          return [{ ID: 'A1', name: 'Do thing', type: 'local', links: { open: {} } }];
        }
        return null;
      }),
    });

    const DynamicActions = (await import('../../src/components/custom-sdk/widget/FusionAIX_Components_DynamicActions/index')).default;
    render(<DynamicActions {...({ getPConnect: () => pConn } as any)} />);

    const { RBComponentsBanner } = await import('../../src/components/custom-sdk/template/RB_Components_Banner/index');
    render(<RBComponentsBanner {...({ variant: 'success', getPConnect: () => pConn } as any)} />);

    const { default: NetworkDiagram } = await import('../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/index');
    render(<NetworkDiagram {...({ heading: 'H', dataPage: 'D', getPConnect: () => pConn } as any)} />);
  });
});


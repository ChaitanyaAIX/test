const mockSdkSetAuthHeader = jest.fn();
const mockSdkSetCustomTokenParamsCB = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  sdkSetAuthHeader: (...args: any[]) => mockSdkSetAuthHeader(...args),
  sdkSetCustomTokenParamsCB: (...args: any[]) => mockSdkSetCustomTokenParamsCB(...args),
}));

describe('src/samples/Embedded/utils.initializeAuthentication', () => {
  beforeEach(() => {
    jest.resetModules();
    mockSdkSetAuthHeader.mockReset();
    mockSdkSetCustomTokenParamsCB.mockReset();
  });

  it('sets Basic auth header when grantType=none and customAuthType=Basic', async () => {
    const { initializeAuthentication } = await import('../../src/samples/Embedded/utils');

    // stable btoa/atob
    (window as any).atob = jest.fn(() => 'decodedPass');
    (window as any).btoa = jest.fn(() => 'encoded');

    initializeAuthentication({
      mashupGrantType: 'none',
      mashupClientId: '',
      customAuthType: 'Basic',
      mashupUserIdentifier: 'user',
      mashupPassword: 'ignoredBase64',
    });

    expect(window.atob).toHaveBeenCalledWith('ignoredBase64');
    expect(window.btoa).toHaveBeenCalledWith('user:decodedPass');
    expect(mockSdkSetAuthHeader).toHaveBeenCalledWith('Basic encoded');
  });

  it('sets BasicTO auth header with timestamp when grantType=none and customAuthType=BasicTO', async () => {
    jest.useFakeTimers().setSystemTime(new Date('2026-03-18T12:00:00.000Z'));
    const { initializeAuthentication } = await import('../../src/samples/Embedded/utils');

    (window as any).atob = jest.fn(() => 'decodedPass');
    (window as any).btoa = jest.fn(() => 'encodedTO');

    initializeAuthentication({
      mashupGrantType: 'none',
      mashupClientId: '',
      customAuthType: 'BasicTO',
      mashupUserIdentifier: 'user',
      mashupPassword: 'ignoredBase64',
    });

    // exp time is now + 5 minutes => 12:05:00Z, stripped of - and :
    expect(window.btoa).toHaveBeenCalledWith('user:decodedPass:20260318T120500Z');
    expect(mockSdkSetAuthHeader).toHaveBeenCalledWith('Basic encodedTO');

    jest.useRealTimers();
  });

  it('registers custom token params callback for customBearer + CustomIdentifier', async () => {
    const { initializeAuthentication } = await import('../../src/samples/Embedded/utils');

    initializeAuthentication({
      mashupGrantType: 'customBearer',
      customAuthType: 'CustomIdentifier',
      mashupUserIdentifier: 'operatorA',
    });

    expect(mockSdkSetCustomTokenParamsCB).toHaveBeenCalledTimes(1);
    const cb = mockSdkSetCustomTokenParamsCB.mock.calls[0][0];
    expect(cb()).toEqual({ userIdentifier: 'operatorA' });
  });
});

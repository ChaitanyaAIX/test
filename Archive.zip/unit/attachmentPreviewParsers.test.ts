import {
  MIME_EML,
  MIME_MSG,
  MIME_XLSX,
  EML_KIND,
  MSG_KIND,
} from '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewHelpers';

describe('attachmentPreviewParsers', () => {
  it('parsePostalMimeHtml handles text-only and empty payloads', async () => {
    jest.doMock('postal-mime', () =>
      jest.fn().mockImplementation(() => ({
        parse: jest.fn().mockResolvedValue({ text: 'plain body' }),
      })),
    );
    jest.doMock('xlsx', () => ({ read: jest.fn(), utils: { sheet_to_html: jest.fn() } }));
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({ parseMsgToHtml: jest.fn(() => ({ html: '' })) }),
    );

    let out = '';
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { parsePostalMimeHtml } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      out = 'PENDING';
      parsePostalMimeHtml(new Uint8Array([1])).then((v: string) => {
        out = v;
      });
    });
    await new Promise((r) => setTimeout(r, 0));
    expect(out).toContain('plain body');
  });

  it('handleMsgBytes uses parseMsgToHtml html when available', async () => {
    const parseMsgToHtmlMock = jest.fn(() => ({ html: '<p>hello</p>' }));

    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({ parseMsgToHtml: parseMsgToHtmlMock }),
    );
    jest.doMock('postal-mime', () => jest.fn().mockImplementation(() => ({ parse: jest.fn() })));
    jest.doMock('xlsx', () => ({ read: jest.fn(), utils: { sheet_to_html: jest.fn() } }));

    let promise: Promise<void> | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { handleMsgBytes } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      const setSelectedKind = jest.fn();
      const setEmailHtml = jest.fn();
      const setNonPdfBytes = jest.fn();
      const setNonPdfMime = jest.fn();

      promise = handleMsgBytes(
        new Uint8Array([1, 2, 3]),
        setSelectedKind,
        setEmailHtml,
        setNonPdfBytes,
        setNonPdfMime,
      );

      (promise as any).__assertions = {
        setSelectedKind,
        setEmailHtml,
        setNonPdfBytes,
        setNonPdfMime,
      };
    });

    await promise;
    const assertions = (promise as any).__assertions;

    expect(assertions.setSelectedKind).toHaveBeenCalledWith(MSG_KIND);
    expect(assertions.setEmailHtml).toHaveBeenCalledWith('<p>hello</p>', MIME_MSG);
    expect(assertions.setNonPdfBytes).not.toHaveBeenCalled();
    expect(assertions.setNonPdfMime).not.toHaveBeenCalled();
  });

  it('handleEmlBytes falls back to decodeSmart+inject when PostalMime parsing fails', async () => {
    const postalMimeParseMock = jest.fn(() => Promise.reject(new Error('postal mime fail')));

    jest.doMock('postal-mime', () => jest.fn().mockImplementation(() => ({ parse: postalMimeParseMock })));

    // Override only the helper fns we depend on; keep MIME constants from the real module.
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewHelpers',
      () => {
        const actual = jest.requireActual(
          '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewHelpers',
        );
        return {
          ...actual,
          decodeSmart: jest.fn(() => '<p>decoded</p>'),
          parseRfc822Headers: jest.fn(() => ({})),
          pickEmailMetaFromHeaders: jest.fn(() => ({ meta: 'x' })),
          isHtmlString: jest.fn(() => true),
          preWrap: jest.fn((s: string) => `WRAPPED:${s}`),
          injectEmailMetaIntoHtml: jest.fn(() => 'INJECTED'),
        };
      },
    );
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({ parseMsgToHtml: jest.fn(() => ({ html: '' })) }),
    );
    jest.doMock('xlsx', () => ({ read: jest.fn(), utils: { sheet_to_html: jest.fn() } }));

    let promise: Promise<void> | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { handleEmlBytes } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      const setSelectedKind = jest.fn();
      const setEmailHtml = jest.fn();
      const setNonPdfBytes = jest.fn();
      const setNonPdfMime = jest.fn();

      promise = handleEmlBytes(
        new Uint8Array([0, 1, 2, 3]),
        'fallback/type',
        setSelectedKind,
        setEmailHtml,
        setNonPdfBytes,
        setNonPdfMime,
      );

      (promise as any).__assertions = {
        setSelectedKind,
        setEmailHtml,
        setNonPdfBytes,
        setNonPdfMime,
      };
    });

    await promise;
    const assertions = (promise as any).__assertions;

    expect(assertions.setSelectedKind).toHaveBeenCalledWith(EML_KIND);
    expect(assertions.setEmailHtml).toHaveBeenCalledWith('INJECTED', MIME_EML);
    expect(assertions.setNonPdfBytes).not.toHaveBeenCalled();
    expect(assertions.setNonPdfMime).not.toHaveBeenCalled();
  });

  it('handleExcelBytes sets html preview and non-pdf mime on success', async () => {
    const readMock = jest.fn(() => ({
      SheetNames: ['Sheet1'],
      Sheets: { Sheet1: {} },
    }));
    const sheetToHtmlMock = jest.fn(() => '<table><tr><th>H</th><td>1</td></tr></table>');

    jest.doMock('xlsx', () => ({
      read: readMock,
      utils: { sheet_to_html: sheetToHtmlMock },
    }));
    jest.doMock('postal-mime', () => jest.fn().mockImplementation(() => ({ parse: jest.fn() })));
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({ parseMsgToHtml: jest.fn(() => ({ html: '' })) }),
    );

    let promise: Promise<void> | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { handleExcelBytes } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      const setHtmlPreview = jest.fn();
      const setNonPdfBytes = jest.fn();
      const setNonPdfMime = jest.fn();

      promise = handleExcelBytes(
        new Uint8Array([7, 8, 9]),
        setHtmlPreview,
        setNonPdfBytes,
        setNonPdfMime,
      );
      (promise as any).__assertions = { setHtmlPreview, setNonPdfBytes, setNonPdfMime };
    });

    await promise;
    const assertions = (promise as any).__assertions;
    expect(readMock).toHaveBeenCalled();
    expect(sheetToHtmlMock).toHaveBeenCalled();
    expect(assertions.setHtmlPreview).toHaveBeenCalledWith(
      expect.stringContaining('position:sticky'),
    );
    expect(assertions.setNonPdfBytes).toHaveBeenCalledWith(null);
    expect(assertions.setNonPdfMime).toHaveBeenCalledWith(MIME_XLSX);
  });

  it('handleExcelBytes sets raw bytes and non-pdf mime on failure', async () => {
    const readMock = jest.fn(() => {
      throw new Error('bad xlsx');
    });

    jest.doMock('xlsx', () => ({
      read: readMock,
      utils: { sheet_to_html: jest.fn() },
    }));
    jest.doMock('postal-mime', () => jest.fn().mockImplementation(() => ({ parse: jest.fn() })));
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({ parseMsgToHtml: jest.fn(() => ({ html: '' })) }),
    );

    let promise: Promise<void> | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { handleExcelBytes } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      const setHtmlPreview = jest.fn();
      const setNonPdfBytes = jest.fn();
      const setNonPdfMime = jest.fn();
      const bytes = new Uint8Array([1, 1, 1]);

      promise = handleExcelBytes(bytes, setHtmlPreview, setNonPdfBytes, setNonPdfMime);
      (promise as any).__assertions = { setNonPdfBytes, setNonPdfMime, bytes };
    });

    await promise;
    const assertions = (promise as any).__assertions;
    expect(assertions.setNonPdfBytes).toHaveBeenCalledWith(assertions.bytes);
    expect(assertions.setNonPdfMime).toHaveBeenCalledWith(MIME_XLSX);
  });

  it('handleMsgBytes falls back to raw bytes when all parsing fails', async () => {
    jest.doMock(
      '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview',
      () => ({
        parseMsgToHtml: jest.fn(() => {
          throw new Error('msg failed');
        }),
      }),
    );
    jest.doMock('postal-mime', () =>
      jest.fn().mockImplementation(() => ({
        parse: jest.fn(() => Promise.reject(new Error('postal failed'))),
      })),
    );
    jest.doMock('xlsx', () => ({ read: jest.fn(), utils: { sheet_to_html: jest.fn() } }));
    const originalTextDecoder = (global as any).TextDecoder;
    (global as any).TextDecoder = class {
      // eslint-disable-next-line class-methods-use-this
      decode() {
        throw new Error('decode failed');
      }
    };

    let promise: Promise<void> | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const { handleMsgBytes } = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers');
      const setSelectedKind = jest.fn();
      const setEmailHtml = jest.fn();
      const setNonPdfBytes = jest.fn();
      const setNonPdfMime = jest.fn();
      const bytes = new Uint8Array([9, 9]);
      promise = handleMsgBytes(bytes, setSelectedKind, setEmailHtml, setNonPdfBytes, setNonPdfMime);
      (promise as any).__assertions = { setNonPdfBytes, setNonPdfMime, bytes };
    });

    await promise;
    const assertions = (promise as any).__assertions;
    expect(assertions.setNonPdfBytes).toHaveBeenCalledWith(assertions.bytes);
    expect(assertions.setNonPdfMime).toHaveBeenCalledWith(MIME_MSG);
    (global as any).TextDecoder = originalTextDecoder;
  });
});


import React from 'react';
import { fireEvent, render } from '@testing-library/react';

const mockLogout = jest.fn(async () => undefined);

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  logout: () => mockLogout(),
}));

describe('src/samples/FullPortal/InvalidPortal', () => {
  beforeEach(() => {
    mockLogout.mockClear();
  });

  it('calls onSelect when a portal is clicked', async () => {
    const onSelect = jest.fn();
    const { default: InvalidPortal } = await import('../../src/samples/FullPortal/InvalidPortal');

    const { getByText } = render(
      <InvalidPortal defaultPortal="D1" portals={['P1', 'P2']} onSelect={onSelect} />,
    );

    fireEvent.click(getByText('P2'));
    expect(onSelect).toHaveBeenCalledWith('P2');
  });

  it('logs out and reloads the page when Logout is clicked', async () => {
    const onSelect = jest.fn();
    const { default: InvalidPortal } = await import('../../src/samples/FullPortal/InvalidPortal');

    const reload = jest.fn();
    Object.defineProperty(window, 'location', {
      value: { reload },
      writable: true,
    });

    const { getByText } = render(
      <InvalidPortal defaultPortal="D1" portals={['P1']} onSelect={onSelect} />,
    );

    fireEvent.click(getByText('Logout'));
    expect(mockLogout).toHaveBeenCalledTimes(1);

    // resolve the promise chain
    await Promise.resolve();
    await Promise.resolve();

    expect(reload).toHaveBeenCalledTimes(1);
  });
});

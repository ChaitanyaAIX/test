import React from 'react';
import { render } from '@testing-library/react';

describe('RB_Components_Banner/styles', () => {
  it('renders the styled wrapper (smoke)', async () => {
    const { default: Styles } = await import(
      '../../src/components/custom-sdk/template/RB_Components_Banner/styles'
    );
    const { container } = render(
      <Styles>
        <div>child</div>
      </Styles>,
    );
    expect(container.textContent).toContain('child');
  });
});


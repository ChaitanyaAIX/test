import React from 'react';

export const withConfiguration = (Component: any) => Component;
export const registerIcon = jest.fn();

export const Banner = ({ children }: any) => <div data-mock="Banner">{children}</div>;
export const Icon = (props: any) => <span data-mock="Icon" {...props} />;
export const Text = ({ children }: any) => <span data-mock="Text">{children}</span>;
export const Card = ({ children }: any) => <div data-mock="Card">{children}</div>;
export const CardHeader = ({ children }: any) => <div data-mock="CardHeader">{children}</div>;
export const CardContent = ({ children }: any) => <div data-mock="CardContent">{children}</div>;
export const Button = ({ children, onClick }: any) => (
  <button type="button" onClick={onClick}>
    {children}
  </button>
);
export const useTheme = () => ({ palette: { foregroundColor: '#000' } });


import React from 'react';
import { fireEvent, render, waitFor } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { loginIfNecessary, getAvailablePortals, SdkConfigAccess } from '@pega/auth/lib/sdk-auth-manager';
import { act } from 'react';

// FullPortal imports ESM-only @pega/* packages; mock them for Jest.
// We only mock `useNavigate` to avoid React Router internals requiring `Request`.
jest.mock('react-router', () => {
  const actual = jest.requireActual('react-router');
  return {
    ...actual,
    useNavigate: () => jest.fn(),
  };
});

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  SdkConfigAccess: { getSdkConfigServer: jest.fn(() => ({ appPortal: '', excludePortals: [] })) },
  loginIfNecessary: jest.fn(),
  getAvailablePortals: jest.fn(async () => ['P1']),
  logout: jest.fn(async () => undefined),
}));

jest.mock('@pega/react-sdk-components/lib/bridge/Context/StoreContext', () => {
  const React = require('react');
  return { __esModule: true, default: React.createContext({}) };
});
jest.mock('@pega/react-sdk-components/lib/bridge/react_pconnect', () => () => () => (
  <div data-mock="PConnect" />
));
jest.mock('@pega/react-sdk-components/lib/components/helpers/versionHelpers', () => ({
  compareSdkPCoreVersions: jest.fn(),
}));
jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => ({
  getSdkComponentMap: jest.fn(async () => ({})),
}));

describe('src/samples/FullPortal', () => {
  beforeEach(() => {
    (SdkConfigAccess.getSdkConfigServer as jest.Mock).mockImplementation(() => ({
      appPortal: '',
      excludePortals: [],
    }));
    (getAvailablePortals as jest.Mock).mockResolvedValue(['P1']);
  });

  it('loads portal when `portal` and `locale` are provided in query string', async () => {
    sessionStorage.clear();
    (global as any).PCore = {
      getStore: () => ({}),
      onPCoreReady: jest.fn((cb) =>
        cb({
          props: { foo: 'bar' },
          portalTarget: 'portal-target',
          styleSheetTarget: 'style-sheet-target',
        }),
      ),
      getEnvironmentInfo: () => ({ getDefaultPortal: () => 'DEFAULT' }),
    };
    (window as any).PCore = (global as any).PCore;
    (window as any).myLoadPortal = jest.fn();
    (window as any).myLoadDefaultPortal = jest.fn();

    const { default: FullPortal } = await import('../../../src/samples/FullPortal');

    const router = createMemoryRouter(
      [
        {
          path: '*',
          element: <FullPortal />,
        },
      ],
      { initialEntries: ['/portal?portal=P2&locale=nl'] },
    );

    const { container } = render(<RouterProvider router={router} />);
    expect(container.querySelector('#pega-root')).toBeTruthy();

    // Trigger the constellation ready callback (calls startPortal()).
    await act(async () => {
      fireEvent(document, new Event('SdkConstellationReady'));
    });

    // Should load the requested portal directly.
    await waitFor(() => {
      expect((window as any).myLoadPortal).toHaveBeenCalledWith('pega-root', 'P2', []);
    });
    expect(sessionStorage.getItem('isLoggedIn')).toBe('true');

    // RootComponent should render the mocked PConnect.
    await waitFor(() => {
      expect(container.querySelector('[data-mock="PConnect"]')).toBeTruthy();
    });

    // Redirect callback should login again with the locale override.
    await waitFor(() => expect(loginIfNecessary).toHaveBeenCalled());
    const firstLoginCallArg = (loginIfNecessary as jest.Mock).mock.calls[0]?.[0];
    expect(firstLoginCallArg).toEqual(
      expect.objectContaining({ appName: 'portal', mainRedirect: true, locale: 'nl' }),
    );
    const redirectDoneCB = firstLoginCallArg.redirectDoneCB;
    await act(async () => {
      redirectDoneCB();
    });

    expect(loginIfNecessary).toHaveBeenCalledWith(
      expect.objectContaining({ appName: 'portal', mainRedirect: true, locale: 'nl' }),
    );
  });

  it('loads appPortal from sdk config when query portal is missing', async () => {
    sessionStorage.clear();
    (global as any).PCore = {
      getStore: () => ({}),
      onPCoreReady: jest.fn((cb) => cb({ props: {}, portalTarget: 'pt', styleSheetTarget: 'st' })),
      getEnvironmentInfo: () => ({ getDefaultPortal: () => 'DEFAULT' }),
    };
    (window as any).PCore = (global as any).PCore;
    (window as any).myLoadPortal = jest.fn();
    (window as any).myLoadDefaultPortal = jest.fn();
    (SdkConfigAccess.getSdkConfigServer as jest.Mock).mockImplementation(() => ({
      appPortal: 'ConfiguredPortal',
      excludePortals: [],
    }));

    const { default: FullPortal } = await import('../../../src/samples/FullPortal');
    const router = createMemoryRouter([{ path: '*', element: <FullPortal /> }], {
      initialEntries: ['/portal'],
    });
    render(<RouterProvider router={router} />);

    await act(async () => {
      fireEvent(document, new Event('SdkConstellationReady'));
    });

    await waitFor(() => {
      expect((window as any).myLoadPortal).toHaveBeenCalledWith('pega-root', 'ConfiguredPortal', []);
    });
  });

  it('loads default portal when appPortal is missing and default is allowed', async () => {
    sessionStorage.clear();
    (global as any).PCore = {
      getStore: () => ({}),
      onPCoreReady: jest.fn((cb) => cb({ props: {}, portalTarget: 'pt', styleSheetTarget: 'st' })),
      getEnvironmentInfo: () => ({ getDefaultPortal: () => 'DEFAULT' }),
    };
    (window as any).PCore = (global as any).PCore;
    (window as any).myLoadPortal = jest.fn();
    (window as any).myLoadDefaultPortal = jest.fn();
    (SdkConfigAccess.getSdkConfigServer as jest.Mock).mockImplementation(() => ({
      appPortal: '',
      excludePortals: [],
    }));

    const { default: FullPortal } = await import('../../../src/samples/FullPortal');
    const router = createMemoryRouter([{ path: '*', element: <FullPortal /> }], {
      initialEntries: ['/portal'],
    });
    render(<RouterProvider router={router} />);

    await act(async () => {
      fireEvent(document, new Event('SdkConstellationReady'));
    });

    await waitFor(() => {
      expect((window as any).myLoadDefaultPortal).toHaveBeenCalledWith('pega-root', []);
    });
  });

  it('redirect callback falls back to undefined locale when none in session', async () => {
    sessionStorage.clear();
    (global as any).PCore = {
      getStore: () => ({}),
      onPCoreReady: jest.fn((cb) => cb({ props: {}, portalTarget: 'pt', styleSheetTarget: 'st' })),
      getEnvironmentInfo: () => ({ getDefaultPortal: () => 'DEFAULT' }),
    };
    (window as any).PCore = (global as any).PCore;
    (window as any).myLoadPortal = jest.fn();
    (window as any).myLoadDefaultPortal = jest.fn();
    (SdkConfigAccess.getSdkConfigServer as jest.Mock).mockImplementation(() => ({
      appPortal: 'ConfiguredPortal',
      excludePortals: [],
    }));

    const { default: FullPortal } = await import('../../../src/samples/FullPortal');
    const router = createMemoryRouter([{ path: '*', element: <FullPortal /> }], {
      initialEntries: ['/portal'],
    });
    render(<RouterProvider router={router} />);

    await waitFor(() => expect(loginIfNecessary).toHaveBeenCalled());
    const firstCallArg = (loginIfNecessary as jest.Mock).mock.calls[0]?.[0];
    await act(async () => {
      firstCallArg.redirectDoneCB();
    });

    expect(loginIfNecessary).toHaveBeenLastCalledWith(
      expect.objectContaining({ appName: 'portal', mainRedirect: true, locale: undefined }),
    );
  });

  it('renders portal selection screen when no portal can be loaded automatically', async () => {
    sessionStorage.clear();
    (global as any).PCore = {
      getStore: () => ({}),
      onPCoreReady: jest.fn((cb) => cb({ props: {}, portalTarget: 'pt', styleSheetTarget: 'st' })),
      getEnvironmentInfo: () => ({ getDefaultPortal: () => 'DEFAULT' }),
    };
    (window as any).PCore = (global as any).PCore;
    (window as any).myLoadPortal = jest.fn();
    (window as any).myLoadDefaultPortal = jest.fn();

    // Force the "portal selection screen" branch.
    (SdkConfigAccess.getSdkConfigServer as jest.Mock).mockImplementation(() => ({
      appPortal: '',
      excludePortals: ['DEFAULT'],
    }));
    (getAvailablePortals as jest.Mock).mockResolvedValue(['P1', 'P2']);

    const { default: FullPortal } = await import('../../../src/samples/FullPortal');
    const router = createMemoryRouter(
      [
        {
          path: '*',
          element: <FullPortal />,
        },
      ],
      { initialEntries: ['/portal'] },
    );

    const { container, getByText } = render(<RouterProvider router={router} />);
    expect(container.querySelector('#pega-root')).toBeTruthy();

    await act(async () => {
      fireEvent(document, new Event('SdkConstellationReady'));
    });

    // Selection screen should appear with available portals.
    expect(getByText('DEFAULT')).toBeTruthy();
    await waitFor(() => expect(getByText('P1')).toBeTruthy());

    // Clicking a portal calls loadSelectedPortal() which switches back and loads app-root.
    fireEvent.click(getByText('P1'));
    await waitFor(() =>
      expect((window as any).myLoadPortal).toHaveBeenCalledWith('app-root', 'P1', []),
    );
  });
});

import React from 'react';
import { act, render, screen, waitFor } from '@testing-library/react';

const loginIfNecessary = jest.fn();
const getSdkConfig = jest.fn();
const sdkSetAuthHeader = jest.fn();
const sdkSetCustomTokenParamsCB = jest.fn();

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  loginIfNecessary: (...args: any[]) => loginIfNecessary(...args),
  getSdkConfig: (...args: any[]) => getSdkConfig(...args),
  sdkSetAuthHeader: (...args: any[]) => sdkSetAuthHeader(...args),
  sdkSetCustomTokenParamsCB: (...args: any[]) => sdkSetCustomTokenParamsCB(...args),
}));

jest.mock('@pega/react-sdk-components/lib/bridge/Context/StoreContext', () => {
  const React = require('react');
  return { __esModule: true, default: React.createContext({}) };
});
jest.mock('@pega/react-sdk-components/lib/bridge/react_pconnect', () => () => () => (
  <div data-testid="pconnect-root">PConnect</div>
));
jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => ({
  getSdkComponentMap: jest.fn(async () => ({})),
}));

describe('Embedded context providers', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    getSdkConfig.mockResolvedValue({
      authConfig: {
        mashupGrantType: 'none',
        mashupClientId: '',
        customAuthType: 'Basic',
        mashupUserIdentifier: 'operator',
        mashupPassword: btoa('secret'),
      },
    });

    (global as any).myLoadMashup = jest.fn();
    (global as any).PCore = {
      getStore: jest.fn(() => ({})),
      onPCoreReady: jest.fn((cb) => cb({ props: { getPConnect: () => ({}) } })),
      getMashupApi: () => ({
        createCase: jest.fn(async () => undefined),
      }),
      getConstants: () => ({ APP: { APP: 'APP' } }),
      getEnvironmentInfo: () => ({
        environmentInfoObject: {
          pyCaseTypeList: [{ pyWorkTypeImplementationClassName: 'My-CaseType' }],
        },
      }),
    };
    (window as any).PCore = (global as any).PCore;
  });

  it('PegaAuthProvider initializes login and flips auth state on SdkConstellationReady', async () => {
    const { default: PegaAuthProvider, usePegaAuth } = await import(
      '../../../src/samples/Embedded/context/PegaAuthProvider'
    );

    const Consumer = () => {
      const { isAuthenticated } = usePegaAuth();
      return <div>{isAuthenticated ? 'AUTH' : 'NO_AUTH'}</div>;
    };

    render(
      <PegaAuthProvider>
        <Consumer />
      </PegaAuthProvider>,
    );

    await waitFor(() => expect(loginIfNecessary).toHaveBeenCalledWith({ appName: 'embedded', mainRedirect: false }));
    expect(sdkSetAuthHeader).toHaveBeenCalled();
    expect(screen.getByText('NO_AUTH')).toBeInTheDocument();

    document.dispatchEvent(new Event('SdkConstellationReady'));
    await waitFor(() => expect(screen.getByText('AUTH')).toBeInTheDocument());
  });

  it('updates auth state after SdkConstellationReady event', async () => {
    const { default: PegaAuthProvider, usePegaAuth } = await import(
      '../../../src/samples/Embedded/context/PegaAuthProvider'
    );
    const Consumer = () => {
      const { isAuthenticated } = usePegaAuth();
      return <div>{isAuthenticated ? 'AUTH' : 'NO_AUTH'}</div>;
    };
    render(
      <PegaAuthProvider>
        <Consumer />
      </PegaAuthProvider>,
    );

    await act(async () => {
      document.dispatchEvent(new Event('SdkConstellationReady'));
    });
    await waitFor(() => expect(screen.getByText('AUTH')).toBeInTheDocument());
  });
});


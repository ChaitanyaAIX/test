import React from 'react';
import { render } from '@testing-library/react';

jest.mock('../../../src/samples/AppSelector', () => {
  const React = require('react');
  return { __esModule: true, default: () => <div data-mock="AppSelector" /> };
});

describe('src/samples/TopLevelApp', () => {
  beforeEach(() => {
    sessionStorage.clear();
    document.body.innerHTML = '';
  });

  it('registers logout handler and clears the portal name on SdkLoggedOut', async () => {
    sessionStorage.setItem('rsdk_portalName', 'SomePortal');
    document.body.innerHTML = `<div id="pega-root"><div>Existing</div></div>`;

    const { default: TopLevelApp } = await import('../../../src/samples/TopLevelApp');
    render(<TopLevelApp />);

    document.dispatchEvent(new Event('SdkLoggedOut'));

    expect(sessionStorage.getItem('rsdk_portalName')).toBeNull();
    const pegaRoot = document.getElementById('pega-root');
    expect(pegaRoot?.textContent).toContain('You are logged out');
  });
});

import React from 'react';
import { render } from '@testing-library/react';
import { createMemoryRouter, RouterProvider } from 'react-router';

// AppSelector routes to Embedded/FullPortal; for this test we only validate router wiring.
jest.mock('../../../src/samples/Embedded', () => {
  const React = require('react');
  return { __esModule: true, default: () => <div data-mock="Embedded" /> };
});
jest.mock('../../../src/samples/FullPortal', () => {
  const React = require('react');
  return { __esModule: true, default: () => <div data-mock="FullPortal" /> };
});

describe('src/samples/AppSelector', () => {
  it('renders inside a memory router', async () => {
    const { default: AppSelector } = await import('../../../src/samples/AppSelector');

    const router = createMemoryRouter(
      [
        {
          path: '*',
          element: <AppSelector />,
        },
      ],
      { initialEntries: ['/'] },
    );

    const { container } = render(<RouterProvider router={router} />);
    expect(container.querySelector('[data-mock="Embedded"]')).toBeTruthy();
  });
});

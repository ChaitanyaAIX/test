import React, { useEffect } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { theme } from '../../../src/theme';

jest.mock('../../../src/samples/Embedded/context/PegaAuthProvider', () => ({
  usePegaAuth: () => ({ isAuthenticated: true }),
}));

jest.mock('@pega/react-sdk-components/lib/bridge/Context/StoreContext', () => {
  const React = require('react');
  return { __esModule: true, default: React.createContext({}) };
});
jest.mock('@pega/react-sdk-components/lib/bridge/react_pconnect', () => () => () => (
  <div data-testid="pconnect-root">PConnect</div>
));
jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => ({
  getSdkComponentMap: jest.fn(async () => ({})),
}));

describe('PegaReadyContext', () => {
  beforeEach(() => {
    (global as any).myLoadMashup = jest.fn();
    (global as any).PCore = {
      getStore: jest.fn(() => ({})),
      onPCoreReady: jest.fn((cb) => cb({ props: { getPConnect: () => ({}) } })),
      getMashupApi: () => ({
        createCase: jest.fn(async () => undefined),
      }),
      getConstants: () => ({ APP: { APP: 'APP' } }),
      getEnvironmentInfo: () => ({
        environmentInfoObject: {
          pyCaseTypeList: [{ pyWorkTypeImplementationClassName: 'My-CaseType' }],
        },
      }),
    };
    (window as any).PCore = (global as any).PCore;
  });

  it('starts mashup and createCase fallback uses first case type', async () => {
    const { PegaReadyProvider, usePega } = await import(
      '../../../src/samples/Embedded/context/PegaReadyContext'
    );

    const Consumer = () => {
      const { isPegaReady, createCase, PegaContainer } = usePega();
      useEffect(() => {
        createCase('', { pageName: 'pyEmbedAssignment', startingFields: {} } as any).catch(() => undefined);
      }, [createCase]);
      return (
        <div>
          <div>{isPegaReady ? 'READY' : 'NOT_READY'}</div>
          <PegaContainer />
        </div>
      );
    };

    render(
      <PegaReadyProvider theme={theme}>
        <Consumer />
      </PegaReadyProvider>,
    );

    await waitFor(() => expect((global as any).myLoadMashup).toHaveBeenCalledWith('pega-root', false));
    await waitFor(() => expect(screen.getByText('READY')).toBeInTheDocument());
  });
});


import React from 'react';
import { render } from '@testing-library/react';

// The real Embedded sample depends on Pega runtime; for unit testing we validate component wiring
// by mocking its providers and child components.
jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn(async () => ({ authConfig: {}, serverConfig: {} })),
  loginIfNecessary: jest.fn(),
  sdkSetAuthHeader: jest.fn(),
  sdkSetCustomTokenParamsCB: jest.fn(),
}));
jest.mock('@mui/styles/makeStyles', () => {
  return () => () => new Proxy({}, { get: (_t, p) => String(p) });
});

jest.mock('../../../src/samples/Embedded/context/PegaAuthProvider', () => {
  const React = require('react');
  return {
    __esModule: true,
    default: ({ children }: any) => <div data-mock="PegaAuthProvider">{children}</div>,
  };
});
jest.mock('../../../src/samples/Embedded/context/PegaReadyContext', () => {
  const React = require('react');
  return {
    __esModule: true,
    PegaReadyProvider: ({ children }: any) => <div data-mock="PegaReadyProvider">{children}</div>,
  };
});
jest.mock('../../../src/samples/Embedded/Header', () => {
  const React = require('react');
  return { __esModule: true, default: () => <div data-mock="Header" /> };
});
jest.mock('../../../src/samples/Embedded/MainScreen', () => {
  const React = require('react');
  return { __esModule: true, default: () => <div data-mock="MainScreen" /> };
});

describe('src/samples/Embedded', () => {
  it('renders with mocked providers without requiring PCore', async () => {
    const { default: Embedded } = await import('../../../src/samples/Embedded');
    const { container } = render(<Embedded />);
    expect(container.querySelector('[data-mock="Header"]')).toBeTruthy();
    expect(container.querySelector('[data-mock="MainScreen"]')).toBeTruthy();
  });
});

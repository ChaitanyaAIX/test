import React from 'react';
import { fireEvent, render, screen, waitFor } from '@testing-library/react';

jest.mock('@mui/styles', () => ({
  makeStyles: () => () => ({
    header: 'header',
    navContainer: 'navContainer',
    logo: 'logo',
    navMenu: 'navMenu',
    navMenuActive: 'navMenuActive',
    navList: 'navList',
    showNavListsOnMobile: 'showNavListsOnMobile',
    profileAvatar: 'profileAvatar',
    menuToggle: 'menuToggle',
    planCard: 'planCard',
    phoneImage: 'phoneImage',
    planName: 'planName',
    saveAmount: 'saveAmount',
    monthlyPrice: 'monthlyPrice',
    tenure: 'tenure',
    retailPrice: 'retailPrice',
    buyButton: 'buyButton',
    resolutionPage: 'resolutionPage',
    resolutionCard: 'resolutionCard',
    successImage: 'successImage',
    title: 'title',
    message: 'message',
    doneButton: 'doneButton',
    appContainer: 'appContainer',
    mainContentArea: 'mainContentArea',
    mainContainer: 'mainContainer',
    hero: 'hero',
    heroText: 'heroText',
    heroImage: 'heroImage',
    plansSection: 'plansSection',
    plansIntro: 'plansIntro',
    highlight: 'highlight',
    plansContainer: 'plansContainer',
    pegaViewContainer: 'pegaViewContainer',
    pegaForm: 'pegaForm',
  }),
}));

jest.mock('@pega/auth/lib/sdk-auth-manager', () => ({
  getSdkConfig: jest.fn(async () => ({
    serverConfig: { appMashupCaseType: 'DIXL-MediaCo-Work-PurchasePhone' },
  })),
}));

jest.mock('../../../src/samples/Embedded/ShoppingOptionCard', () => {
  const React = require('react');
  return {
    __esModule: true,
    default: ({ onClick, name }: any) => (
      <button type="button" data-test-id={`shop-${name}`} onClick={onClick}>
        {name}
      </button>
    ),
  };
});

const pegaAuthMock = { isAuthenticated: true };
const createCaseMock = jest.fn(async () => undefined);
const pegaContainerMock = () => <div data-testid="pega-container">PegaContainer</div>;

jest.mock('../../../src/samples/Embedded/context/PegaAuthProvider', () => ({
  usePegaAuth: () => pegaAuthMock,
}));

jest.mock('../../../src/samples/Embedded/context/PegaReadyContext', () => ({
  usePega: () => ({
    isPegaReady: true,
    PegaContainer: pegaContainerMock,
    createCase: createCaseMock,
  }),
}));

describe('Embedded component files', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (global as any).PCore = {
      getPubSubUtils: () => ({
        subscribe: jest.fn(),
        unsubscribe: jest.fn(),
      }),
      getConstants: () => ({
        PUB_SUB_EVENTS: {
          EVENT_CANCEL: 'EVENT_CANCEL',
          CASE_EVENTS: { END_OF_ASSIGNMENT_PROCESSING: 'END_OF_ASSIGNMENT_PROCESSING' },
        },
      }),
      getContainerUtils: () => ({
        getActiveContainerItemName: jest.fn(() => undefined),
      }),
      getStoreValue: jest.fn((path: string) => {
        if (path.includes('ModelName')) return 'Oceonix 25';
        if (path.includes('BillingAddress')) return '221B Baker Street';
        if (path.includes('EmailAddress')) return 'user@example.com';
        return '';
      }),
    };
    (window as any).PCore = (global as any).PCore;
  });

  it('renders Header and toggles menu class', async () => {
    const { default: Header } = await import('../../../src/samples/Embedded/Header');
    const { container } = render(<Header />);
    expect(screen.getByAltText('MediaCo Logo')).toBeInTheDocument();

    const menuButton = screen.getByLabelText('Open menu');
    fireEvent.click(menuButton);
    expect(container.querySelector('.navMenu.navMenuActive')).toBeTruthy();

    fireEvent.click(menuButton);
    expect(container.querySelector('.navMenu.navMenuActive')).toBeNull();
  });

  it('MainScreen shows loading when not authenticated', async () => {
    pegaAuthMock.isAuthenticated = false;
    const { default: MainScreen } = await import('../../../src/samples/Embedded/MainScreen');
    render(<MainScreen />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
    pegaAuthMock.isAuthenticated = true;
  });

  it('MainScreen creates case and renders embedded container after selecting a phone', async () => {
    const { default: MainScreen } = await import('../../../src/samples/Embedded/MainScreen');
    render(<MainScreen />);

    fireEvent.click(screen.getByText('Oceonix 25'));

    await waitFor(() => expect(createCaseMock).toHaveBeenCalledTimes(1));
    const [caseType, options] = ((createCaseMock.mock.calls[0] || []) as unknown) as [string, any];
    expect(caseType).toBe('DIXL-MediaCo-Work-PurchasePhone');
    expect(options.startingFields.PhoneModelss.pyGUID).toBe('0f670ae2-3e61-47d4-b426-edd62558cfb8');
    expect(screen.getByText('PegaContainer')).toBeInTheDocument();
  });
});


import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

jest.mock('@mui/styles', () => ({
  makeStyles: () => () => ({
    planCard: 'planCard',
    phoneImage: 'phoneImage',
    planName: 'planName',
    saveAmount: 'saveAmount',
    monthlyPrice: 'monthlyPrice',
    tenure: 'tenure',
    retailPrice: 'retailPrice',
    buyButton: 'buyButton',
    resolutionPage: 'resolutionPage',
    resolutionCard: 'resolutionCard',
    successImage: 'successImage',
    title: 'title',
    message: 'message',
    doneButton: 'doneButton',
  }),
}));

describe('Standalone Embedded components', () => {
  beforeEach(() => {
    (global as any).PCore = {
      getContainerUtils: () => ({
        getActiveContainerItemName: jest.fn(() => undefined),
      }),
      getStoreValue: jest.fn((path: string) => {
        if (path.includes('ModelName')) return 'Oceonix 25';
        if (path.includes('BillingAddress')) return '221B Baker Street';
        if (path.includes('EmailAddress')) return 'user@example.com';
        return '';
      }),
    };
    (window as any).PCore = (global as any).PCore;
  });

  it('ShoppingOptionCard calls onClick with level', async () => {
    const { default: ShoppingOptionCard } = await import(
      '../../../src/samples/Embedded/ShoppingOptionCard'
    );
    const onClick = jest.fn();
    render(
      <ShoppingOptionCard
        name="Phone A"
        imageSrc="/x.png"
        saveAmount="Save"
        monthlyPrice="$1"
        tenure="36m"
        retailPrice="$100"
        level="Gold"
        onClick={onClick}
      />,
    );
    fireEvent.click(screen.getByRole('button', { name: 'Buy now' }));
    expect(onClick).toHaveBeenCalledWith('Gold');
  });

  it('ResolutionScreen renders resolved store values', async () => {
    const { default: ResolutionScreen } = await import('../../../src/samples/Embedded/ResolutionScreen');
    render(<ResolutionScreen />);

    expect(screen.getByText(/Get excited for your new phone!/i)).toBeInTheDocument();
    expect(screen.getByText(/Oceonix 25/i)).toBeInTheDocument();
    expect(screen.getByText(/221B Baker Street/i)).toBeInTheDocument();
    expect(screen.getByText(/user@example.com/i)).toBeInTheDocument();
  });
});


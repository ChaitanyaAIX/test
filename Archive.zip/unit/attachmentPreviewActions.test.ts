import {
  handleSelectAttachment,
  openInlineMenuEdit,
  submitEdit,
  submitInlineMenuEdit,
} from '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewActions';

describe('attachmentPreviewActions', () => {
  beforeEach(() => {
    (window as any).PCore = {
      getAttachmentUtils: () => ({
        editAttachment: jest.fn(() => Promise.resolve(undefined)),
      }),
    };
  });

  it('openInlineMenuEdit initializes edit state from attachment + available categories', () => {
    const setEditingMenuIndex = jest.fn();
    const setMenuEditTitle = jest.fn();
    const setMenuEditCategory = jest.fn();

    openInlineMenuEdit({
      attachment: { name: 'My file', category: 'cat-2' } as any,
      index: 3,
      availableCategories: [
        { id: 'cat-1', label: 'One' },
        { id: 'cat-2', label: 'Two' },
      ],
      setEditingMenuIndex,
      setMenuEditTitle,
      setMenuEditCategory,
    });

    expect(setEditingMenuIndex).toHaveBeenCalledWith(3);
    expect(setMenuEditTitle).toHaveBeenCalledWith('My file');
    expect(setMenuEditCategory).toHaveBeenCalledWith('cat-2');
  });

  it('openInlineMenuEdit falls back to first category when provided category does not match', () => {
    const setEditingMenuIndex = jest.fn();
    const setMenuEditTitle = jest.fn();
    const setMenuEditCategory = jest.fn();

    openInlineMenuEdit({
      attachment: { name: 'My file', category: 'unknown' } as any,
      index: 0,
      availableCategories: [
        { id: 'cat-1', label: 'One' },
        { id: 'cat-2', label: 'Two' },
      ],
      setEditingMenuIndex,
      setMenuEditTitle,
      setMenuEditCategory,
    });

    expect(setMenuEditCategory).toHaveBeenCalledWith('cat-1');
  });

  it('openInlineMenuEdit uses empty category when no categories are provided', () => {
    const setEditingMenuIndex = jest.fn();
    const setMenuEditTitle = jest.fn();
    const setMenuEditCategory = jest.fn();

    openInlineMenuEdit({
      attachment: { name: 'My file', category: 'cat-2' } as any,
      index: 1,
      availableCategories: undefined,
      setEditingMenuIndex,
      setMenuEditTitle,
      setMenuEditCategory,
    });

    expect(setEditingMenuIndex).toHaveBeenCalledWith(1);
    expect(setMenuEditTitle).toHaveBeenCalledWith('My file');
    expect(setMenuEditCategory).toHaveBeenCalledWith('');
  });

  it('handleSelectAttachment routes non-pdf attachments to fetchNonPdf and opens preview', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'K1', name: 'a.docx', extension: 'docx' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setPdfData).toHaveBeenCalledWith(null);
    expect(setIsPreviewOpen).toHaveBeenCalledWith(true);
    expect(fetchNonPdf).toHaveBeenCalledWith('K1', 'docx', 'CTX', expect.any(String));
    expect(fetchPdf).not.toHaveBeenCalled();
    expect(setError).not.toHaveBeenCalled();
  });

  it('handleSelectAttachment uses docx/xlsx default mimes when mimeType is missing', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'W1', name: 'a.docx', extension: 'docx' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });
    expect(fetchNonPdf).toHaveBeenCalledWith(
      'W1',
      'docx',
      'CTX',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    );

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'X1', name: 'a.xlsx', extension: 'xlsx' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });
    expect(fetchNonPdf).toHaveBeenCalledWith(
      'X1',
      'xlsx',
      'CTX',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    );
  });

  it('handleSelectAttachment uses octet-stream mime for unknown non-pdf types', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'U1', name: 'a.bin', extension: 'bin' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(fetchNonPdf).toHaveBeenCalledWith('U1', 'bin', 'CTX', 'application/octet-stream');
  });

  it('handleSelectAttachment sets error when non-pdf attachment key is missing', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ name: 'a.docx', extension: 'docx' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setPdfData).toHaveBeenCalledWith(null);
    expect(setError).toHaveBeenCalledWith('Attachment key not found.');
    expect(fetchNonPdf).not.toHaveBeenCalled();
  });

  it('handleSelectAttachment infers MSG kind + mime when mimeType is octet-stream', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'K3', name: 'a.msg', mimeType: 'application/octet-stream' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setSelectedKind).toHaveBeenCalledWith('msg');
    expect(fetchNonPdf).toHaveBeenCalledWith('K3', undefined, 'CTX', 'application/vnd.ms-outlook');
  });

  it('handleSelectAttachment infers EML kind + mime when mimeType is octet-stream', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'K4', name: 'a.eml', mimeType: 'application/octet-stream' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setSelectedKind).toHaveBeenCalledWith('eml');
    expect(fetchNonPdf).toHaveBeenCalledWith('K4', undefined, 'CTX', 'message/rfc822');
  });

  it('handleSelectAttachment routes pdf attachments to fetchPdf and opens preview', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ pzInsKey: 'K2', name: 'a.pdf', extension: 'pdf' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setIsPreviewOpen).toHaveBeenCalledWith(true);
    expect(fetchPdf).toHaveBeenCalledWith('K2', 'CTX');
    expect(fetchNonPdf).not.toHaveBeenCalled();
    expect(setError).not.toHaveBeenCalled();
  });

  it('handleSelectAttachment sets an error when attachment key is missing', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 0,
      attachments: [{ name: 'a.pdf', extension: 'pdf' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setError).toHaveBeenCalledWith('Attachment key not found.');
    expect(fetchPdf).not.toHaveBeenCalled();
    expect(fetchNonPdf).not.toHaveBeenCalled();
  });

  it('handleSelectAttachment no-ops when selected index is out of range', async () => {
    const setSelectedKind = jest.fn();
    const setPdfData = jest.fn();
    const setError = jest.fn();
    const setIsPreviewOpen = jest.fn();
    const fetchNonPdf = jest.fn().mockResolvedValue(undefined);
    const fetchPdf = jest.fn().mockResolvedValue(undefined);

    await handleSelectAttachment({
      index: 99,
      attachments: [{ pzInsKey: 'K2', name: 'a.pdf', extension: 'pdf' }] as any,
      inferredContext: 'CTX',
      setSelectedKind,
      setPdfData,
      setError,
      setIsPreviewOpen,
      fetchNonPdf,
      fetchPdf,
    });

    expect(setIsPreviewOpen).not.toHaveBeenCalled();
    expect(fetchPdf).not.toHaveBeenCalled();
    expect(fetchNonPdf).not.toHaveBeenCalled();
  });

  it('submitInlineMenuEdit clears menu state and refreshes on success', async () => {
    const loadAttachments = jest.fn().mockResolvedValue(undefined);
    const notifyAttachmentUpdate = jest.fn();
    const setEditingMenuIndex = jest.fn();
    const setOpenMenuIndex = jest.fn();

    await submitInlineMenuEdit({
      attachment: { pzInsKey: 'K1', name: 't' } as any,
      menuEditTitle: 'New',
      menuEditCategory: 'cat-1',
      inferredContext: 'CTX',
      loadAttachments,
      notifyAttachmentUpdate,
      setEditingMenuIndex,
      setOpenMenuIndex,
    } as any);

    // promise chain, not awaited internally — flush microtasks
    await Promise.resolve();

    expect(setEditingMenuIndex).toHaveBeenCalledWith(null);
    expect(setOpenMenuIndex).toHaveBeenCalledWith(null);
    expect(loadAttachments).toHaveBeenCalled();
    expect(notifyAttachmentUpdate).toHaveBeenCalledWith('CTX');
  });

  it('submitInlineMenuEdit clears menu state on failure', async () => {
    (window as any).PCore = {
      getAttachmentUtils: () => ({
        editAttachment: jest.fn(() => Promise.reject(new Error('nope'))),
      }),
    };
    const loadAttachments = jest.fn().mockResolvedValue(undefined);
    const notifyAttachmentUpdate = jest.fn();
    const setEditingMenuIndex = jest.fn();
    const setOpenMenuIndex = jest.fn();

    await submitInlineMenuEdit({
      attachment: { pzInsKey: 'K1', name: 't' } as any,
      menuEditTitle: 'New',
      menuEditCategory: 'cat-1',
      inferredContext: 'CTX',
      loadAttachments,
      notifyAttachmentUpdate,
      setEditingMenuIndex,
      setOpenMenuIndex,
    } as any);

    await Promise.resolve();
    expect(setEditingMenuIndex).toHaveBeenCalledWith(null);
    expect(setOpenMenuIndex).toHaveBeenCalledWith(null);
    expect(loadAttachments).not.toHaveBeenCalled();
    expect(notifyAttachmentUpdate).not.toHaveBeenCalled();
  });

  it('submitEdit publishes ATTACHMENT_PREVIEW_UPDATE when caseID exists', async () => {
    const editAttachment = jest.fn(() => Promise.resolve(undefined));
    const publish = jest.fn();
    const PCore = {
      getAttachmentUtils: () => ({ editAttachment }),
      getEnvironmentInfo: () => ({ getKeyMapping: (_v: string) => undefined }),
      getStoreValue: () => 'CASE-1',
      getResolvedConstantValue: () => 'caseInfo.content',
      getPubSubUtils: () => ({ publish }),
    };

    const setIsEditOpen = jest.fn();
    const setEditTarget = jest.fn();
    const loadAttachments = jest.fn().mockResolvedValue(undefined);
    const notifyAttachmentUpdate = jest.fn();

    await submitEdit({
      editTarget: { pzInsKey: 'K1', name: 't' } as any,
      editTitle: 'T',
      editCategory: 'C',
      inferredContext: 'CTX',
      loadAttachments,
      notifyAttachmentUpdate,
      setIsEditOpen,
      setEditTarget,
      PCore,
    } as any);

    await Promise.resolve();
    expect(setIsEditOpen).toHaveBeenCalledWith(false);
    expect(setEditTarget).toHaveBeenCalledWith(null);
    expect(publish).toHaveBeenCalledWith('ATTACHMENT_PREVIEW_UPDATE', 'CASE-1');
  });

  it('submitEdit clears edit state on failure', async () => {
    const editAttachment = jest.fn(() => Promise.reject(new Error('nope')));
    const PCore = {
      getAttachmentUtils: () => ({ editAttachment }),
    };
    const setIsEditOpen = jest.fn();
    const setEditTarget = jest.fn();
    const loadAttachments = jest.fn().mockResolvedValue(undefined);
    const notifyAttachmentUpdate = jest.fn();

    await submitEdit({
      editTarget: { pzInsKey: 'K1', name: 't' } as any,
      editTitle: 'T',
      editCategory: 'C',
      inferredContext: 'CTX',
      loadAttachments,
      notifyAttachmentUpdate,
      setIsEditOpen,
      setEditTarget,
      PCore,
    } as any);

    await Promise.resolve();
    expect(setIsEditOpen).toHaveBeenCalledWith(false);
    expect(setEditTarget).toHaveBeenCalledWith(null);
    expect(loadAttachments).not.toHaveBeenCalled();
  });

  it('submitEdit returns early when editTarget is null', async () => {
    const setIsEditOpen = jest.fn();
    const setEditTarget = jest.fn();
    const loadAttachments = jest.fn().mockResolvedValue(undefined);
    const notifyAttachmentUpdate = jest.fn();

    await submitEdit({
      editTarget: null,
      editTitle: 'T',
      editCategory: 'C',
      inferredContext: 'CTX',
      loadAttachments,
      notifyAttachmentUpdate,
      setIsEditOpen,
      setEditTarget,
      PCore: {},
    } as any);

    expect(setIsEditOpen).not.toHaveBeenCalled();
    expect(setEditTarget).not.toHaveBeenCalled();
  });
});

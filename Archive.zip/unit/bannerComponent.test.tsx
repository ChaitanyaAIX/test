import React from 'react';
import { fireEvent, render, waitFor } from '@testing-library/react';

jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    withConfiguration: (c: any) => c,
    Banner: ({ messages, onDismiss }: any) => (
      <div>
        <span data-test-id="banner-messages">{(messages || []).join(',')}</span>
        {onDismiss ? (
          <button type="button" onClick={onDismiss}>
            Dismiss
          </button>
        ) : null}
      </div>
    ),
  };
});

jest.mock('../../src/components/custom-sdk/template/RB_Components_Banner/styles', () => {
  const React = require('react');
  return ({ children }: any) => <div data-testid="banner-wrap">{children}</div>;
});

describe('RB_Components_Banner/index', () => {
  const mkPConn = () => {
    const openLocalAction = jest.fn();
    return {
      getValue: jest.fn((k: string) => (k.includes('CASE_INFO_ID') ? 'CASE-1' : 'My-Case')),
      getContextName: jest.fn(() => 'CTX'),
      getDataObject: jest.fn(() => ({ caseInfo: { content: {} } })),
      getContainerManager: jest.fn(() => ({
        addContainerItem: jest.fn(),
        removeContainerItem: jest.fn(),
      })),
      updateState: jest.fn(),
      getActionsApi: jest.fn(() => ({ openLocalAction })),
    };
  };

  beforeEach(() => {
    (window as any).PCore = {
      getConstants: () => ({ CASE_INFO: { CASE_INFO_ID: 'CASE_INFO_ID', CASE_INFO_CLASSID: 'CASE_INFO_CLASSID' } }),
      getDataApiUtils: () => ({
        getData: jest.fn(async () => ({ data: { data: [{ pyDescription: 'M1' }] } })),
        getCaseEditLock: jest.fn(async () => ({ headers: { etag: 'E1' } })),
      }),
      getRestClient: () => ({
        invokeRestApi: jest.fn(async () => ({ data: { data: { caseInfo: {} } } })),
      }),
      getContainerUtils: () => ({
        getContainerItems: jest.fn(() => ({ a: {}, b: {} })),
        updateCaseContextEtag: jest.fn(),
      }),
      getMessagingServiceManager: () => ({
        subscribe: jest.fn(() => 'sub-1'),
        unsubscribe: jest.fn(),
      }),
      createPConnect: () => ({
        getPConnect: () => ({
          getActionsApi: () => ({ finishAssignment: jest.fn(async () => undefined) }),
          getContextName: () => 'TMP',
        }),
      }),
    };
  });

  it('loads data-page messages and renders banner', async () => {
    const { default: BannerCmp } = await import(
      '../../src/components/custom-sdk/template/RB_Components_Banner'
    );
    const pConn = mkPConn();
    const { getByTestId } = render(
      <BannerCmp variant="success" dataPage="D_Messages" dismissible getPConnect={() => pConn} />,
    );

    await waitFor(() => expect(getByTestId('banner-messages').textContent).toContain('M1'));
  });

  it('supports dismiss without dismissAction', async () => {
    const { default: BannerCmp } = await import(
      '../../src/components/custom-sdk/template/RB_Components_Banner'
    );
    const pConn = mkPConn();
    const { getByText } = render(
      <BannerCmp variant="info" dataPage="D_Messages" dismissible getPConnect={() => pConn} />,
    );
    await waitFor(() => getByText('Dismiss'));
    fireEvent.click(getByText('Dismiss'));
  });
});


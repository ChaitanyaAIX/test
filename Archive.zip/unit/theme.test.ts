describe('src/theme', () => {
  beforeEach(() => {
    jest.resetModules();
  });

  it('exports the dark theme when sdk-config.json sets theme=dark', async () => {
    jest.doMock('../../sdk-config.json', () => ({ theme: 'dark' }), { virtual: true });

    const { theme } = await import('../../src/theme');

    expect(theme.palette.mode).toBe('dark');
    // sanity check: dark theme sets CssBaseline body background override
    const cssBaseline = (theme.components as any)?.MuiCssBaseline?.styleOverrides;
    expect(cssBaseline?.body?.background).toContain('radial-gradient');
    // and sets dark svg invert
    expect(cssBaseline?.[':root']?.['--svg-color']).toBe('invert(100%)');
  });

  it('exports the light theme when sdk-config.json is missing theme or not dark', async () => {
    jest.doMock('../../sdk-config.json', () => ({}), { virtual: true });

    const { theme } = await import('../../src/theme');

    // MUI defaults palette.mode to 'light' when not specified
    expect(theme.palette.mode).toBe('light');
    const cssBaseline = (theme.components as any)?.MuiCssBaseline?.styleOverrides;
    expect(cssBaseline?.[':root']?.['--app-primary-color']).toBe('#007bff');
    expect(cssBaseline?.[':root']?.['--svg-color']).toBe('invert(0%)');
  });
});

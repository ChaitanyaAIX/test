import React from 'react';
import { fireEvent, render, waitFor } from '@testing-library/react';

jest.mock('@dagrejs/dagre', () => ({
  graphlib: {
    Graph: class {
      setDefaultEdgeLabel() {}
      setGraph() {}
      setNode() {}
      setEdge() {}
      node() {
        return { x: 100, y: 100 };
      }
    },
  },
  layout: jest.fn(),
}));

jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    withConfiguration: (c: any) => c,
    registerIcon: jest.fn(),
    Icon: () => <span data-testid="icon-reset" />,
    Text: ({ children }: any) => <span>{children}</span>,
    Card: ({ children }: any) => <div>{children}</div>,
    CardHeader: ({ children, actions }: any) => (
      <div>
        {actions}
        {children}
      </div>
    ),
    CardContent: ({ children }: any) => <div>{children}</div>,
    Button: ({ children, onClick }: any) => (
      <button type="button" onClick={onClick}>
        {children}
      </button>
    ),
    useTheme: () => ({ palette: { foregroundColor: '#000' } }),
  };
});

jest.mock('reactflow', () => {
  const React = require('react');
  return {
    __esModule: true,
    default: ({ children }: any) => <div data-testid="rf">{children}</div>,
    useNodesState: () => [[], jest.fn(), jest.fn()],
    useEdgesState: () => [[], jest.fn(), jest.fn()],
    useReactFlow: () => ({ fitView: jest.fn() }),
    ReactFlowProvider: ({ children }: any) => <div>{children}</div>,
    MiniMap: () => <div data-testid="minimap" />,
    Controls: () => <div data-testid="controls" />,
    MarkerType: { ArrowClosed: 'ArrowClosed' },
    ConnectionMode: { Loose: 'Loose' },
  };
});
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/user.icon', () => ({}), { virtual: true });
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/store.icon', () => ({}), { virtual: true });
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/reset.icon', () => ({}), { virtual: true });

jest.mock('../../src/components/custom-sdk/template/RB_Components_NetworkDiagram/styles', () => {
  const React = require('react');
  return ({ children }: any) => <div>{children}</div>;
});

describe('RB_Components_NetworkDiagram/index', () => {
  beforeEach(() => {
    (window as any).PCore = {
      getDataPageUtils: () => ({
        getPageDataAsync: jest.fn(async () => ({
          pyNodes: [{ pyID: 'N1', pyCategory: 'Person', pyLabel: 'A', pzInsKey: 'K1', pyClassName: 'C1' }],
          pyEdges: [{ pyID: 'E1', pyFrom: 'N1', pyTo: 'N1', pyCategory: 'FRIEND', pyLabel: 'L1' }],
        })),
      }),
    };
  });

  it('renders network diagram and refresh button', async () => {
    const { default: Diagram } = await import(
      '../../src/components/custom-sdk/template/RB_Components_NetworkDiagram'
    );
    const pConn = {
      getContextName: () => 'CTX',
      getLocalizedValue: (v: string) => v,
    };

    const { getAllByRole, getByText } = render(
      <Diagram heading="H1" dataPage="D_Graph" showRefresh edgePath="bezier" getPConnect={() => pConn} />,
    );
    fireEvent.click(getAllByRole('button')[0]);
    await waitFor(() => expect(getByText('H1')).toBeInTheDocument());
  });
});


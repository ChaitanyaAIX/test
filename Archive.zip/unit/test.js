function getUploadAgeLabel(dateStr: any): string | null {
    try {
      if (!dateStr) {
        return null;
      }
      const dt = new Date(String(dateStr));
      if (Number.isNaN(dt.getTime())) {
        return null;
      }
      const now = new Date();
      const diffMs = now.getTime() - dt.getTime();
      if (diffMs < 0) {
        return '0 days ago';
      }

      const oneDayMs = 1000 * 60 * 60 * 24;
      if (diffMs >= oneDayMs) {
        const days = Math.floor(diffMs / oneDayMs);
        return `${days} ${days === 1 ? 'day' : 'days'} ago`;
      }

      const totalMinutes = Math.floor(diffMs / (1000 * 60));
      if (totalMinutes < 60) {
        const minutes = Math.max(1, totalMinutes);
        return `${minutes} ${minutes === 1 ? 'min' : 'mins'} ago`;
      }
      const totalHours = Math.floor(totalMinutes / 60);
      return `${totalHours} ${totalHours === 1 ? 'hour' : 'hours'} ago`;
    } catch {
      return null;
    }
  }
     const uploadAgeLabel = getUploadAgeLabel(a?.createTime);

   if (uploadAgeLabel) {
      parts.push(uploadAgeLabel);
    }
                sonar.coverage.exclusions=src/components/custom-constellation/**,src/components_map.js,src/index.tsx,src/**/*.stories.ts,src/**/*.stories.tsx,src/**/*.stories.js,src/**/*.stories.jsx,src/**/mock.ts,src/**/mock.tsx,src/**/mock.js,src/**/mock.jsx,src/**/style.ts,src/**/style.tsx,src/**/style.js,src/**/style.jsx,src/**/styles.ts,src/**/styles.tsx,src/**/styles.js,src/**/styles.jsx,src/samples/Embedded/Header/index.tsx,src/samples/Embedded/MainScreen/index.tsx,src/samples/Embedded/ResolutionScreen/index.tsx,src/samples/Embedded/ShoppingOptionCard/index.tsx,src/samples/Embedded/context/PegaAuthProvider.tsx,src/samples/Embedded/context/PegaReadyContext.tsx

 collectCoverageFrom: [
    // Cover the whole src tree, excluding the custom-constellation templates as requested.
    'src/**/*.{ts,tsx,js,jsx}',
    '!src/components/custom-constellation/**/*',
    // keep common non-source patterns excluded
    '!src/components_map.js',
    '!src/index.tsx',
    '!src/**/*.stories.{ts,tsx,js,jsx}',
    '!src/**/*.{mock,mocks}.{ts,tsx,js,jsx}',
    '!src/**/mock.{ts,tsx,js,jsx}',
    '!src/**/style.{ts,tsx,js,jsx}',
    '!src/**/styles.{ts,tsx,js,jsx}',
    '!src/samples/Embedded/Header/index.tsx',
    '!src/samples/Embedded/MainScreen/index.tsx',
    '!src/samples/Embedded/ResolutionScreen/index.tsx',
    '!src/samples/Embedded/ShoppingOptionCard/index.tsx',
    '!src/samples/Embedded/context/PegaAuthProvider.tsx',
    '!src/samples/Embedded/context/PegaReadyContext.tsx',
  ],

import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

jest.mock('@pega/cosmos-react-core', () => {
  const ReactActual = require('react');
  const pass =
    (Tag: any, stripProps: string[] = []) =>
    // eslint-disable-next-line react/display-name
    ({ children, ...rest }: any) => {
      stripProps.forEach((k) => {
        if (k in rest) {
          delete rest[k];
        }
      });
      return ReactActual.createElement(Tag, rest, children);
    };

  return {
    __esModule: true,
    Button: pass('button', ['icon', 'variant', 'fullWidth']),
    Card: pass('div'),
    CardContent: pass('div'),
    CardHeader: ({ actions, children, ...rest }: any) => (
      <div {...rest}>
        <div>{children}</div>
        <div>{actions}</div>
      </div>
    ),
    FieldGroup: pass('div'),
    Flex: pass('div'),
    Icon: ({ name, ...rest }: any) => (
      <span {...rest} aria-label={`icon-${name}`}>
        {name}
      </span>
    ),
    Input: ({ value, onChange, ...rest }: any) => (
      <input value={value} onChange={onChange} {...rest} />
    ),
    Option: pass('option'),
    Select: pass('select'),
    SummaryItem: ({ primary, secondary }: any) => (
      <div>
        <div>{primary}</div>
        <div>{secondary}</div>
      </div>
    ),
    Text: pass('span'),
  };
});

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/style',
  () => {
    const ReactActual = require('react');
    return {
      __esModule: true,
      default: ReactActual.forwardRef(({ children, ...rest }: any, ref: any) => (
        <div ref={ref} {...rest}>
          {children}
        </div>
      )),
    };
  },
);

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewHelpers',
  () => {
    return {
      __esModule: true,
      MIME_OCTET_STREAM: 'application/octet-stream',
      MIME_PDF: 'application/pdf',
      displayName: (a: any) => a?.name || a?.pyLabel || 'file',
      getEmailHeaderLabel: () => 'Email',
      inferAttachmentExtension: (a: any) => a?.extension || null,
      inferExtensionFromName: (name: string) => (name.includes('.') ? name.split('.').pop() : null),
      looksLikeEml: (a: any) => (a?.extension || '').toLowerCase() === 'eml',
      looksLikeExcel: (a: any) => (a?.extension || '').toLowerCase().startsWith('xl'),
      looksLikeMsg: (a: any) => (a?.extension || '').toLowerCase() === 'msg',
      looksLikePdf: (a: any) => (a?.extension || '').toLowerCase() === 'pdf',
      looksLikeWord: (a: any) => (a?.extension || '').toLowerCase().startsWith('doc'),
      pickAttachmentId: (a: any) => a?.ID || a?.pzInsKey || a?.key || null,
    };
  },
);

import AttachmentPreviewView from '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/AttachmentPreviewView';

function baseProps(overrides: any = {}) {
  return {
    wrapperRef: { current: null },
    openMenuIndex: null,
    setOpenMenuIndex: jest.fn(),
    openHeaderMenu: false,
    setOpenHeaderMenu: jest.fn(),
    propsToUse: { showLabel: true, label: 'Attachments' },
    label: 'Attachments',
    localeCategory: 'CosmosFields',
    localizedVal: (s: string) => s,
    isAllowAddAttachment: true,
    isDragOver: false,
    onDragEnter: jest.fn(),
    onDragOver: jest.fn(),
    onDragLeave: jest.fn(),
    onDrop: jest.fn(),
    isSearchable: true,
    isSearchOpen: false,
    setIsSearchOpen: jest.fn(),
    searchQuery: 'abc',
    setSearchQuery: jest.fn(),
    handleAddFiles: jest.fn(),
    loadingList: false,
    isUploading: false,
    uploadItems: [],
    attachments: [{ name: 'a.pdf', extension: 'pdf', links: { delete: { href: 'x' } } }],
    effectiveList: [{ name: 'a.pdf', extension: 'pdf', links: { delete: { href: 'x' } } }],
    visibleCount: 1,
    pageSize: 0,
    children: null,
    editingMenuIndex: null,
    setEditingMenuIndex: jest.fn(),
    menuEditTitle: '',
    setMenuEditTitle: jest.fn(),
    menuEditCategory: '',
    setMenuEditCategory: jest.fn(),
    availableCategories: [{ id: 'c1', label: 'Cat1' }],
    submitInlineMenuEdit: jest.fn(),
    openInlineMenuEdit: jest.fn(),
    downloadAttachmentBytes: jest.fn(),
    deleteAttachmentIfPossible: jest.fn(),
    inferredContext: 'app/primary_1',
    handleSelectAttachment: jest.fn(),
    isPreviewOpen: false,
    setIsPreviewOpen: jest.fn(),
    modalLabel: 'Attachment Preview',
    pdfData: null,
    docxArrayBuffer: null,
    docxHostId: 'docx-host',
    setDocxRef: jest.fn(),
    htmlPreview: null,
    nonPdfBytes: null,
    nonPdfMime: null,
    selectedKind: null,
    loadingPdf: false,
    loadingOther: false,
    isEditOpen: false,
    editTitle: '',
    setEditTitle: jest.fn(),
    editCategory: '',
    setEditCategory: jest.fn(),
    submitEdit: jest.fn(),
    allowedDownloadExts: null,
    configProps: { allowDownloadAttachments: true },
    sortDirection: 'desc',
    handleSort: jest.fn(),
    handleShowMore: jest.fn(),
    handleShowLess: jest.fn(),
    ...overrides,
  };
}

describe('AttachmentPreviewView', () => {
  beforeAll(() => {
    if (!(global as any).URL) {
      (global as any).URL = {} as any;
    }
    if (!(global as any).URL.createObjectURL) {
      (global as any).URL.createObjectURL = jest.fn(() => 'blob:mock');
    }
    if (!(global as any).URL.revokeObjectURL) {
      (global as any).URL.revokeObjectURL = jest.fn();
    }
  });

  it('toggles search and clears query when closing', () => {
    const setIsSearchOpen = jest.fn((fn: any) => fn(false));
    const setSearchQuery = jest.fn();
    render(
      <AttachmentPreviewView
        {...baseProps({
          isSearchOpen: true,
          setIsSearchOpen,
          setSearchQuery,
        })}
      />,
    );

    fireEvent.click(screen.getByRole('button', { name: 'Search attachments' }));
    expect(setIsSearchOpen).toHaveBeenCalled();
    expect(setSearchQuery).toHaveBeenCalledWith('');
  });

  it('calls handleAddFiles when + is clicked', () => {
    const handleAddFiles = jest.fn();
    render(<AttachmentPreviewView {...baseProps({ handleAddFiles })} />);
    fireEvent.click(screen.getByLabelText('Add files'));
    expect(handleAddFiles).toHaveBeenCalledWith(null);
  });

  it('calls handleSelectAttachment when attachment name clicked', () => {
    const handleSelectAttachment = jest.fn();
    render(<AttachmentPreviewView {...baseProps({ handleSelectAttachment })} />);
    fireEvent.click(screen.getByText('a.pdf'));
    expect(handleSelectAttachment).toHaveBeenCalledWith(0);
  });

  it('opens menu and calls deleteAttachmentIfPossible', () => {
    const setOpenMenuIndex = jest.fn();
    const deleteAttachmentIfPossible = jest.fn();
    render(
      <AttachmentPreviewView
        {...baseProps({
          openMenuIndex: 0,
          setOpenMenuIndex,
          deleteAttachmentIfPossible,
        })}
      />,
    );

    // menu is already open via openMenuIndex=0, click Delete item
    fireEvent.click(screen.getByText('Delete'));
    expect(setOpenMenuIndex).toHaveBeenCalledWith(null);
    expect(deleteAttachmentIfPossible).toHaveBeenCalledWith(
      expect.objectContaining({ name: 'a.pdf' }),
      'app/primary_1',
    );
  });

  it('renders PDF preview iframe when pdfData is present', () => {
    render(<AttachmentPreviewView {...baseProps({ isPreviewOpen: true, pdfData: new Uint8Array([1]) })} />);
    expect(screen.getByTitle('PDF preview')).toBeInTheDocument();
  });

  it('renders DOCX host container when docxArrayBuffer is present', () => {
    render(
      <AttachmentPreviewView
        {...baseProps({
          isPreviewOpen: true,
          docxArrayBuffer: new Uint8Array([1, 2, 3]),
          docxHostId: 'docx-host-1',
        })}
      />,
    );
    expect(document.getElementById('docx-host-1')).toBeTruthy();
  });

  it('renders Email preview iframe when htmlPreview is present', () => {
    render(
      <AttachmentPreviewView
        {...baseProps({
          isPreviewOpen: true,
          htmlPreview: '<html><body>Hi</body></html>',
          nonPdfMime: 'message/rfc822',
          selectedKind: 'eml',
        })}
      />,
    );
    expect(screen.getByTitle('Email preview')).toBeInTheDocument();
    expect(screen.getByText('Email')).toBeInTheDocument();
  });

  it('renders image tag when nonPdfBytes are image/*', () => {
    render(
      <AttachmentPreviewView
        {...baseProps({
          isPreviewOpen: true,
          nonPdfBytes: new Uint8Array([1, 2, 3]),
          nonPdfMime: 'image/png',
        })}
      />,
    );
    const img = document.querySelector('img.preview-image');
    expect(img).toBeTruthy();
  });

  it('renders generic attachment iframe when nonPdfBytes are non-image', () => {
    render(
      <AttachmentPreviewView
        {...baseProps({
          isPreviewOpen: true,
          nonPdfBytes: new Uint8Array([1, 2, 3]),
          nonPdfMime: 'text/plain',
        })}
      />,
    );
    expect(screen.getByTitle('Attachment preview')).toBeInTheDocument();
  });

  it('shows Download menu item when allowed and calls downloadAttachmentBytes', () => {
    const setOpenMenuIndex = jest.fn();
    const downloadAttachmentBytes = jest.fn();
    render(
      <AttachmentPreviewView
        {...baseProps({
          openMenuIndex: 0,
          setOpenMenuIndex,
          allowedDownloadExts: ['pdf'],
          downloadAttachmentBytes,
          configProps: { allowDownloadAttachments: true },
        })}
      />,
    );

    fireEvent.click(screen.getByText('Download'));
    expect(setOpenMenuIndex).toHaveBeenCalledWith(null);
    expect(downloadAttachmentBytes).toHaveBeenCalledWith(expect.objectContaining({ name: 'a.pdf' }));
  });
});


import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';

const mockHandleEvent = jest.fn();

jest.mock('@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map', () => ({
  __esModule: true,
  getComponentFromMap: () => {
    const ReactModule = require('react');
    return ({ name, value, variant }: { name?: string; value?: React.ReactNode; variant?: string }) => (
      <div
        data-test-id='field-value-list'
        data-name={name ?? ''}
        data-variant={variant ?? ''}
      >
        {value}
      </div>
    );
  },
}));

jest.mock('@pega/react-sdk-components/lib/components/helpers/event-utils', () => ({
  __esModule: true,
  default: (...args: unknown[]) => mockHandleEvent(...args),
}));

import FusionAixComponentsBannerInput from '../../../src/components/custom-sdk/field/FusionAIX_Components_BannerInput/index';

describe('FusionAIX_Components_BannerInput (SDK)', () => {
  beforeEach(() => {
    mockHandleEvent.mockClear();
  });

  const getPConnect = () => ({
    getStateProps: () => ({ value: 'Note.Content' }),
    getActionsApi: () => ({}),
  });

  const base = {
    getPConnect,
    label: 'Note',
    required: false,
    disabled: false,
    validatemessage: '',
    readOnly: false,
    testId: 'sdk-banner',
    helperText: '',
    hideLabel: false,
    placeholder: 'Type here',
    displayMode: undefined,
    value: '',
    status: undefined,
  };

  it('renders DISPLAY_ONLY with FieldValueList and banner HTML', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          displayMode: 'DISPLAY_ONLY',
          value: '<strong>Hi</strong>',
        } as any)}
      />,
    );
    const fvl = screen.getByTestId('field-value-list');
    expect(fvl).toHaveAttribute('data-name', 'Note');
    expect(screen.getByTestId('banner-display-html').innerHTML).toContain('<strong>Hi</strong>');
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner success - <strong>Hi</strong>');
  });

  it('hides label in DISPLAY_ONLY when hideLabel is true', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          displayMode: 'DISPLAY_ONLY',
          value: 'v',
          hideLabel: true,
        } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toHaveAttribute('data-name', '');
  });

  it('renders STACKED_LARGE_VAL with stacked variant', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          displayMode: 'STACKED_LARGE_VAL',
          value: 'Big',
        } as any)}
      />,
    );
    const fvl = screen.getByTestId('field-value-list');
    expect(fvl).toHaveAttribute('data-variant', 'stacked');
    expect(screen.getByTestId('banner-stacked-val')).toHaveTextContent('Big');
  });

  it('uses custom banner variant in aria-label', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          displayMode: 'DISPLAY_ONLY',
          value: 'm',
          bannerVariant: 'warn',
          bannerIcon: 'information-solid',
        } as any)}
      />,
    );
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner warn - m');
  });

  it('submits changeNblur on blur when not readOnly', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          value: 'initial',
        } as any)}
      />,
    );
    const input = screen.getByRole('textbox');
    fireEvent.change(input, { target: { value: 'next' } });
    fireEvent.blur(input);
    expect(mockHandleEvent).toHaveBeenCalledWith(expect.anything(), 'changeNblur', 'Note.Content', 'next');
  });

  it('does not attach blur when readOnly', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          value: 'ro',
          readOnly: true,
        } as any)}
      />,
    );
    const input = screen.getByRole('textbox');
    fireEvent.blur(input);
    expect(mockHandleEvent).not.toHaveBeenCalled();
  });

  it('shows error state when status is error', () => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          value: 'x',
          status: 'error',
          validatemessage: 'Bad input',
        } as any)}
      />,
    );
    expect(screen.getByText('Bad input')).toBeInTheDocument();
  });

  it('updates input when prop value changes', () => {
    const { rerender } = render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          value: 'a',
        } as any)}
      />,
    );
    rerender(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          value: 'b',
        } as any)}
      />,
    );
    expect(screen.getByRole('textbox')).toHaveValue('b');
  });

  it.each(['success', 'urgent', 'info', 'warn', 'pending'] as const)('covers SDK bannerVariant %s aria metadata', (bannerVariant) => {
    render(
      <FusionAixComponentsBannerInput
        {...({
          ...base,
          displayMode: 'DISPLAY_ONLY',
          value: 'v',
          bannerVariant,
          bannerIcon: 'check',
        } as any)}
      />,
    );
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', `Banner ${bannerVariant} - v`);
  });

  it.each(['warn-solid', 'flag-wave-solid', 'check', 'information-solid'] as const)(
    'covers SDK bannerIcon glyph %s',
    (bannerIcon) => {
      const { container } = render(
        <FusionAixComponentsBannerInput
          {...({
            ...base,
            displayMode: 'DISPLAY_ONLY',
            value: ' glyph ',
            bannerVariant: 'info',
            bannerIcon,
          } as any)}
        />,
      );
      expect(container.querySelector('[aria-hidden]')).toBeInTheDocument();
    },
  );
});

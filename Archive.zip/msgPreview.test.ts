import { extractMsgDetails, parseMsgToHtml } from '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview';

type MsgReaderShape = {
  getFileData: () => any;
  getProperty?: (tag: number) => any;
  properties?: Record<string, any>;
};

describe('msgPreview', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('parseMsgToHtml returns header + bodyHTML when available', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Hello',
              senderName: 'Alice',
              recipients: [{ type: 'to', email: 'bob@example.com' }],
              messageDeliveryTime: '2026-01-02T03:04:05Z',
              bodyHTML: '<div>Body</div>',
              attachments: [],
            }),
            properties: { any: 'prop' },
            getProperty: () => undefined,
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1, 2, 3]));
    });

    expect(result?.html).toContain('Subject:');
    expect(result?.html).toContain('Hello');
    expect(result?.html).toContain('<div>Body</div>');
    expect(result?.hasBody).toBe(true);
  });

  it('parseMsgToHtml returns empty when MSGReader throws', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => {
              throw new Error('boom');
            },
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1]));
    });

    expect(result).toEqual({ html: '', hasBody: false });
  });

  it('extractMsgDetails returns structured dump and bestHtml', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Subj',
              senderEmail: 'a@example.com',
              messageDeliveryTime: '2026-02-03T00:00:00Z',
              recipients: [
                { type: 'to', email: 't@example.com' },
                { type: 'cc', email: 'c@example.com' },
                { type: 'bcc', email: 'b@example.com' },
              ],
              attachments: [
                { fileName: 'body.html', mimeType: 'text/html', content: '<html><body>ATT</body></html>' },
              ],
              bodyHTML: '<html><body>INLINE</body></html>',
            }),
          };
        }),
      };
    });

    let details: any;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      details = mod.extractMsgDetails(new Uint8Array([1, 2]));
    });

    expect(details.subject).toBe('Subj');
    expect(details.recipients.to).toEqual(['t@example.com']);
    expect(details.recipients.cc).toEqual(['c@example.com']);
    expect(details.recipients.bcc).toEqual(['b@example.com']);
    expect(details.bestHtml).toHaveProperty('source');
    expect(typeof details.bestHtml.html).toBe('string');
  });
});


type MsgReaderShape = {
  getFileData: () => any;
  getProperty?: (tag: number) => any;
  properties?: Record<string, any>;
};

describe('msgPreview', () => {
  beforeEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
  });

  it('parseMsgToHtml returns header + bodyHTML when available', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Hello',
              senderName: 'Alice',
              recipients: [{ type: 'to', email: 'bob@example.com' }],
              messageDeliveryTime: '2026-01-02T03:04:05Z',
              bodyHTML: '<div>Body</div>',
              attachments: [],
            }),
            properties: { any: 'prop' },
            getProperty: () => undefined,
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1, 2, 3]));
    });

    expect(result?.html).toContain('Subject:');
    expect(result?.html).toContain('Hello');
    expect(result?.html).toContain('<div>Body</div>');
    expect(result?.hasBody).toBe(true);
  });

  it('parseMsgToHtml uses attachment html when bodyHTML is missing', () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Hello',
              senderName: 'Alice',
              recipients: [],
              attachments: [
                {
                  fileName: 'content.html',
                  mimeType: 'text/html',
                  content: '<html><body><p>ATTACHMENT BODY</p></body></html>',
                },
              ],
            }),
            getProperty: () => undefined,
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1]));
    });

    expect(result?.html).toContain('ATTACHMENT BODY');
    expect(result?.hasBody).toBe(true);
  });

  it('parseMsgToHtml falls back to plain text when html is missing', () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'S',
              senderName: 'A',
              recipients: [],
              body: 'Hello <world>',
              attachments: [],
            }),
            getProperty: () => undefined,
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1]));
    });

    // ensure html escaping for plain text fallback
    expect(result?.html).toContain('Hello &lt;world&gt;');
    expect(result?.hasBody).toBe(true);
  });

  it('parseMsgToHtml can populate html via MSGReader getProperty tags', () => {
    // PidTagHtml = 0x1013 (used inside mergeReaderProperties)
    const htmlProp = '<div>FROM PROPERTY</div>';

    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Prop',
              senderName: 'A',
              recipients: [],
              // no bodyHTML here on purpose
              attachments: [],
            }),
            getProperty: (tag: number) => (tag === 0x1013 ? htmlProp : undefined),
            properties: { subject: 'Prop' },
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1]));
    });

    expect(result?.html).toContain('FROM PROPERTY');
    expect(result?.hasBody).toBe(true);
  });

  it('parseMsgToHtml returns empty when MSGReader throws', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => {
              throw new Error('boom');
            },
          };
        }),
      };
    });

    let result: { html: string; hasBody: boolean } | undefined;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      result = mod.parseMsgToHtml(new Uint8Array([1]));
    });

    expect(result).toEqual({ html: '', hasBody: false });
  });

  it('extractMsgDetails returns structured dump and bestHtml', async () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation((): MsgReaderShape => {
          return {
            getFileData: () => ({
              subject: 'Subj',
              senderEmail: 'a@example.com',
              messageDeliveryTime: '2026-02-03T00:00:00Z',
              recipients: [
                { type: 'to', email: 't@example.com' },
                { type: 'cc', email: 'c@example.com' },
                { type: 'bcc', email: 'b@example.com' },
              ],
              attachments: [
                { fileName: 'body.html', mimeType: 'text/html', content: '<html><body>ATT</body></html>' },
              ],
              bodyHTML: '<html><body>INLINE</body></html>',
            }),
          };
        }),
      };
    });

    let details: any;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      details = mod.extractMsgDetails(new Uint8Array([1, 2]));
    });

    expect(details.subject).toBe('Subj');
    expect(details.recipients.to).toEqual(['t@example.com']);
    expect(details.recipients.cc).toEqual(['c@example.com']);
    expect(details.recipients.bcc).toEqual(['b@example.com']);
    expect(details.bestHtml).toHaveProperty('source');
    expect(typeof details.bestHtml.html).toBe('string');
  });

  it('extractMsgDetails returns error object when MSGReader fails', () => {
    jest.doMock('@kenjiuno/msgreader', () => {
      return {
        __esModule: true,
        default: jest.fn().mockImplementation(() => {
          throw new Error('nope');
        }),
      };
    });

    let details: any;
    jest.isolateModules(() => {
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/msgPreview');
      details = mod.extractMsgDetails(new Uint8Array([1]));
    });

    expect(details).toHaveProperty('error');
  });
});


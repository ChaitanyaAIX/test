import { getKeyForMappedField, mapStateToProps } from '../../src/components/custom-sdk/template/FusionAIX_Components_fxSaveTemplate/utils';

jest.mock('uuid', () => ({ v4: jest.fn(() => 'uuid-1') }));

describe('fxSaveTemplate utils', () => {
  it('mapStateToProps maps visibility and getPConnect', () => {
    const getPConnect = () => ({ getComputedVisibility: () => true });
    const out = mapStateToProps({}, { getPConnect });
    expect(out.visibility).toBe(true);
    expect(out.getPConnect).toBe(getPConnect);
  });

  it('getKeyForMappedField builds key from meta.type + meta.config.name', () => {
    const field = {
      getPConnect: () => ({
        meta: { type: 'TextInput', config: { name: '.Foo' } },
      }),
    };
    expect(getKeyForMappedField(field)).toBe('TextInput_.Foo');
  });

  it('getKeyForMappedField falls back to label, then uuid', () => {
    const withLabel = {
      getPConnect: () => ({
        meta: { type: 'TextInput', config: { label: 'Bar' } },
      }),
    };
    expect(getKeyForMappedField(withLabel)).toBe('TextInput_Bar');

    const noMeta = { getPConnect: () => ({ meta: {} }) };
    expect(getKeyForMappedField(noMeta)).toBe('uuid-1');
  });

  it('getKeyForMappedField handles arrays', () => {
    const a = { getPConnect: () => ({ meta: { type: 'A', config: { name: 'x' } } }) };
    const b = { getPConnect: () => ({ meta: { type: 'B', config: { name: 'y' } } }) };
    expect(getKeyForMappedField([a, b])).toBe('A_x__B_y');
  });
});


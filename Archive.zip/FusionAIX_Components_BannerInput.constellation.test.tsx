import React from 'react';
import { ThemeProvider } from 'styled-components';
import { fireEvent, render, screen } from '@testing-library/react';

const mockHandleEvent = jest.fn();

jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon', () => ({ name: 'warn-solid' }), {
  virtual: true,
});
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon', () => ({ name: 'flag-wave-solid' }), {
  virtual: true,
});
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/check.icon', () => ({ name: 'check' }), {
  virtual: true,
});
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/information-solid.icon', () => ({ name: 'information-solid' }), {
  virtual: true,
});

jest.mock('@pega/cosmos-react-core', () => {
  const React = require('react');
  return {
    __esModule: true,
    withConfiguration: (C: unknown) => C,
    registerIcon: jest.fn(),
    Icon: ({ name }: { name?: string }) => <span data-test-id='banner-icon' data-name={name ?? ''} />,
    HTML: ({ content }: { content?: string }) => <div data-test-id='html-content'>{content}</div>,
    TextArea: ({
      onChange,
      onBlur,
      value,
      label,
      status,
      onResolveSuggestion,
      required,
      disabled,
      readOnly,
    }: any) => (
      <>
        <textarea
          aria-label={label}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          data-status={status ?? ''}
          required={required}
          disabled={disabled}
          readOnly={readOnly}
        />
        <button type='button' data-test-id='resolve-suggestion' onClick={() => onResolveSuggestion?.(true)}>
          resolve
        </button>
      </>
    ),
    FieldValueList: ({ fields }: { fields?: { id: string; value: React.ReactNode }[] }) => (
      <div data-test-id='field-value-list'>
        {(fields ?? []).map((f) => (
          <div key={f.id} data-test-id={`fvl-${f.id}`}>
            {f.value}
          </div>
        ))}
      </div>
    ),
    Text: ({ children }: { children?: React.ReactNode }) => <span data-test-id='large-text'>{children}</span>,
    EmailDisplay: (p: { value?: string }) => (
      <a data-test-id='email' href={`mailto:${p.value}`}>
        {p.value}
      </a>
    ),
    PhoneDisplay: (p: { value?: string }) => <span data-test-id='phone'>{p.value}</span>,
    URLDisplay: (p: { value?: string }) => (
      <a data-test-id='url' href={p.value}>
        {p.value}
      </a>
    ),
  };
});

jest.mock(
  '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/event-utils',
  () => ({
    __esModule: true,
    default: (...args: unknown[]) => mockHandleEvent(...args),
  }),
);

const mockSuggestionsHandler = jest.fn();
jest.mock(
  '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/suggestions-handler',
  () => ({
    suggestionsHandler: (...args: unknown[]) => mockSuggestionsHandler(...args),
  }),
);

jest.mock(
  '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/styles',
  () => {
    const React = require('react');
    return {
      StyledBanner: ({ children, ...rest }: { children?: React.ReactNode }) => (
        <div data-test-id='styled-banner' {...rest}>
          {children}
        </div>
      ),
      StyledBannerStatus: ({ children, variant }: { children?: React.ReactNode; variant?: string }) => (
        <div data-test-id='banner-status' data-variant={variant ?? ''}>
          {children}
        </div>
      ),
      StyledBannerText: ({ children, variant }: { children?: React.ReactNode; variant?: string }) => (
        <div data-test-id='banner-text' data-variant={variant ?? ''}>
          {children}
        </div>
      ),
    };
  },
);

import FusionAixComponentsBannerInput, {
  formatExists,
  textFormatter,
} from '../../../src/components/custom-constellation/field/FusionAIX_Components_BannerInput/index';

const bannerTheme = {
  base: {
    palette: {
      success: '#4caf50',
      urgent: '#f44336',
      info: '#2196f3',
      warn: '#ff9800',
      pending: '#9e9e9e',
      'primary-background': '#ffffff',
    },
  },
  components: {
    card: { 'border-radius': '0.25rem' },
  },
};

function makePConnect() {
  return {
    getStateProps: () => ({ value: 'Note.Body', hasSuggestions: false }),
    getActionsApi: () => ({
      updateFieldValue: jest.fn(),
      triggerFieldChange: jest.fn(),
    }),
    ignoreSuggestion: jest.fn(),
    acceptSuggestion: jest.fn(),
    setInheritedProps: jest.fn(),
    resolveConfigProps: jest.fn(),
  };
}

function renderWithTheme(ui: React.ReactElement) {
  return render(<ThemeProvider theme={bannerTheme as any}>{ui}</ThemeProvider>);
}

describe('FusionAIX_Components_BannerInput constellation helpers', () => {
  it('formatExists recognises supported formatters', () => {
    expect(formatExists('Email')).toEqual(true);
    expect(formatExists('Unknown')).toEqual(false);
  });

  it('textFormatter returns cosmos display nodes', () => {
    expect(textFormatter('TextInput', 'plain-copy')).toBe('plain-copy');
    const urlNode = textFormatter('URL', 'https://example.com');
    render(<ThemeProvider theme={bannerTheme as any}>{urlNode}</ThemeProvider>);
    expect(screen.getByTestId('url')).toHaveTextContent('https://example.com');
    const mail = textFormatter('Email', 'you@there.com');
    render(<ThemeProvider theme={bannerTheme as any}>{mail}</ThemeProvider>);
    expect(screen.getAllByTestId('email')[0]).toHaveAttribute('href', 'mailto:you@there.com');
    const phoneNode = textFormatter('Phone', '5551212');
    render(<ThemeProvider theme={bannerTheme as any}>{phoneNode}</ThemeProvider>);
    expect(screen.getAllByTestId('phone')[0]).toHaveTextContent('5551212');
  });
});

describe('FusionAIX_Components_BannerInput constellation UI', () => {
  beforeEach(() => {
    mockHandleEvent.mockClear();
    mockSuggestionsHandler.mockClear();
  });

  const baseField = {
    label: 'Banner note',
    required: false,
    disabled: false,
    validatemessage: '',
    readOnly: false,
    testId: 'banner-note',
    helperText: '',
    hideLabel: false,
    placeholder: '',
    formatter: 'TextInput',
    getPConnect: () => makePConnect(),
  };

  it('renders DISPLAY_ONLY banner with HTML body', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'DISPLAY_ONLY',
          value: '<em>Important</em>',
        } as any)}
      />,
    );
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner success - <em>Important</em>');
    expect(screen.getByTestId('html-content')).toHaveTextContent('<em>Important</em>');
  });

  it('renders LABELS_LEFT with FieldValueList and Email formatter', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'LABELS_LEFT',
          value: 'a@b.com',
          isTableFormatter: true,
          formatter: 'Email',
        } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toBeInTheDocument();
    expect(screen.getByTestId('email')).toHaveAttribute('href', 'mailto:a@b.com');
  });

  it('renders STACKED_LARGE_VAL inside banner chrome', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'STACKED_LARGE_VAL',
          value: 'Headline',
        } as any)}
      />,
    );
    expect(screen.getByTestId('large-text')).toHaveTextContent('Headline');
  });

  it('uses custom banner variant and icon in aria-label', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'DISPLAY_ONLY',
          value: 'X',
          bannerVariant: 'urgent',
          bannerIcon: 'check',
        } as any)}
      />,
    );
    expect(screen.getByRole('alert')).toHaveAttribute('aria-label', 'Banner urgent - X');
    expect(screen.getByTestId('banner-icon')).toHaveAttribute('data-name', 'check');
  });

  it('applies LABELS_LEFT with stacked variant when hideLabel is true', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'LABELS_LEFT',
          value: '<p>X</p>',
          hideLabel: true,
          variant: 'horizontal',
        } as any)}
      />,
    );
    const fvl = screen.getByTestId('field-value-list');
    expect(fvl).toBeInTheDocument();
  });

  it('covers STACKED_LARGE_VAL empty value banner', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          displayMode: 'STACKED_LARGE_VAL',
          value: '',
        } as any)}
      />,
    );
    expect(screen.getByTestId('field-value-list')).toBeInTheDocument();
    expect(screen.queryByTestId('large-text')).not.toBeInTheDocument();
  });

  it('flags validation status from validatemessage and suggestion flow', () => {
    const { rerender } = renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          hasSuggestions: true,
          validatemessage: 'Fix this',
        } as any)}
      />,
    );
    expect(screen.getByRole('textbox')).toHaveAttribute('data-status', 'pending');
    rerender(
      <ThemeProvider theme={bannerTheme as any}>
        <FusionAixComponentsBannerInput
          {...({
            ...baseField,
            hasSuggestions: false,
            validatemessage: 'Still bad',
          } as any)}
        />
      </ThemeProvider>,
    );
    expect(screen.getByRole('textbox')).toHaveAttribute('data-status', 'error');
    fireEvent.click(screen.getByTestId('resolve-suggestion'));
    expect(mockSuggestionsHandler).toHaveBeenCalledWith(
      true,
      expect.any(Object),
      expect.any(Function),
    );
  });

  it('fires change and blur handlers on edit', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          value: 'old',
        } as any)}
      />,
    );
    const ta = screen.getByRole('textbox');
    fireEvent.change(ta, { target: { value: 'new text' } });
    fireEvent.blur(ta, { target: { value: 'new text' } });
    expect(mockHandleEvent).toHaveBeenCalledWith(
      expect.anything(),
      'change',
      'Note.Body',
      'new text',
    );
    expect(mockHandleEvent).toHaveBeenCalledWith(
      expect.anything(),
      'blur',
      'Note.Body',
      'new text',
    );
  });

  it('skips blur event when value exists and user made no edits', () => {
    mockHandleEvent.mockClear();
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          value: 'unchanged',
        } as any)}
      />,
    );
    const ta = screen.getByRole('textbox');
    fireEvent.blur(ta, { target: { value: 'unchanged' } });
    expect(mockHandleEvent).not.toHaveBeenCalled();
  });

  it('calls ignoreSuggestion on blur when suggestions are enabled', () => {
    const pConnExtra = makePConnect();
    pConnExtra.ignoreSuggestion = jest.fn();
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          value: '',
          hasSuggestions: true,
          getPConnect: () => pConnExtra,
        } as any)}
      />,
    );
    const ta = screen.getByRole('textbox');
    fireEvent.change(ta, { target: { value: 'y' } });
    fireEvent.blur(ta, { target: { value: 'y' } });
    expect(pConnExtra.ignoreSuggestion).toHaveBeenCalledWith('');
  });

  it('maps string coercion for required and disabled booleans', () => {
    renderWithTheme(
      <FusionAixComponentsBannerInput
        {...({
          ...baseField,
          value: 'z',
          required: 'true' as any,
          disabled: 'true' as any,
          readOnly: 'false' as any,
        } as any)}
      />,
    );
    const tb = screen.getByRole('textbox');
    expect(tb).toHaveAttribute('required');
    expect(tb).toHaveAttribute('disabled');
    expect((tb as HTMLTextAreaElement).readOnly).toEqual(false);
  });
});

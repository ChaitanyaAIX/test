import React from 'react';
import { render } from '@testing-library/react';

const viewSpy = jest.fn((props: any) => props);

// cosmos-react-core icon modules ship as ESM; stub them for Jest (CJS) runtime.
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/document-pdf.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/document-doc.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/picture.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/document-xls.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/paper-clip.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/mail.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/document.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/download.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/more.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/plus.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/pencil.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/trash.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/search.icon', () => ({}));
jest.mock('@pega/cosmos-react-core/lib/components/Icon/icons/upload.icon', () => ({}));

jest.mock('@pega/cosmos-react-core', () => {
  return {
    __esModule: true,
    registerIcon: jest.fn(),
    withConfiguration: (Comp: any) => Comp,
  };
});

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/AttachmentPreviewView',
  () => {
    return {
      __esModule: true,
      default: (props: any) => {
        viewSpy(props);
        return null;
      },
    };
  },
);

jest.mock('docx-preview', () => ({ renderAsync: jest.fn() }));

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/attachmentActions',
  () => ({
    __esModule: true,
    addFilesFromFiles: jest.fn(() => Promise.resolve()),
    addFilesWithPicker: jest.fn(() => Promise.resolve()),
  }),
);

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewParsers',
  () => ({
    __esModule: true,
    handleEmlBytes: jest.fn(),
    handleExcelBytes: jest.fn(),
    handleMsgBytes: jest.fn(),
  }),
);

jest.mock(
  '../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/utils/attachmentPreviewActions',
  () => ({
    __esModule: true,
    handleSelectAttachment: jest.fn(),
    openInlineMenuEdit: jest.fn(),
    submitEdit: jest.fn(),
    submitInlineMenuEdit: jest.fn(),
  }),
);

describe('FusionAIX AttachmentPreview index', () => {
  beforeEach(() => {
    viewSpy.mockClear();
    (global as any).window = Object.assign(global.window || {}, {});
    (global as any).window.PCore = {
      getLocaleUtils: () => ({ getLocaleValue: (s: string) => s }),
      getEnvironmentInfo: () => ({ getKeyMapping: (_s: string) => _s }),
      getResolvedConstantValue: () => 'caseInfo.content',
      getStoreValue: () => 'CASE-1',
      getPubSubUtils: () => ({
        publish: jest.fn(),
        subscribe: jest.fn(),
        unsubscribe: jest.fn(),
      }),
      getConstants: () => ({
        PUB_SUB_EVENTS: { CASE_EVENTS: { ASSIGNMENT_SUBMISSION: 'ASSIGNMENT_SUBMISSION' } },
      }),
      getContextName: () => 'app/primary_1',
      getAttachmentUtils: () => ({
        getCaseAttachments: jest.fn().mockResolvedValue([]),
        downloadAttachment: jest.fn(),
      }),
    };
  });

  it('parses allowedDownloadExtensions into allowedDownloadExts and passes to view', async () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/index.tsx')
      .default;

    const getPConnect = () => ({
      getInheritedProps: () => ({}),
      resolveConfigProps: () => ({ allowDownloadAttachments: true }),
      getConfigProps: () => ({}),
      getCaseInfo: () => ({
        getClassName: () => 'ACME-Work-Case',
        getID: () => 'C-1',
        getKey: () => 'KEY-1',
      }),
      getCurrentView: () => 'View',
      getContextName: () => 'app/primary_1',
      getActionsApi: () => ({ refreshCaseView: jest.fn() }),
    });

    render(
      <Comp
        getPConnect={getPConnect}
        label="Attachments"
        showLabel
        allowedDownloadExtensions=" .PDF, docx ;XLSX  "
      />,
    );

    // allow effects to run
    await new Promise((r) => setTimeout(r, 0));

    expect(viewSpy).toHaveBeenCalled();
    const calls = (viewSpy as any).mock.calls as any[];
    const lastProps = calls[calls.length - 1]?.[0];
    expect(lastProps).toBeTruthy();
    expect(lastProps.allowedDownloadExts).toEqual(['pdf', 'docx', 'xlsx']);
  });

  it('keeps allowedDownloadExts as null when input is empty/whitespace', async () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/index.tsx')
      .default;

    const getPConnect = () => ({
      getInheritedProps: () => ({}),
      resolveConfigProps: () => ({ allowDownloadAttachments: true }),
      getConfigProps: () => ({}),
      getCaseInfo: () => ({
        getClassName: () => 'ACME-Work-Case',
        getID: () => 'C-1',
        getKey: () => 'KEY-1',
      }),
      getCurrentView: () => 'View',
      getContextName: () => 'app/primary_1',
      getActionsApi: () => ({ refreshCaseView: jest.fn() }),
    });

    render(
      <Comp getPConnect={getPConnect} label="Attachments" showLabel allowedDownloadExtensions="   " />,
    );

    await new Promise((r) => setTimeout(r, 0));
    const calls = (viewSpy as any).mock.calls as any[];
    const lastProps = calls[calls.length - 1]?.[0];
    expect(lastProps.allowedDownloadExts).toBeNull();
  });

  it('handleAddFiles uses onAddFiles override when provided', async () => {
    const { addFilesWithPicker } =
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/attachmentActions');

    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const Comp = require('../../src/components/custom-sdk/widget/FusionAIX_Components_AttachmentPreview/index.tsx')
      .default;

    const onAddFiles = jest.fn();
    const getPConnect = () => ({
      getInheritedProps: () => ({}),
      resolveConfigProps: () => ({ allowDownloadAttachments: true }),
      getConfigProps: () => ({}),
      getCaseInfo: () => ({
        getClassName: () => 'ACME-Work-Case',
        getID: () => 'C-1',
        getKey: () => 'KEY-1',
      }),
      getCurrentView: () => 'View',
      getContextName: () => 'app/primary_1',
      getActionsApi: () => ({ refreshCaseView: jest.fn() }),
    });

    render(<Comp getPConnect={getPConnect} label="Attachments" showLabel onAddFiles={onAddFiles} />);
    await new Promise((r) => setTimeout(r, 0));

    const calls = (viewSpy as any).mock.calls as any[];
    const lastProps = calls[calls.length - 1]?.[0];
    expect(typeof lastProps.handleAddFiles).toBe('function');

    lastProps.handleAddFiles(null);
    expect(onAddFiles).toHaveBeenCalled();
    expect(addFilesWithPicker).not.toHaveBeenCalled();
  });
});


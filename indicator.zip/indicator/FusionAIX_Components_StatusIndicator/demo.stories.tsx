import { useState } from 'react';

import type { Meta, StoryObj } from '@storybook/react';

import FusionAixComponentsStatusIndicator from './index';
import { configProps, fieldMetadata } from './mock';

const meta: Meta<typeof FusionAixComponentsStatusIndicator> = {
  title: 'FusionAixComponentsStatusIndicator',
  component: FusionAixComponentsStatusIndicator,
  excludeStories: /.*Data$/,
};

export default meta;
type Story = StoryObj<typeof FusionAixComponentsStatusIndicator>;

export const BaseFusionAixComponentsStatusIndicator: Story = (args) => {
  const [value, setValue] = useState(configProps.value);

  const props = {
    value,
    placeholder: configProps.placeholder,
    fieldMetadata,
    getPConnect: () => {
      return {
        getActionsApi: () => {
          return {
            updateFieldValue: (propName, theValue) => {
              setValue(theValue);
            },
            triggerFieldChange: (propName, theValue) => {
              setValue(theValue);
            },
          };
        },
        getStateProps: () => {
          return { value: '.name' };
        },
      };
    },
    onChange: (event) => {
      setValue(event.target.value);
    },
    onBlur: () => {
      return configProps.value;
    },
  };

  return <FusionAixComponentsStatusIndicator {...props} {...args} />;
};

BaseFusionAixComponentsStatusIndicator.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  testId: configProps.testId,
  indicator: configProps.indicator as 'badge' | 'trafficIndicator',
  inputProperty: configProps.inputProperty,
  infoStatus: configProps.infoStatus,
  warnStatus: configProps.warnStatus,
  successStatus: configProps.successStatus,
  pendingStatus: configProps.pendingStatus,
  urgentStatus: configProps.urgentStatus,
  iconPosition: configProps.iconPosition,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  required: configProps.required,
  status: configProps.status,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  validatemessage: configProps.validatemessage,
};

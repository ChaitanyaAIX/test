import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    display: inline-flex;
    flex-direction: column;
    gap: 0.375rem;

    .status-badge-label {
      font-size: 0.75rem;
      line-height: 1rem;
      color: #333333;
      font-weight: 500;
    }

    .status-badge-inline {
      position: relative;
      display: inline-block;
    }

    .status-badge-pill {
      display: inline-block;
    }

    .status-badge-icon {
      position: absolute;
      top: 50%;
      font-size: 0.82rem;
      line-height: 1;
      transform: translateY(-50%);
      pointer-events: none;
    }

    .status-badge-icon--left {
      left: 0.45rem;
    }

    .status-badge-icon--right {
      right: 1px;
      bottom: 1px;
      top: auto;
      transform: none;
    }

    .status-badge-pill.status-badge-pill--icon-left {
      padding-inline-start: 1.35rem;
      padding-inline-end: 0.5rem;
    }

    .status-badge-pill.status-badge-pill--icon-right {
      padding-inline-start: 0.5rem;
      padding-inline-end: 1.35rem;
    }

    .status-badge-inline--success .status-badge-icon {
      color: #00763b;
    }

    .status-badge-inline--warn .status-badge-icon {
      color: #cc7900;
    }

    .status-badge-inline--urgent .status-badge-icon {
      color: #b00020;
    }

    .status-badge-inline--pending .status-badge-icon,
    .status-badge-inline--info .status-badge-icon {
      color: #3d5ea4;
    }
  `;
});

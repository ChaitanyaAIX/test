import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    flex-direction: column;
    gap: 6px;

    .status-banner-label {
      font-size: 12px;
      line-height: 16px;
      color: #333333;
      font-weight: 500;
    }

    .status-banner-track {
      display: inline-flex;
      align-items: center;
      gap: 9px;
      padding: 4px 8px;
      border-radius: 8px;
      background: linear-gradient(180deg, #727272 0%, #666666 100%);
      box-shadow:
        inset 0 1px 1px rgba(255, 255, 255, 0.2),
        inset 0 -1px 1px rgba(0, 0, 0, 0.35);
    }

    .status-dot {
      width: 26px;
      height: 26px;
      border-radius: 50%;
      background-color: #a1a1a1;
      border: 1px solid #8a8a8a;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      box-shadow:
        inset 0 1px 1px rgba(255, 255, 255, 0.28),
        inset 0 -1px 1px rgba(0, 0, 0, 0.32);
    }

    .status-dot.is-active {
      border-width: 0;
      box-shadow:
        inset 0 1px 1px rgba(255, 255, 255, 0.3),
        0 1px 1px rgba(0, 0, 0, 0.2);
    }

    .status-dot.is-green {
      background-color: #1ed760;
      box-shadow:
        0 0 4px rgba(46, 204, 113, 0.6),
        inset 0 1px 1px rgba(255, 255, 255, 0.36);
    }

    .status-dot.is-amber,
    .status-dot.is-yellow {
      background-color: #df6329;
      box-shadow:
        0 0 4px rgba(223, 99, 41, 0.6),
        inset 0 1px 1px rgba(255, 255, 255, 0.34);
    }

    .status-dot.is-red {
      background-color: #cf0015;
      box-shadow:
        0 0 4px rgba(207, 0, 21, 0.62),
        inset 0 1px 1px rgba(255, 255, 255, 0.28);
    }

    .status-icon {
      position: relative;
      display: inline-block;
    }

    .status-icon-green {
      width: 10px;
      height: 6px;
      border-left: 2px solid #ffffff;
      border-bottom: 2px solid #ffffff;
      transform: rotate(-45deg) translateY(-1px);
    }

    .status-icon-amber,
    .status-icon-yellow {
      width: 12px;
      height: 12px;
    }

    .status-icon-amber::before,
    .status-icon-yellow::before {
      content: '';
      position: absolute;
      left: 1px;
      top: 0;
      width: 2px;
      height: 12px;
      border-radius: 1px;
      background: #ffffff;
    }

    .status-icon-amber::after,
    .status-icon-yellow::after {
      content: '';
      position: absolute;
      left: 3px;
      top: 1px;
      width: 7px;
      height: 5px;
      background: #ffffff;
      border-radius: 1px;
    }

    .status-icon-red {
      width: 14px;
      height: 12px;
    }

    .status-icon-red::before {
      content: '';
      position: absolute;
      left: 1px;
      top: 0;
      width: 0;
      height: 0;
      border-left: 6px solid transparent;
      border-right: 6px solid transparent;
      border-bottom: 11px solid #ffffff;
    }

    .status-icon-red::after {
      content: '!';
      position: absolute;
      z-index: 1;
      font-size: 8px;
      font-weight: 700;
      color: #cf0015;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -48%);
      line-height: 1;
    }
  `;
});

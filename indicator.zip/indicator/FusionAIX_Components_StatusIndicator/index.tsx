import { getComponentFromMap } from '@pega/react-sdk-components/lib/bridge/helpers/sdk_component_map';
import { PConnFieldProps } from '@pega/react-sdk-components/lib/types/PConnProps';
import { Icon, Status, Text, registerIcon, type StatusProps } from '@pega/cosmos-react-core';
import * as checkIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon';
import * as arrowDownIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/arrow-down.icon';
import * as flagSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/flag-solid.icon';
import * as flagWaveSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon';
import * as warnSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon';

import StyledFusionAixComponentsStatusIndicatorWrapper from './styles';
import StyledFusionAixComponentsStatusBadgeWrapper from './badgeStyles';

registerIcon(checkIcon, arrowDownIcon, flagSolidIcon, flagWaveSolidIcon, warnSolidIcon);

const STATUS_ORDER = ['RED', 'AMBER', 'GREEN'] as const;
type StatusValue = (typeof STATUS_ORDER)[number];
const MAX_PATTERN_LENGTH = 128;
const STATUS_VARIANTS = ['info', 'warn', 'success', 'pending', 'urgent'] as const;
const BADGE_ICON_BY_VARIANT: Record<StatusProps['variant'], string> = {
  info: 'check',
  warn: 'flag-solid',
  success: 'arrow-down',
  pending: 'check',
  urgent: 'warn-solid',
};
const BADGE_ICON_STYLE_BY_NAME = {
  'flag-solid': { marginTop: 1 } as const,
  'arrow-down': { marginTop: 0 } as const,
} as const;
const STATUS_LABEL_MAP: Record<StatusValue, string> = {
  RED: 'Critical',
  AMBER: 'Warning',
  GREEN: 'Healthy',
};
const STATUS_ICON_CONFIG: Record<
  StatusValue,
  {
    name: 'check' | 'flag-wave-solid' | 'warn-solid';
    style: {
      color: '#ffffff';
      fontSize: string;
      lineHeight: number;
      transform?: 'translateY(-1px)';
    };
  }
> = {
  GREEN: {
    name: 'check',
    style: {
      color: '#ffffff',
      fontSize: '0.95rem',
      lineHeight: 1,
    },
  },
  AMBER: {
    name: 'flag-wave-solid',
    style: {
      color: '#ffffff',
      fontSize: '0.92rem',
      lineHeight: 1,
      transform: 'translateY(-1px)',
    },
  },
  RED: {
    name: 'warn-solid',
    style: {
      color: '#ffffff',
      fontSize: '0.9rem',
      lineHeight: 1,
      transform: 'translateY(-1px)',
    },
  },
};

const looksLikeRegex = (pattern: string): boolean => /[\\^$.*+?()[\]{}|]/.test(pattern);

const isLikelyUnsafeRegex = (pattern: string): boolean => {
  if (pattern.includes('(?') || pattern.includes('\\1') || pattern.includes('\\k<')) return true;
  if (/[+*]{2,}/.test(pattern)) return true;
  if (/\([^)]*[+*{][^)]*\)/.test(pattern)) return true;
  return false;
};

const safeTest = (value: string, pattern: string): boolean => {
  const trimmed = pattern.trim();
  if (!trimmed || trimmed.length > MAX_PATTERN_LENGTH) return false;

  if (trimmed.startsWith('/') && trimmed.lastIndexOf('/') > 0) {
    const lastSlash = trimmed.lastIndexOf('/');
    const body = trimmed.slice(1, lastSlash);
    const flags = trimmed.slice(lastSlash + 1);
    try {
      const rawFlags = `${flags}i`.replace(/[^gimsuy]/g, '');
      const safeFlags = Array.from(new Set(rawFlags.split(''))).join('');
      return new RegExp(body, safeFlags).test(value);
    } catch {
      return false;
    }
  }

  if (looksLikeRegex(trimmed)) {
    if (isLikelyUnsafeRegex(trimmed)) return false;
    try {
      return new RegExp(trimmed, 'i').test(value);
    } catch {
      return false;
    }
  }

  return value.toLowerCase().includes(trimmed.toLowerCase());
};

const getStatusVariant = (value: string, statusesRegex: string[]): StatusProps['variant'] => {
  let variant: StatusProps['variant'] = 'info';
  const safeValue = `${value ?? ''}`;

  for (let index = 0; index < statusesRegex.length; index += 1) {
    const pattern = statusesRegex[index] ?? '';
    if (safeTest(safeValue, pattern)) {
      variant = STATUS_VARIANTS[index] ?? variant;
    }
  }

  return variant;
};

interface FusionAixComponentsStatusIndicatorProps extends PConnFieldProps {
  indicator?: 'badge' | 'trafficIndicator';
  inputProperty?: string;
  infoStatus?: string;
  warnStatus?: string;
  successStatus?: string;
  pendingStatus?: string;
  urgentStatus?: string;
  iconPosition?: 'left' | 'right';
  fieldMetadata?: Record<string, unknown>;
}

// Duplicated runtime code from React SDK

// props passed in combination of props from property panel (config.json) and run time props from Constellation
export default function FusionAixComponentsStatusIndicator(
  props: FusionAixComponentsStatusIndicatorProps,
) {
  // Get emitted components from map (so we can get any override that may exist)
  const FieldValueList = getComponentFromMap('FieldValueList');

  const {
    label,
    value = '',
    displayMode,
    hideLabel = false,
    indicator = 'trafficIndicator',
    inputProperty = '',
    infoStatus = '',
    warnStatus = '',
    successStatus = '',
    pendingStatus = '',
    urgentStatus = '',
    iconPosition = 'left',
    testId,
  } = props;
  const selectedIndicator = `${indicator}`.trim().toLowerCase();

  if (displayMode === 'DISPLAY_ONLY') {
    return <FieldValueList name={hideLabel ? '' : label} value={value} />;
  }

  if (displayMode === 'STACKED_LARGE_VAL') {
    return <FieldValueList name={hideLabel ? '' : label} value={value} variant="stacked" />;
  }

  if (selectedIndicator === 'badge') {
    const badgeValue = `${inputProperty || value || ''}`.trim();
    const badgeDisplayValue = badgeValue ? badgeValue.toUpperCase() : '--';
    const statusesRegex = [infoStatus, warnStatus, successStatus, pendingStatus, urgentStatus];
    const variant = getStatusVariant(badgeValue, statusesRegex);
    const iconName = BADGE_ICON_BY_VARIANT[variant];
    const iconStyle = BADGE_ICON_STYLE_BY_NAME[iconName as keyof typeof BADGE_ICON_STYLE_BY_NAME];

    return (
      <StyledFusionAixComponentsStatusBadgeWrapper data-testid={testId}>
        {!hideLabel && label ? (
          <Text className="status-badge-label" as="span">
            {label}
          </Text>
        ) : null}
        <span className={`status-badge-inline status-badge-inline--${variant}`}>
          <Status className={`status-badge-pill status-badge-pill--icon-${iconPosition}`} variant={variant}>
            {badgeDisplayValue}
          </Status>
          <Icon
            className={`status-badge-icon status-badge-icon--${iconPosition}`}
            name={iconName}
            size="font-size"
            aria-hidden="true"
            style={iconStyle}
          />
        </span>
      </StyledFusionAixComponentsStatusBadgeWrapper>
    );
  }

  const normalizedValue = `${value ?? ''}`.trim().toUpperCase();
  const effectiveValue = normalizedValue === 'YELLOW' ? 'AMBER' : normalizedValue;
  const hasKnownStatus = (status: string): status is StatusValue => status in STATUS_LABEL_MAP;
  const readableStatus =
    hasKnownStatus(effectiveValue) ? STATUS_LABEL_MAP[effectiveValue] : 'Unknown';
  const renderStatusIcon = (statusItem: StatusValue) => {
    const iconConfig = STATUS_ICON_CONFIG[statusItem];
    return (
      <Icon
        name={iconConfig.name}
        size="font-size"
        aria-hidden="true"
        style={iconConfig.style}
      />
    );
  };

  return (
    <StyledFusionAixComponentsStatusIndicatorWrapper>
      {!hideLabel && label ? <div className="status-banner-label">{label}</div> : null}
      <div
        className="status-banner-track"
        role="img"
        aria-label={`Current status: ${readableStatus}`}
        title={readableStatus}
      >
        {STATUS_ORDER.map((statusItem) => {
          const isActive = effectiveValue === statusItem;
          const statusClass = statusItem.toLowerCase();

          return (
            <span
              key={statusItem}
              className={`status-dot ${isActive ? `is-active is-${statusClass}` : ''}`}
              aria-hidden="true"
            >
              {isActive ? renderStatusIcon(statusItem) : null}
            </span>
          );
        })}
      </div>
    </StyledFusionAixComponentsStatusIndicatorWrapper>
  );
}

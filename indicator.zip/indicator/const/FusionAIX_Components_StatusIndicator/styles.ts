// individual style, comment out above, and uncomment here and add styles
import styled, { css } from 'styled-components';

export default styled.div(() => {
  return css`
    display: flex;
    flex-direction: column;
    gap: 6px;
  `;
});

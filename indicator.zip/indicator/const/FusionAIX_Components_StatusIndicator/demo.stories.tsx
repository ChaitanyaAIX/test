/* eslint-disable react/jsx-no-useless-fragment */
import type { Meta, StoryObj } from '@storybook/react';

import FusionAixComponentsStatusIndicator from './index';

import { stateProps, fieldMetadata, configProps } from './mock';

const meta: Meta<typeof FusionAixComponentsStatusIndicator> = {
  title: 'FusionAixComponentsStatusIndicator',
  component: FusionAixComponentsStatusIndicator,
  excludeStories: /.*Data$/,
};

export default meta;
type Story = StoryObj<typeof FusionAixComponentsStatusIndicator>;

export const BaseFusionAixComponentsStatusIndicator: Story = (args) => {
  const props = {
    value: configProps.value,
    hasSuggestions: configProps.hasSuggestions,
    fieldMetadata,
    getPConnect: () => {
      return {
        getStateProps: () => {
          return stateProps;
        },
        getActionsApi: () => {
          return {
            updateFieldValue: () => {
              /* nothing */
            },
            triggerFieldChange: () => {
              /* nothing */
            },
          };
        },
        ignoreSuggestion: () => {
          /* nothing */
        },
        acceptSuggestion: () => {
          /* nothing */
        },
        setInheritedProps: () => {
          /* nothing */
        },
        resolveConfigProps: () => {
          /* nothing */
        },
      };
    },
  };

  return (
    <>
      <FusionAixComponentsStatusIndicator {...props} {...args} />
    </>
  );
};

BaseFusionAixComponentsStatusIndicator.args = {
  label: configProps.label,
  helperText: configProps.helperText,
  placeholder: configProps.placeholder,
  testId: configProps.testId,
  readOnly: configProps.readOnly,
  disabled: configProps.disabled,
  required: configProps.required,
  status: configProps.status,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  indicator: configProps.indicator as 'badge' | 'trafficIndicator',
  inputProperty: configProps.inputProperty,
  infoStatus: configProps.infoStatus,
  warnStatus: configProps.warnStatus,
  successStatus: configProps.successStatus,
  pendingStatus: configProps.pendingStatus,
  urgentStatus: configProps.urgentStatus,
  iconPosition: configProps.iconPosition as 'left' | 'right',
  validatemessage: configProps.validatemessage,
};

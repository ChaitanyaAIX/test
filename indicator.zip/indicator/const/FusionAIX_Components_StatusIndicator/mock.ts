// @ts-nocheck
export const configProps = {
  value: 'pending',
  label: 'TextInput Sample',
  placeholder: 'TextInput Placeholder',
  helperText: 'TextInput Helper Text',
  testId: 'TextInput-12345678',
  hasSuggestions: false,
  displayMode: '',
  indicator: 'badge',
  inputProperty: '',
  infoStatus: 'open|hold|info|new',
  warnStatus: 'fail|cancel|reject|withdraw|revoke|stopped|warn',
  successStatus: 'resolved|completed|success',
  pendingStatus: 'pending',
  urgentStatus: 'blocked',
  iconPosition: 'left',
  hideLabel: false,
  readOnly: false,
  required: false,
  disabled: false,
  status: '',
  validatemessage: '',
};

export const stateProps = {
  value: '.TextInputSample',
  hasSuggestions: false,
};

export const fieldMetadata = {
  classID: 'DIXL-MediaCo-Work-NewService',
  type: 'Text',
  maxLength: 256,
  displayAs: 'pxTextInput',
  label: 'TextInput Sample',
};

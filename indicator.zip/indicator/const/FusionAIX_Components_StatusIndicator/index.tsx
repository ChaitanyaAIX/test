import { Icon, Status, Text, registerIcon, withConfiguration, type StatusProps } from '@pega/cosmos-react-core';
import * as checkIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon';
import * as arrowDownIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/arrow-down.icon';
import * as flagSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/flag-solid.icon';
import * as flagWaveSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/flag-wave-solid.icon';
import * as warnSolidIcon from '@pega/cosmos-react-core/lib/components/Icon/icons/warn-solid.icon';
import type { PConnFieldProps } from './PConnProps';
import './create-nonce';
import StyledFusionAixComponentsStatusBadgeWrapper from './badgeStyles';

registerIcon(checkIcon, arrowDownIcon, flagSolidIcon, flagWaveSolidIcon, warnSolidIcon);

const MAX_PATTERN_LENGTH = 128;
const STATUS_VARIANTS = ['info', 'warn', 'success', 'pending', 'urgent'] as const;
const BADGE_ICON_BY_VARIANT: Record<StatusProps['variant'], string> = {
  info: 'check',
  warn: 'flag-solid',
  success: 'arrow-down',
  pending: 'check',
  urgent: 'warn-solid',
};
const BADGE_ICON_STYLE_BY_NAME = {
  'flag-solid': { marginTop: 1 } as const,
  'arrow-down': { marginTop: 0 } as const,
} as const;

const looksLikeRegex = (pattern: string): boolean => /[\\^$.*+?()[\]{}|]/.test(pattern);

const isLikelyUnsafeRegex = (pattern: string): boolean => {
  if (pattern.includes('(?') || pattern.includes('\\1') || pattern.includes('\\k<')) return true;
  if (/[+*]{2,}/.test(pattern)) return true;
  if (/\([^)]*[+*{][^)]*\)/.test(pattern)) return true;
  return false;
};

const safeTest = (value: string, pattern: string): boolean => {
  const trimmed = pattern.trim();
  if (!trimmed || trimmed.length > MAX_PATTERN_LENGTH) return false;

  if (trimmed.startsWith('/') && trimmed.lastIndexOf('/') > 0) {
    const lastSlash = trimmed.lastIndexOf('/');
    const body = trimmed.slice(1, lastSlash);
    const flags = trimmed.slice(lastSlash + 1);
    try {
      const rawFlags = `${flags}i`.replace(/[^gimsuy]/g, '');
      const safeFlags = Array.from(new Set(rawFlags.split(''))).join('');
      return new RegExp(body, safeFlags).test(value);
    } catch {
      return false;
    }
  }

  if (looksLikeRegex(trimmed)) {
    if (isLikelyUnsafeRegex(trimmed)) return false;
    try {
      return new RegExp(trimmed, 'i').test(value);
    } catch {
      return false;
    }
  }

  return value.toLowerCase().includes(trimmed.toLowerCase());
};

const getStatusVariant = (value: string, statusesRegex: string[]): StatusProps['variant'] => {
  let variant: StatusProps['variant'] = 'info';
  const safeValue = `${value ?? ''}`;

  for (let index = 0; index < statusesRegex.length; index += 1) {
    const pattern = statusesRegex[index] ?? '';
    if (safeTest(safeValue, pattern)) {
      variant = STATUS_VARIANTS[index] ?? variant;
    }
  }

  return variant;
};

// interface for props
interface FusionAixComponentsStatusIndicatorProps extends PConnFieldProps {
  indicator?: 'badge' | 'trafficIndicator';
  inputProperty?: string;
  infoStatus?: string;
  warnStatus?: string;
  successStatus?: string;
  pendingStatus?: string;
  urgentStatus?: string;
  iconPosition?: 'left' | 'right';
  fieldMetadata?: any;
}

// Duplicated runtime code from Constellation Design System Component

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function FusionAixComponentsStatusIndicator(props: FusionAixComponentsStatusIndicatorProps) {
  const {
    label,
    value = '',
    hideLabel = false,
    testId,
    indicator = 'trafficIndicator',
    inputProperty = '',
    infoStatus = '',
    warnStatus = '',
    successStatus = '',
    pendingStatus = '',
    urgentStatus = '',
    iconPosition = 'left',
  } = props;
  const selectedIndicator = `${indicator}`.trim().toLowerCase();

  if (selectedIndicator === 'badge') {
    const badgeValue = `${inputProperty || value || ''}`.trim();
    const badgeDisplayValue = badgeValue ? badgeValue.toUpperCase() : '--';
    const statusesRegex = [infoStatus, warnStatus, successStatus, pendingStatus, urgentStatus];
    const variant = getStatusVariant(badgeValue, statusesRegex);
    const iconName = BADGE_ICON_BY_VARIANT[variant];
    const iconStyle = BADGE_ICON_STYLE_BY_NAME[iconName as keyof typeof BADGE_ICON_STYLE_BY_NAME];

    return (
      <StyledFusionAixComponentsStatusBadgeWrapper data-testid={testId}>
        {!hideLabel && label ? (
          <Text className="status-badge-label" as="span">
            {label}
          </Text>
        ) : null}
        <span className={`status-badge-inline status-badge-inline--${variant}`}>
          <Status className={`status-badge-pill status-badge-pill--icon-${iconPosition}`} variant={variant}>
            {badgeDisplayValue}
          </Status>
          <Icon
            className={`status-badge-icon status-badge-icon--${iconPosition}`}
            name={iconName}
            size="font-size"
            aria-hidden="true"
            style={iconStyle}
          />
        </span>
      </StyledFusionAixComponentsStatusBadgeWrapper>
    );
  }

  const normalizedValue = `${value}`.trim().toUpperCase();
  const effectiveValue = normalizedValue === 'YELLOW' ? 'AMBER' : normalizedValue;
  const statusOrder = ['RED', 'AMBER', 'GREEN'] as const;
  type StatusValue = (typeof statusOrder)[number];
  const statusLabelMap = {
    RED: 'Critical',
    AMBER: 'Warning',
    GREEN: 'Healthy',
  } as const;
  const readableStatus = statusLabelMap[effectiveValue as keyof typeof statusLabelMap] || 'Unknown';
  const renderStatusIcon = (statusItem: StatusValue) => {
    if (statusItem === 'GREEN') {
      return (
        <Icon
          name="check"
          size="font-size"
          aria-hidden="true"
          style={{
            color: '#ffffff',
            fontSize: '0.95rem',
            lineHeight: 1,
          }}
        />
      );
    }

    if (statusItem === 'AMBER') {
      return (
        <Icon
          name="flag-wave-solid"
          size="font-size"
          aria-hidden="true"
          style={{
            color: '#ffffff',
            fontSize: '0.92rem',
            lineHeight: 1,
            transform: 'translateY(-1px)',
          }}
        />
      );
    }

    return (
      <Icon
        name="warn-solid"
        size="font-size"
        aria-hidden="true"
        style={{
          color: '#ffffff',
          fontSize: '0.9rem',
          lineHeight: 1,
          transform: 'translateY(-1px)',
        }}
      />
    );
  };

  const statusBanner = (
    <div style={{ display: 'flex', width: '112px' }}>
      <div
        role="img"
        aria-label={`Current status: ${readableStatus}`}
        title={readableStatus}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 9,
          width: '100%',
          minWidth: 0,
          boxSizing: 'border-box',
          padding: '4px 8px',
          borderRadius: 8,
          background: 'linear-gradient(180deg, #727272 0%, #666666 100%)',
          boxShadow:
            'inset 0 1px 1px rgba(255, 255, 255, 0.2), inset 0 -1px 1px rgba(0, 0, 0, 0.35)',
        }}
      >
        {statusOrder.map((statusItem) => {
          const isActive = effectiveValue === statusItem;
          const activeStyles: Record<StatusValue, { backgroundColor: string; boxShadow: string }> =
            {
              GREEN: {
                backgroundColor: '#1ed760',
                boxShadow:
                  '0 0 4px rgba(46, 204, 113, 0.6), inset 0 1px 1px rgba(255, 255, 255, 0.36)',
              },
              AMBER: {
                backgroundColor: '#df6329',
                boxShadow:
                  '0 0 4px rgba(223, 99, 41, 0.6), inset 0 1px 1px rgba(255, 255, 255, 0.34)',
              },
              RED: {
                backgroundColor: '#cf0015',
                boxShadow:
                  '0 0 4px rgba(207, 0, 21, 0.62), inset 0 1px 1px rgba(255, 255, 255, 0.28)',
              },
            };

          return (
            <div
              key={statusItem}
              aria-hidden="true"
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                width: 26,
                height: 26,
                borderRadius: '50%',
                backgroundColor: '#a1a1a1',
                border: isActive ? 'none' : '1px solid #8a8a8a',
                boxShadow: isActive
                  ? `inset 0 1px 1px rgba(255, 255, 255, 0.3), 0 1px 1px rgba(0, 0, 0, 0.2), ${activeStyles[statusItem].boxShadow}`
                  : 'inset 0 1px 1px rgba(255, 255, 255, 0.28), inset 0 -1px 1px rgba(0, 0, 0, 0.32)',
                ...(isActive ? activeStyles[statusItem] : null),
              }}
            >
              {isActive ? renderStatusIcon(statusItem) : null}
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div
      data-testid={testId}
      style={{
        display: 'flex',
        flexDirection: 'column',
        width: '100%',
        minWidth: 0,
        gap: 6,
      }}
    >
      {!hideLabel && label ? (
        <Text
          style={{
            fontSize: 12,
            lineHeight: '16px',
            color: '#333333',
            fontWeight: 500,
          }}
        >
          {label}
        </Text>
      ) : null}
      {statusBanner}
    </div>
  );
}

export default withConfiguration(FusionAixComponentsStatusIndicator);
